<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Analysis_msg extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "analysis_msg";
    protected $fillable = [
        'users_id',
        'analysis_id',
        'msg_content'
    ];

    protected $casts = [
        'msg_content' => 'encrypted'
    ];

    public function user(){
        return $this->belongsTo(Users::class, 'users_id');
    }
}
