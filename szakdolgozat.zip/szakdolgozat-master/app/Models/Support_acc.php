<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Support_acc extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "support_acc";
    protected $fillable = [
        'users_id',
        'support_id'
    ];

    public function user() {
        return $this->belongsTo(Users::class, 'users_id');
    }
}
