<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Watchlist_coin extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "watchlist_coin";
    protected $fillable = [
        'users_id',
        'coin',
        'fav',
    ];

    protected $casts = [
        'coin' => 'encrypted',
        'fav' => 'encrypted'
    ];
}
