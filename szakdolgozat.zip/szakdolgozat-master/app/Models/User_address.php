<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User_address extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "user_address";
    protected $fillable = [
        'city_id',
        'street_id',
        'house_number'
    ];

    protected $casts = [
        'house_number' => 'encrypted'
    ];
}
