<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Support extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "support";
    protected $fillable = [
        'users_id',
        'email',
        'title',
        'content',
        'support_img',
        'created_date',
        'done'
    ];

    protected $casts = [
        'email' => 'encrypted',
        'content' => 'encrypted',
        'done' => 'encrypted',
        'support_img' => 'encrypted'
    ];

    public function user(){
        return $this->belongsTo(Users::class, 'users_id');
    }
}
