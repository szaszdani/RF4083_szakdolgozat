<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Users extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "users";
    protected $fillable = [
        'username',
        'pwd',
        'email',
        'address_id',
        'user_rank',
        'vip',
        'points'
    ];

    protected $casts = [
        'email' => 'encrypted',
        'user_rank' => 'encrypted',
        'vip' => 'encrypted'
    ];

    public function user_sec()
    {
        return $this->hasOne(User_security::class);
    }

    public function posts()
    {
        return $this->hasMany(Posts::class);
    }

    public function post_msg()
    {
        return $this->hasMany(Post_msg::class);
    }

    public function analysis()
    {
        return $this->hasMany(Analysis::class);
    }

    public function analysis_msg()
    {
        return $this->hasMany(Analysis_msg::class);
    }

    public function forum()
    {
        return $this->hasMany(Forum::class);
    }

    public function ban_list()
    {
        return $this->hasMany(Ban_list::class);
    }

    public function ban_acc()
    {
        return $this->hasMany(Ban_acc::class);
    }

    public function support()
    {
        return $this->hasMany(Support::class);
    }

    public function support_acc()
    {
        return $this->hasMany(Support_acc::class);
    }

    public function support_ans()
    {
        return $this->hasMany(Support_ans::class);
    }
}
