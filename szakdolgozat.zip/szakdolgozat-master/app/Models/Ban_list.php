<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Ban_list extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "ban_list";
    protected $fillable = [
        'users_id',
        'date_start',
        'date_end',
        'reason'
    ];

    protected $casts = [
        'reason' => 'encrypted'
    ];

    public function ban_acc(){
        return $this->hasOne(Ban_acc::class);
    }
    
    public function user(){
        return $this->belongsTo(Users::class, 'users_id');
    }
}
