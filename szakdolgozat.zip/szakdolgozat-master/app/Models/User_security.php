<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User_security extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "user_security";
    protected $fillable = [
        'users_id',
        'kyc',
        'sms',
        'anti_phising',
        'fa'
    ];

    protected $casts = [
        'kyc' => 'encrypted',
        'sms' => 'encrypted',
        'anti_phising' => 'encrypted',
        'fa' => 'encrypted'
    ];

    public function user()
    {
        return $this->belongsTo(Users::class, 'users_id');
    }
}
