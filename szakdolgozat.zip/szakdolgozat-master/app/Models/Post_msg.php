<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Post_msg extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "post_msg";
    protected $fillable = [
        'users_id',
        'posts_id',
        'msg_content',
        'msg_date'
    ];

    protected $casts = [
        'msg_content' => 'encrypted'
    ];
    
    public function user(){
        return $this->belongsTo(Users::class, 'users_id');
    }
}
