<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Support_ans extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "support_ans";
    protected $fillable = [
        'support_id',
        'users_id',
        'content',
        'ans_img',
        'created_date'
    ];

    protected $casts = [
        'content' => 'encrypted'
    ];

    public function user()
    {
        return $this->belongsTo(Users::class , 'users_id');
    }
}
