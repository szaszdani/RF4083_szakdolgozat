<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Forum extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "forum";
    protected $fillable = [
        'forum_owner',
        'title',
        'forum_desc',
        'created_date',
        'vip',
    ];

    public function posts(){
        return $this->hasMany(Posts::class);
    }

    public function user()
    {
        return $this->belongsTo(Users::class, 'forum_owner');
    }
}
