<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Quiz extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    public $timestamps = false;
    protected $table = "quiz";
    protected $fillable = [
        'users_id',
        'quiz_one',
        'quiz_two',
        'quiz_three',
        'quiz_four',
        'quiz_five',
        'quiz_six',
        'quiz_seven',
        'quiz_eight',
        'quiz_nine',
        'quiz_ten'
    ];
}
