<?php

namespace App\Http\Controllers;

use App\Models\Portfolio;
use Exception;
use Illuminate\Http\Request;

class PortfolioApiController extends Controller
{
    public function index()
    {
        try {
            $portfolio = Portfolio::all();
            return $portfolio;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'required',
                'coin' => 'required',
                'transaction_type' => 'required',
                'transaction_date' => 'required',
                'quantity' => 'required',
                'price' => 'required',
                'price_of_coin' => 'required'
            ]);

            Portfolio::create(array(
                'users_id' => $request->users_id,
                'coin' => $request->coin,
                'transaction_type' => $request->transaction_type,
                'transaction_date' => $request->transaction_date,
                'quantity' => $request->quantity,
                'price' => $request->price,
                'total_value' => $request->price_of_coin * $request->quantity
            ));

            return response()->json([
                "message" => "Sikeres hozzáadás!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen töltött ki! (CREATE)"
            ], 400);
        }
    }

    public function show($id)
    {
        try {
            if (Portfolio::where('users_id', $id)->exists()) {
                $portfolio = Portfolio::where('users_id', $id)->get();
                return $portfolio;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 400);
        }
    }

    public function update(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required',
                'users_id' => 'required',
                'coin' => 'required'
            ]);
            if (Portfolio::where('users_id', $request->users_id)->exists()) {
                $portfolio = Portfolio::where('users_id', $request->users_id)->get();
                foreach ($portfolio as $data) {
                    if ($request->coin == $data["coin"]) {
                        $pf = Portfolio::find($request->id);
                        $pf->transaction_date = is_null($request->transaction_date) ? $pf->transaction_date : $request->transaction_date;
                        if ($request->transaction_type == 0) {
                            if ($pf->quantity - $request->quantity < 0) {
                                return response()->json([
                                    "message" => "Kérem ne adjon meg nagyobb mennyiséget, mint ami a portfoliójában szerepel!"
                                ], 400);
                            }
                            $pf->quantity = is_null($request->quantity) ? $pf->quantity : $pf->quantity - $request->quantity;
                            $pf->price = is_null($request->price) ? $pf->price : $pf->price - $request->price;
                        }
                        else {
                            $pf->quantity = is_null($request->quantity) ? $pf->quantity : $request->quantity;
                        }
                        $pf->total_value = is_null($request->total_value) ? $pf->total_value : $request->total_value;
                        $pf->save();
                        if ($pf->quantity == 0) {
                            $pf->delete();
                        }
                        return response()->json([
                            "message" => "Sikeresen frissítette az adatait!"
                        ], 200);
                    }
                }
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 400);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 400);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! Kérem ellenőrizze, hogy mindent helyesen adott meg! (UPDATE)"
            ], 400);
        }

    }

    public function destroy(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required',
                'users_id' => 'required',
                'coin' => 'required'
            ]);
            if (Portfolio::where("users_id", $request->users_id)->exists()) {
                $portfolio = Portfolio::where([["users_id", $request->users_id]])->get();
                foreach ($portfolio as $data) {
                    if ($request->coin == $data["coin"]) {
                        $p = Portfolio::find($request->id);
                        $p->delete();
                        return response()->json([
                            "message" => "Sikeres törlés!"
                        ], 200);
                    }
                }
                return response()->json([
                    "message" => "Ilyen kriptovaluta nincsen hozzáadva az Ön portfoliójában!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 400);
        }

    }
}