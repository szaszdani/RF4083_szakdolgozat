<?php

namespace App\Http\Controllers;

use App\Models\User_security;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserSecurityApiController extends Controller
{
    public function index()
    {
        try {
            $user_security = User_security::all();
            return $user_security;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }
    public function show($id)
    {
        try {
            if (User_security::where('users_id', $id)->exists()) {
                if ($id == Auth::user()->id) {
                    $user_security = User_security::where('users_id', $id)->get();
                    return $user_security;
                }
                else {
                    return response()->json([
                        "message" => "Sikertelen lekérdezés! (ONE)"
                    ], 404);
                }

            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function getSecretKey()
    {
        $user = Auth::user()->id;
        return User_security::where('users_id', $user)->get();
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'kyc' => 'nullable',
                'sms' => 'min:10|max:12|nullable',
                'anti_phising' => 'min:4|max:6|nullable',
                'fa' => 'nullable'
            ]);
            $sec = User_security::where('users_id', Auth::user()->id)->first();
            if ($sec->exists()) {
                $sec->kyc = is_null($request->kyc) ? $sec->kyc : $request->kyc;
                $sec->sms = is_null($request->sms) ? $sec->sms : $request->sms;
                $sec->anti_phising = is_null($request->anti_phising) ? $sec->anti_phising : $request->anti_phising;
                $sec->fa = is_null($request->fa) ? $sec->fa : $request->fa;
                $sec->save();
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 404);
        }
    }
}
