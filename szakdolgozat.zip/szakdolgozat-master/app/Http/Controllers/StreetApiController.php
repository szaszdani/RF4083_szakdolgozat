<?php

namespace App\Http\Controllers;

use App\Models\Street;
use Exception;
use Illuminate\Http\Request;

class StreetApiController extends Controller
{
    public function index()
    {
        try
        {
            $street = Street::all();
            return $street;
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }
        
    }
    public function show($id)
    {
        try{
            if(Street::where('id', $id)->exists())
            {
                $street = Street::find($id);
                return $street;
            }
        }
        catch(Exception $e){
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }
}
