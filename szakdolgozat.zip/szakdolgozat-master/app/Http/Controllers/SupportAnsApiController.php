<?php

namespace App\Http\Controllers;

use App\Models\Support_ans;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SupportAnsApiController extends Controller
{
    public function index()
    {
        try {
            $support_ans = Support_ans::all();
            return $support_ans;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'support_id' => 'required',
                'users_id' => 'required',
                'content' => 'min:10|max:1000|required'
            ]);

            Support_ans::create(array(
                'support_id' => $request->support_id,
                'users_id' => $request->users_id,
                'content' => $request->content,
                'created_date' => date('Y-m-d H:i:s')
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az üzenetet!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Support_ans::where('support_id', $id)->exists()) {
                $support_ans = Support_ans::with('user:id,username')->where('support_id', $id)->get();
                return $support_ans;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'content' => 'min:10|max:1000|nullable'
        ]);
        try {
            if (Support_ans::where('id', $request->id)->exists()) {
                $support_ans = Support_ans::find($request->id);
                $support_ans->content = is_null($request->content) ? $support_ans->content : $request->content;
                $support_ans->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }

    }

    public function destroy($id)
    {
        try {
            $support_ans = Support_ans::find($id);
            if ($support_ans->exists()) {
                $support_ans->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }

    }
}
