<?php

namespace App\Http\Controllers;

use App\Models\Ban_acc;
use App\Models\Ban_list;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BanListApiController extends Controller
{
    public function index()
    {
        try {
            $ban_list = Ban_list::with('user:id,username')->get();
            return $ban_list;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'required',
                'ban_acc' => 'required',
                'date_end' => 'required',
                'reason' => 'min:10|max:100|required',
            ]);
            if ($request->date_end <= date('Y-m-d')) {
                return response()->json([
                    "message" => "Kérem adjon meg egy másik időpontot!"
                ], 400);
            }
            if (Ban_list::where('users_id', $request->users_id)->exists()) {
                $ban = Ban_list::where('users_id', $request->users_id)->latest('date_end')->first();
                if ($ban["date_end"] >= date('Y-m-d')) {
                    return response()->json([
                        "message" => "Ennek a felhasználónak már van érvényben kitiltása!"
                    ], 400);
                }

            }
            Ban_list::create(array(
                'users_id' => $request->users_id,
                'date_start' => date('Y-m-d'),
                'date_end' => $request->date_end,
                'reason' => $request->reason
            ));

            $banListId = DB::getPdo()->lastInsertId();

            Ban_acc::create(array(
                'users_id' => $request->ban_acc,
                'ban_list_id' => $banListId
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta a kitiltást!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Ban_list::where('id', $id)->exists()) {
                $ban_list = Ban_list::find($id);
                return $ban_list;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'reason' => 'min:10|max:100|nullable'
            ]);
            if (Ban_list::where('id', $id)->exists()) {
                $ban_list = Ban_list::find($id);
                $ban_list->date_end = is_null($request->date_end) ? $ban_list->date_end : $request->date_end;
                $ban_list->reason = is_null($request->reason) ? $ban_list->reason : $request->reason;


                $ban_list->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $ban_list = Ban_list::find($id);
            if ($ban_list->exists()) {
                $ban_acc = Ban_acc::where('ban_list_id', $ban_list['id']);
                $ban_acc->delete();
                $ban_list->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }
    }
}
