<?php

namespace App\Http\Controllers;

use App\Models\Quiz;
use Exception;
use Illuminate\Http\Request;

class QuizApiController extends Controller
{
    public function index()
    {
        try {
            $quiz = Quiz::all();
            return $quiz;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function show($id)
    {
        try {
            if (Quiz::where('users_id', $id)->exists()) {
                $quiz = Quiz::where('users_id', $id)->get();
                return $quiz;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'quiz_one' => 'max:1|nullable',
                'quiz_two' => 'max:1|nullable',
                'quiz_three' => 'max:1|nullable',
                'quiz_four' => 'max:1|nullable',
                'quiz_five' => 'max:1|nullable',
                'quiz_six' => 'max:1|nullable',
                'quiz_seven' => 'max:1|nullable',
                'quiz_eight' => 'max:1|nullable',
                'quiz_nine' => 'max:1|nullable',
                'quiz_ten' => 'max:1|nullable',
            ]);
            if (Quiz::where('users_id', $id)->exists()) {
                $quiz = Quiz::where('users_id', $id)->get();
                foreach ($quiz as $data) {
                    $userQuiz = Quiz::find($data['id']);
                    $userQuiz->update($request->all());
                }

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $quiz = Quiz::find($id);
            if ($quiz->exists()) {
                $quiz->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }
    }
}
