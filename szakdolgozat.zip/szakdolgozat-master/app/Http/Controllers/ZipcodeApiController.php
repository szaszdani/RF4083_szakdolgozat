<?php

namespace App\Http\Controllers;

use App\Models\Zipcode;
use Exception;

class ZipcodeApiController extends Controller
{
    public function index()
    {
        try
        {
            $zipcode = Zipcode::all();
            return $zipcode;
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }
        
    }
    public function show($id)
    {
        try{
            if(Zipcode::where('id', $id)->exists())
            {
                $zipcode = Zipcode::find($id);
                return $zipcode;
            }
        }
        catch(Exception $e){
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }
}
