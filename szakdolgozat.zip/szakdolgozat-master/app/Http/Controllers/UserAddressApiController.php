<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\Street;
use App\Models\User_address;
use App\Models\Users;
use App\Models\Zipcode;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserAddressApiController extends Controller
{
    public function index()
    {
        try {
            $user_address = User_address::all();
            return $user_address;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }
    public function show($id)
    {
        try {
            if (User_address::where('id', $id)->exists()) {
                $user_address = User_address::find($id);
                $city = City::where('id', $user_address->city_id)->get();
                $street = Street::where('id', $user_address->street_id)->get();
                $zipcode = Zipcode::where('id', $city[0]["zipcode_id"])->get();
                return response()->json([
                    'id' => $user_address->id,
                    'zipcode' => $zipcode[0]["zipcode"],
                    'city_name' => $city[0]["city_name"],
                    'street_name' => $street[0]["street_name"],
                    'house_number' => $user_address->house_number
                ]);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'house_number' => 'min:1|max:3|nullable',
                'city_name' => 'min:3|max:30|nullable',
                'street_name' => 'min:2|max:15|nullable',
                'zipcode' => 'min:1|max:4|nullable'
            ]);
            if (Users::where('id', Auth::user()->id)->exists()) {
                $user = Users::find($id);
                $address = User_address::where('id', $user['address_id'])->first();
                $address->house_number = is_null($request->house_number) ? $address->house_number : $request->house_number;

                $city = City::where('id', $address['city_id'])->first();
                $city->city_name = is_null($request->city_name) ? $city->city_name : $request->city_name;

                $street = Street::where('id', $address['street_id'])->first();
                $street->street_name = is_null($request->street_name) ? $street->street_name : $request->street_name;

                $zipcode = Zipcode::where('id', $city['zipcode_id'])->first();
                $zipcode->zipcode = is_null($request->zipcode) ? $zipcode->zipcode : $request->zipcode;

                $address->save();
                $city->save();
                $street->save();
                $zipcode->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés! (UPDATE)"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }

    }
}