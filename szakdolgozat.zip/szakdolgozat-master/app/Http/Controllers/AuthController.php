<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\Quiz;
use App\Models\Street;
use App\Models\User_address;
use App\Models\User_security;
use App\Models\Users;
use App\Models\Zipcode;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    //Új felhasználó regisztrálása
    public function register(Request $request)
    {
        try {
            $request->validate([
                'username' => 'min:5|max:15|required',
                'pwd' => 'min:6|max:15|required',
                'email' => 'email|required',
                'zipcode' => 'min:1|max:4|required',
                'city_name' => 'min:3|max:30|required',
                'street_name' => 'min:2|max:20|required',
                'house_number' => 'min:1|max:3|required'
            ]);
            $email = Users::all(['email']);
            foreach ($email as $data) {
                if ($request->email == $data['email']) {
                    return response()->json([
                        "message" => "Ilyen e-mail címmel már létezik fiók!"
                    ], 400);
                }
            }

            $newUser = Users::where("username", $request->username)->first();
            if ($newUser) {
                return response()->json([
                    "message" => "Ilyen felhasználónévvel már létezik fiók!"
                ], 400);
            }
            else {
                Zipcode::create(array(
                    'zipcode' => $request->zipcode
                ));
                $zipID = DB::getPdo()->lastInsertId();
                Street::create(array(
                    'street_name' => $request->street_name
                ));
                $stID = DB::getPdo()->lastInsertId();
                City::create(array(
                    'zipcode_id' => $zipID,
                    'city_name' => $request->city_name
                ));
                $cityID = DB::getPdo()->lastInsertId();
                User_address::create(array(
                    'city_id' => $cityID,
                    'street_id' => $stID,
                    'house_number' => $request->house_number
                ));
                $addressID = DB::getPdo()->lastInsertId();
                $user = Users::create(array(
                    'username' => $request->username,
                    'pwd' => bcrypt($request->pwd),
                    'email' => $request->email,
                    'email_verified' => "0",
                    'address_id' => $addressID,
                    'user_rank' => "1",
                    'vip' => "0",
                    'points' => "0"
                ));
                $userID = DB::getPdo()->lastInsertId();
                User_security::create(array(
                    'users_id' => $userID,
                    'kyc' => "0",
                    'sms' => "0",
                    'anti_phising' => "0",
                    'fa' => "0"
                ));

                Quiz::create(array(
                    'users_id' => $userID,
                    'quiz_one' => "0",
                    'quiz_two' => "0",
                    'quiz_three' => "0",
                    'quiz_four' => "0",
                    'quiz_five' => "0",
                    'quiz_six' => "0",
                    'quiz_seven' => "0",
                    'quiz_eight' => "0",
                    'quiz_nine' => "0",
                    'quiz_ten' => "0"
                ));

                $token = $user->createToken('userToken')->plainTextToken;
                $response = [
                    'id' => $user->id,
                    'email' => $user->email,
                    'token' => $token
                ];

                return response($response, 200);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen regisztráció! Kérem ellenőrízze, hogy mindenhol helyes adatokat adott-e meg!"
            ], 404);
        }
    }

    public function google2FA()
    {

        $google2fa = app('pragmarx.google2fa');
        $googleSecretKey = $google2fa->generateSecretKey();

        $QR_Image = $google2fa->getQRCodeInline(
            'KriptoBázis Google 2FA',
            Auth::user()->email,
            $googleSecretKey
        );
        Storage::disk('public')->put(Auth::user()->email . '.svg', $QR_Image);
        return response(array(
            'email' => Auth::user()->email,
            'secretKey' => $googleSecretKey
        ));

    }

    public function verify2FA(Request $request)
    {
        $request->validate([
            'inputCode' => 'required',
            'secretKey' => 'required'
        ]);

        if (Storage::disk('public')->exists(Auth::user()->email . '.svg')) {
            Storage::disk('public')->delete(Auth::user()->email . '.svg');
        }

        $google2fa = app('pragmarx.google2fa');
        $valid = $google2fa->verifyKey($request->secretKey, $request->inputCode);
        if ($valid) {
            if (User_security::where('users_id', Auth::user()->id)->exists()) {
                $sec = User_security::where('users_id', Auth::user()->id)->get();
                foreach ($sec as $data) {
                    if ($data["fa"] == "0") {
                        $user = User_security::find($data["id"]);
                        $user->fa = is_null($request->secretKey) ? $user->fa : $request->secretKey;
                        $user->save();
                        return response()->json([
                            "message" => "Sikeresen beállította a kétlépcsős azonosítást!"
                        ], 200);
                    }
                    else if ($data["fa"] == $request->secretKey) {
                        return response()->json([
                            "message" => "Sikeresen bejelentkezett!"
                        ], 200);
                    }
                }
            }
        }
        else {
            return response()->json([
                "message" => "Sikertelen beállítás!"
            ], 400);
        }
    }

    //Beléptetés
    public function login(Request $request)
    {
        try {
            $request->validate([
                'username' => 'max:15|required',
                'pwd' => 'max:15|required'
            ]);

            $user = Users::where("username", $request->username)->first();
            if (!$user || !Hash::check($request->pwd, $user->pwd)) {
                return response()->json([
                    "message" => "Sikertelen bejelentkezés!"
                ], 400);
            }

            if (DB::table('personal_access_tokens')->where('tokenable_id', $user->id)->exists()) {
                $row = DB::table('personal_access_tokens')->where('tokenable_id', $user->id)->first();
                DB::table('personal_access_tokens')->delete($row->id);
            }
            $token = $user->createToken('userToken')->plainTextToken;
            $response = [
                'user' => $user,
                'token' => $token
            ];
            return response($response, 201);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen belépés! (LOGIN)"
            ], 400);
        }
    }

    //Kilépés esetén megszűnik a token
    public function logout(Request $request)
    {
        try {
            $request->user()->tokens()->delete();
            return [
                "message" => "Kijelentkezett!"
            ];
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen kijelentkezés! (LOGOUT)"
            ], 400);
        }
    }

    public function userVerify(Request $request)
    {
        try {
            $request->validate([
                'token' => 'required'
            ]);
            if(Users::where('email_verified', $request->token)->exists())
            {
                $user = Users::where('email_verified', $request->token)->get();
                foreach ($user as $data) {
                    $userVer = Users::find($data["id"]);
                    $userVer->email_verified = "1";
                    $userVer->save();
                }
                return response()->json([
                    "message" => "Sikeres megerősítés!"
                ], 200);
            }
            else
            {
                return response()->json([
                    "message" => "Sikertelen megerősítés! Korábbi token-t alkalmazott!"
                ], 400);
            }
            
        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 400);
        }
    }
    public function verifyEmail(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|numeric',
                'email' => 'email|required'
            ]);

            $user = Users::find($request->id);
            if ($user->email_verified == "1") {
                return response()->json([
                    "message" => "Sikeres bejelentkezés!"
                ], 200);
            }
            else {
                $tokenData = Str::random(32);
                $user->email_verified = $tokenData;
                $user->save();
                $action_link = "http://localhost:8000/verifyEmail/" . $tokenData;
                $body = "Az alábbi linkre kattintva tudja megerősíteni a regisztrációját!";
                Mail::send('email/email-verify', ['action_link' => $action_link, 'body' => $body], function ($message) use ($request) {
                    $message->from("kriptobazis@gmail.com", 'Kriptóbázis - E-mail megerősítés');
                    $message->to($request->email, '')
                        ->subject("E-mail megerősítés");
                });
                return response()->json([
                    "message" => "Elküldtünk Önnek egy megerősítő e-mail-t, mivel a fiókja nincsen megerősítve!",
                    "email" => true
                ], 200);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 400);
        }

    }
}