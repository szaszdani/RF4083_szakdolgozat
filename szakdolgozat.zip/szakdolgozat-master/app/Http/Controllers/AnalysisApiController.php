<?php

namespace App\Http\Controllers;

use App\Models\Analysis;
use App\Models\Analysis_msg;
use App\Models\Ban_list;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AnalysisApiController extends Controller
{
    public function index()
    {
        try {
            $analysis = Analysis::with('user:id,username')->get();
            return $analysis;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'required',
                'title' => 'min:5|max:25|required',
                'content' => 'min:10|max:1000|required',
                'img' => 'mimes:jpeg,jpg,png|nullable'
            ]);

            if (Ban_list::where('users_id', $request->users_id)->exists()) {
                $ban = Ban_list::where('users_id', $request->users_id)->latest('date_end')->first();

                $date = date('Y-m-d');
                if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                    return response()->json([
                        "message" => "Ön nem hozhat létre elemzést, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                    ], 400);
                }

            }

            if ($request->file('img')) {
                $img = $request->file('img');
                $randDest = Str::random(32);
                $destination_path = 'public/images/analysis/' . $randDest;
                $image_name = $img->getClientOriginalName();
                $request->file('img')->storeAs($destination_path, $image_name);
                $path = $randDest . '/' . $image_name;
            }
            else {
                $path = NULL;
            }

            Analysis::create(array(
                'users_id' => $request->users_id,
                'title' => $request->title,
                'content' => $request->content,
                'created_date' => date('Y-m-d'),
                'viewing' => 0,
                'img' => $path,
                'likes' => 0
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az elemzést!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Analysis::where('id', $id)->exists()) {
                $analysis = Analysis::find($id);
                return $analysis;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {

            $request->validate([
                'title' => 'min:5|max:25|nullable',
                'content' => 'min:10|max:1000|nullable',
                'viewing' => 'nullable',
                'likes' => 'nullable',
                'img' => 'mimes:jpeg,jpg,png|nullable'
            ]);
            if (Analysis::where('id', $id)->exists()) {
                $analysis = Analysis::find($id);
                $path = null;
                if (Analysis::where('title', $request->title)->exists()) {
                    return response()->json([
                        "message" => "Sikertelen frissítés! Ilyen címmel már létezik elemzés!"
                    ], 404);
                }
                $analysis->title = is_null($request->title) ? $analysis->title : $request->title;
                $analysis->content = is_null($request->content) ? $analysis->content : $request->content;
                $analysis->viewing = is_null($request->viewing) ? $analysis->viewing : $request->viewing;
                if ($request->file('img')) {
                    if (Storage::disk('public')->exists('images/analysis/' . $analysis->img)) {
                        $directory = explode('/', $analysis->img);
                        Storage::disk('public')->deleteDirectory('images/analysis/' . $directory[0]);
                    }
                    $img = $request->file('img');
                    $randDest = Str::random(32);
                    $destination_path = 'public/images/analysis/' . $randDest;
                    $image_name = $img->getClientOriginalName();
                    $request->file('img')->storeAs($destination_path, $image_name);
                    $path = $randDest . '/' . $image_name;
                }
                else {
                    $path = $analysis->img;
                }
                $analysis->img = is_null($request->file('img')) ? $analysis->img : $path;
                $analysis->likes = is_null($request->likes) ? $analysis->likes : $request->likes;

                $analysis->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $analysis = Analysis::find($id);
            if ($analysis->exists()) {
                $analysis_msg = Analysis_msg::where('analysis_id', $analysis['id']);
                $analysis_msg->delete();
                if ($analysis->img != null) {
                    $directory = explode('/', $analysis->img);
                    if (Storage::disk('public')->exists('images/analysis/' . $analysis->img)) {
                        Storage::disk('public')->deleteDirectory('images/analysis/' . $directory[0]);
                    }
                }

                $analysis->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }
    }
}