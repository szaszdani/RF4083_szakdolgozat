<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class UsersApiController extends Controller
{
    public function index()
    {
        try {
            $user = Users::with('user_sec')->get();
            return $user;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }
    public function show($id)
    {
        try {
            if (Users::where('id', $id)->exists()) {
                $user = Users::find($id);
                return $user;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 400);
        }
    }
    public function allForgotPassword()
    {
        try {
            return DB::table('password_resets')->get();
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL PWD)"
            ], 400);
        }

    }

    public function deleteForgotPassword($email)
    {
        try {
            if (DB::table('password_resets')->where('email', $email)->exists()) {
                DB::table('password_resets')->where('email', $email)->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }

            return response()->json([
                "message" => "Sikertelen törlés!"
            ], 400);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (PWD)"
            ], 400);
        }

    }

    public function forgotPassword(Request $request)
    {
        try {
            $request->validate([
                'email' => 'email|required'
            ]);

            $user = Users::all();
            foreach ($user as $data) {
                if ($request->email == $data["email"]) {
                    if (DB::table('password_resets')->where('email', $request->email)->exists()) {
                        return response()->json([
                            "message" => "Önnek van érvényben egy visszaállítása!"
                        ], 400);
                    }

                    DB::table("password_resets")->insert([
                        'email' => $request->email,
                        'token' => Str::random(60),
                        'created_at' => Date::now()
                    ]);

                    $tokenData = DB::table('password_resets')->where("email", $request->email)->first();
                    $action_link = "http://localhost:8000/reset-password/" . $tokenData->token;
                    $body = "Az alábbi linkre kattintva tudja visszaállítani a jelszavát! Abban az esetben, ha ezt a jelszó visszaállítást nem Ön kérte, kérem hagyja figyelmen kívül!";
                    Mail::send('email-forgot', ['action_link' => $action_link, 'body' => $body], function ($message) use ($request) {
                        $message->from("kriptobazis@gmail.com", 'Kriptóbázis - Jelszó visszaállítás');
                        $message->to($request->email, '')
                            ->subject("Jelszó visszaállítás");
                    });

                    return response()->json([
                        "message" => "Az e-mail sikeresen elküldve!"
                    ], 200);
                }
            }
            return response()->json([
                "message" => "Sikertelen jelszó visszaállítás!"
            ], 400);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen jelszó visszaállítás! (FORGOT-PASSWORD)"
            ], 400);
        }


    }

    public function resetPassword(Request $request)
    {
        try {
            $request->validate([
                'email' => 'email|required',
                'password' => 'min:6|max:15|required',
                'password_verify' => 'min:6|max:15|required',
                'token' => 'required'
            ]);
            if ($request->password == $request->password_verify) {
                $user = Users::all();
                foreach ($user as $data) {
                    if ($request->email == $data["email"]) {
                        $token = DB::table("password_resets")->where('token', $request->token)->first();
                        if ($token) {
                            Users::where("id", $data["id"])->update(['pwd' => Hash::make($request->password)]);
                            DB::table('password_resets')->where(['email' => $request->email])->delete();

                            return response()->json([
                                "message" => "Sikeresen megváltoztatta a jelszavát!"
                            ], 200);
                        }
                    }
                }
                return response()->json([
                    "message" => "Sikertelen jelszó visszaállítás!"
                ], 400);
            }
            else {
                return response()->json([
                    "message" => "A két jelszó nem egyezik!"
                ], 400);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen jelszó frissítés! Kérem ellenőrizze, hogy helyes adatokat adott-e meg!"
            ], 400);
        }
    }

    public function getUserId()
    {
        try {
            return response()->json([
                "id" => Auth::user()->id
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés (GET-ID)!"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'username' => 'min:5|max:15|nullable',
                'email' => 'email|nullable',
                'pwd' => 'min:6|max:15|nullable',
                'user_rank' => 'max:1|nullable',
                'vip' => 'max:1|nullable',
                'points' => 'nullable',
            ]);
            if (Users::where('id', $id)->exists()) {
                $user = Users::find($id);
                if (Users::where('username', $request->username)->exists()) {
                    return response()->json([
                        "message" => "Sikertelen frissítés! Ilyen felhasználónév már létezik!"
                    ], 404);
                }
                $user->username = is_null($request->username) ? $user->username : $request->username;

                $email = Users::all(['email']);
                foreach ($email as $data) {
                    if ($request->email == $data['email']) {
                        return response()->json([
                            "message" => "Sikertelen frissítés! Ilyen e-mail cím már létezik!"
                        ], 404);
                    }
                }
                $user->email = is_null($request->email) ? $user->email : $request->email;
                $user->pwd = is_null($request->pwd) ? $user->pwd : bcrypt($request->pwd);
                $user->user_rank = is_null($request->user_rank) ? $user->user_rank : $request->user_rank;
                $user->vip = is_null($request->vip) ? $user->vip : $request->vip;
                $user->points = is_null($request->points) ? $user->points : $request->points;
                $user->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }

    }
}
