<?php

namespace App\Http\Controllers;

use App\Models\Watchlist_coin;
use Exception;
use Illuminate\Http\Request;

class WatchlistApiController extends Controller
{
    public function index()
    {
        try {
            $watchlist = Watchlist_coin::all();
            return $watchlist;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'numeric|required',
                'coin' => 'required',
                'fav' => 'numeric|required'
            ]);

            $watch = Watchlist_coin::where("users_id", $request->users_id)->get();
            foreach ($watch as $data) {
                if ($request->coin == $data["coin"]) {
                    return response()->json([
                        "message" => "Egyszer már hozzáadta ezt a kriptovalutát a listájához!"
                    ], 400);
                }
            }

            Watchlist_coin::create(array(
                'users_id' => $request->users_id,
                'coin' => $request->coin,
                'fav' => $request->fav,
            ));

            return response()->json([
                "message" => "Sikeresen hozzáadta az elemet a figyelőlistához!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Watchlist_coin::where('users_id', $id)->exists()) {
                $watchlist = Watchlist_coin::where('users_id', $id)->get();
                return $watchlist;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 404);
        }
    }

    public function update(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'numeric|required',
                'coin' => 'required',
                'fav' => 'numeric|required',
            ]);

            if (Watchlist_coin::where('users_id', $request->users_id)->exists()) {
                $watchlist = Watchlist_coin::where([["users_id", $request->users_id]])->get();
                foreach ($watchlist as $data) {
                    if ($request->coin == $data["coin"]) {
                        $w = Watchlist_coin::find($data["id"]);
                        $w->fav = is_null($request->fav) ? $w->fav : $request->fav;
                        $w->save();
                        return response()->json([
                            "message" => "Sikeresen frissítette az adatait!"
                        ], 200);
                    }
                }
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }

    }

    public function destroy(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'integer|required',
                'coin' => 'required',
            ]);
            if (Watchlist_coin::where("users_id", $request->users_id)->exists()) {
                $watchlist = Watchlist_coin::where([["users_id", $request->users_id]])->get();
                foreach ($watchlist as $data) {
                    if ($request->coin == $data["coin"]) {
                        $w = Watchlist_coin::find($data["id"]);
                        $w->delete();
                        return response()->json([
                            "message" => "Sikeres törlés!"
                        ], 200);
                    }
                }
                return response()->json([
                    "message" => "Ilyen kriptovaluta nincsen hozzáadva az Ön figyelőlistájához!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }

    }
}
