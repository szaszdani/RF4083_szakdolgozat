<?php

namespace App\Http\Controllers;

use App\Models\Forum;
use App\Models\Post_msg;
use App\Models\Posts;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ForumApiController extends Controller
{
    public function index()
    {
        try {
            $forum = Forum::with('user:id,username')->get();
            return $forum;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'forum_owner' => 'required',
                'title' => 'min:5|max:25|required',
                'forum_desc' => 'min:10|max:100|required',
                'vip' => 'max:1|required'
            ]);
            if(Forum::where('title', $request->title)->exists())
            {
                return response()->json([
                    "message" => "Ilyen névvel már van létrehozva fórum!"
                ], 400);
            }
            Forum::create(array(
                'forum_owner' => $request->forum_owner,
                'title' => $request->title,
                'forum_desc' => $request->forum_desc,
                'created_date' => date('Y-m-d H:i:s'),
                'vip' => $request->vip
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az elemzést!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Forum::where('id', $id)->exists()) {
                $forum = Forum::find($id);
                return $forum;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'title' => 'min:5|max:25|nullable',
                'forum_desc' => 'min:10|max:100|nullable'
            ]);
            if (Forum::where('id', $id)->exists()) {
                $forum = Forum::find($id);
                if (Forum::where('title', $request->title)->exists()) {
                    return response()->json([
                        "message" => "Sikertelen frissítés! Ilyen címmel már létezik fórum!"
                    ], 404);
                }
                $forum->title = is_null($request->title) ? $forum->title : $request->title;
                $forum->forum_desc = is_null($request->forum_desc) ? $forum->forum_desc : $request->forum_desc;

                $forum->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $forum = Forum::find($id);
            if ($forum->exists()) {
                if (Posts::where('forum_id', $forum['id'])->exists()) {
                    $posts = Posts::where('forum_id', $forum['id'])->get();
                    foreach ($posts as $data) {
                        $post = Posts::find($data['id']);
                        if (Post_msg::where('posts_id', $data['id'])->exists()) {
                            $post_msg = Post_msg::where('posts_id', $data['id'])->get();
                            foreach ($post_msg as $data) {
                                $msg = Post_msg::find($data['id']);
                                $msg->delete();
                            }
                        }


                        if ($data['post_img'] != null) {
                            $directory = explode('/', $data['post_img']);
                            if (Storage::disk('public')->exists('images/post/' . $data['post_img'])) {
                                Storage::disk('public')->deleteDirectory('images/post/' . $directory[0]);
                            }
                            $post->delete();
                        }
                        else {
                            $post->delete();
                        }

                    }
                    $forum->delete();
                }
                else {
                    $forum->delete();
                }
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 404);
        }
    }
}
