<?php

namespace App\Http\Controllers;

use App\Models\Support;
use App\Models\Support_acc;
use App\Models\Support_ans;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SupportApiController extends Controller
{
    public function index()
    {
        try {
            $support = Support::with('user:id,username')->get();
            return $support;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }
    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'users_id' => 'nullable',
                'email' => 'email|required',
                'title' => 'min:5|max:20|required',
                'content' => 'min:10|max:1000|required',
                'img' => 'mimes:jpeg,jpg,png|nullable'
            ]);

            if ($request->users_id) {
                $users_id = $request->users_id;
            }
            else {
                $users_id = NULL;
            }

            if ($request->file('img')) {
                $img = $request->file('img');
                $randDest = Str::random(32);
                $destination_path = 'public/images/support/' . $randDest;
                $image_name = $img->getClientOriginalName();
                $request->file('img')->storeAs($destination_path, $image_name);
                $path = $randDest . '/' . $image_name;
            }
            else {
                $path = NULL;
            }

            $support = Support::create(array(
                'users_id' => $users_id,
                'email' => $request->email,
                'title' => $request->title,
                'content' => $request->content,
                'support_img' => $path,
                'created_date' => date('Y-m-d H:i:s'),
                'done' => '0'
            ));
            $body = "Segítségkérési kérelmét megkaptuk! A továbbiakban egy munkatársunk fog Önnek segíteni, amint erre lesz alkalma! Amennyiben nem regisztrált felhasználóként hozott létre segítségkérést e-mail-ben folytatódik a segítségadás, más esetben a weboldalon tekintheti meg a válaszunkat!";
            $action_link = "http://localhost:8000/login";
            Mail::send('email-forgot', ['action_link' => $action_link, 'body' => $body], function ($message) use ($request) {
                $message->from("dszasz6@gmail.com", 'Kriptóbázis - Segítségkérés');
                $message->to($request->email, '')
                    ->subject("Segítségkérés");
            });
            return response()->json([
                "message" => $support
            ], 200);

        }
        catch (Exception $e) {
            return response()->json([
                "message" => $e
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Support::where('id', $id)->exists()) {
                $support = Support::find($id);
                return $support;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function showByUserId($id)
    {
        try {
            if (Support::where('users_id', $id)->exists()) {
                $support = Support::where('users_id', $id)->get();
                return $support;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'content' => 'min:10|max:1000|nullable',
                'done' => 'max:1|nullable'
            ]);
            if (Support::where('id', $id)->exists()) {
                $support = Support::find($id);
                $support->content = is_null($request->content) ? $support->content : $request->content;
                $support->done = is_null($request->done) ? $support->done : $request->done;
                $support->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }

    }

    public function destroy($id)
    {
        try {
            $support = Support::find($id);
            if ($support->exists()) {
                if ($support->support_img != null) {
                    $directory = explode('/', $support->support_img);
                    if (Storage::disk('public')->exists('images/support/' . $support->support_img)) {
                        Storage::disk('public')->deleteDirectory('images/support/' . $directory[0]);
                    }
                }
                $support_ans = Support_ans::where('support_id', $id);
                $support_acc = Support_acc::where('support_id', $id);
                $support_acc->delete();
                $support_ans->delete();
                $support->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }

    }
}
