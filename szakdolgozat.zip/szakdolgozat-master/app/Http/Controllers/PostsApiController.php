<?php

namespace App\Http\Controllers;

use App\Models\Post_msg;
use App\Models\Posts;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PostsApiController extends Controller
{
    public function index()
    {
        try {
            $posts = Posts::with('forum:id,title,vip')->with('user:id,username')->get();
            return $posts;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'forum_id' => 'required',
                'users_id' => 'required',
                'post_title' => 'min:5|max:15|required',
                'post_text' => 'min:10|max:1000|required',
                'img' => 'mimes:jpeg,jpg,png|nullable'
            ]);

            if ($request->file('img')) {
                $img = $request->file('img');
                $randDest = Str::random(32);
                $destination_path = 'public/images/post/' . $randDest;
                $image_name = $img->getClientOriginalName();
                $request->file('img')->storeAs($destination_path, $image_name);
                $path = $randDest . '/' . $image_name;
            }
            else {
                $path = NULL;
            }

            Posts::create(array(
                'forum_id' => $request->forum_id,
                'users_id' => $request->users_id,
                'post_title' => $request->post_title,
                'post_text' => $request->post_text,
                'post_img' => $path,
                'post_date' => date('Y-m-d H:i:s'),
                'post_viewing' => 0
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az elemzést!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Posts::where('id', $id)->exists()) {
                $posts = Posts::with('forum:id,title,vip')->with('user:id,username')->where('id', $id)->get();
                return $posts;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function showPerForum($id)
    {
        try {
            if (Posts::where('forum_id', $id)->exists()) {
                $posts = Posts::with('forum:id,title,vip')->with('user:id,username')->where('forum_id', $id)->get();
                return $posts;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'post_title' => 'min:5|max:15|nullable',
                'post_text' => 'min:5|max:1000|nullable',
                'post_viewing' => 'nullable',
                'img' => 'mimes:jpeg,jpg,png|nullable'
            ]);
            if (Posts::where('id', $id)->exists()) {
                $post = Posts::find($id);

                if (Posts::where('post_title', $request->post_title)->exists()) {
                    return response()->json([
                        "message" => "Sikertelen frissítés! Ilyen címmel már létezik elemzés!"
                    ], 404);
                }
                $post->post_title = is_null($request->post_title) ? $post->post_title : $request->post_title;
                $post->post_text = is_null($request->post_text) ? $post->post_text : $request->post_text;

                if ($request->file('img')) {
                    if (Storage::disk('public')->exists('images/post/' . $post->post_img)) {
                        $directory = explode('/', $post->post_img);
                        Storage::disk('public')->deleteDirectory('images/post/' . $directory[0]);
                    }
                    $img = $request->file('img');
                    $randDest = Str::random(32);
                    $destination_path = 'public/images/post/' . $randDest;
                    $image_name = $img->getClientOriginalName();
                    $request->file('img')->storeAs($destination_path, $image_name);
                    $path = $randDest . '/' . $image_name;
                }
                else {
                    $path = $post->post_img;
                }
                $post->post_img = is_null($request->file('img')) ? $post->post_img : $path;
                $post->post_viewing = is_null($request->post_viewing) ? $post->post_viewing : $request->post_viewing;
                $post->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $posts = Posts::find($id);
            if ($posts->exists()) {
                if (Post_msg::where('posts_id', $posts['id'])->exists()) {
                    $post_msg = Post_msg::where('posts_id', $posts['id']);
                    $post_msg->delete();
                }
                if ($posts->post_img != null) {
                    $directory = explode('/', $posts->post_img);
                    if (Storage::disk('public')->exists('images/post/' . $posts->post_img)) {
                        Storage::disk('public')->deleteDirectory('images/post/' . $directory[0]);
                    }
                }

                $posts->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }
    }
}
