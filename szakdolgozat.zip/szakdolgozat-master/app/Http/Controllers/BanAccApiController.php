<?php

namespace App\Http\Controllers;

use App\Models\Ban_acc;
use Exception;
use Illuminate\Http\Request;

class BanAccApiController extends Controller
{
    public function index()
    {
        try
        {
            $ban_acc = Ban_acc::with('user:id,username')->get();
            return $ban_acc;
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }
        
    }

    public function show($id)
    {
        try{
            if(Ban_acc::where('id', $id)->exists())
            {
                $ban_acc = Ban_acc::find($id);
                return $ban_acc;
            }
        }
        catch(Exception $e){
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }
    

    public function update(Request $request, $id)
    {
        try
        {
            if(Ban_acc::where('id', $id)->exists())
            {
                $ban_acc = Ban_acc::find($id);

                if(Ban_acc::where('users_id', $request->users_id)->exists())
                {
                    return response()->json([
                        "message" => "Sikertelen frissítés! Ezt a felhasználót, már kitiltották egyszer!"
                    ], 404);
                }
                $ban_acc->users_id = is_null($request->users_id) ? $ban_acc->users_id : $request->users_id;

                $ban_acc->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            } 
            else 
            {
            return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

}
