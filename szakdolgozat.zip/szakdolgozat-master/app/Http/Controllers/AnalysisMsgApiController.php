<?php

namespace App\Http\Controllers;

use App\Models\Analysis_msg;
use App\Models\Ban_list;
use Exception;
use Illuminate\Http\Request;

class AnalysisMsgApiController extends Controller
{
    public function index()
    {
        try {
            $analysis_msg = Analysis_msg::all();
            return $analysis_msg;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'analysis_id' => 'required',
                'users_id' => 'required',
                'msg_content' => 'min:5|max:250|required'
            ]);
            if (Ban_list::where('users_id', $request->users_id)->exists()) {
                $ban = Ban_list::where('users_id', $request->users_id)->latest('date_end')->first();

                $date = date('Y-m-d');
                if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                    return response()->json([
                        "message" => "Ön nem hozhat létre üzenetet, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                    ], 400);
                }

            }
            Analysis_msg::create(array(
                'analysis_id' => $request->analysis_id,
                'users_id' => $request->users_id,
                'msg_content' => $request->msg_content
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az üzenetet!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Analysis_msg::where('analysis_id', $id)->exists()) {
                $analysis_msg = Analysis_msg::with('user:id,username')->where('analysis_id', $id)->get();
                return $analysis_msg;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'msg_content' => 'min:10|max:250|nullable'
            ]);
            if (Analysis_msg::where('id', $id)->exists()) {
                $analysis_msg = Analysis_msg::find($id);
                if (Ban_list::where('users_id', $analysis_msg->users_id)->exists()) {
                    $ban = Ban_list::where('users_id', $analysis_msg->users_id)->latest('date_end')->first();

                    $date = date('Y-m-d');
                    if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                        return response()->json([
                            "message" => "Sajnos nem változtathatja meg az üzenetet, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                        ], 400);
                    }

                }
                $analysis_msg->msg_content = is_null($request->msg_content) ? $analysis_msg->msg_content : $request->msg_content;
                $analysis_msg->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }

    }

    public function destroy($id)
    {
        try {
            $analysis_msg = Analysis_msg::find($id);
            if ($analysis_msg->exists()) {
                if (Ban_list::where('users_id', $analysis_msg->users_id)->exists()) {
                    $ban = Ban_list::where('users_id', $analysis_msg->users_id)->latest('date_end')->first();

                    $date = date('Y-m-d');
                    if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                        return response()->json([
                            "message" => "Sajnos nem törölheti az üzenetet, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                        ], 400);
                    }

                }
                $analysis_msg->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }

    }
}
