<?php

namespace App\Http\Controllers;

use App\Models\Ban_list;
use App\Models\Post_msg;
use Exception;
use Illuminate\Http\Request;

class PostMsgApiController extends Controller
{
    public function index()
    {
        try {
            $post_msg = Post_msg::all();
            return $post_msg;
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }

    }

    public function create(Request $request)
    {
        try {

            $request->validate([
                'users_id' => 'required',
                'posts_id' => 'required',
                'msg_content' => 'min:10|max:250|required'
            ]);
            if (Ban_list::where('users_id', $request->users_id)->exists()) {
                $ban = Ban_list::where('users_id', $request->users_id)->latest('date_end')->first();

                $date = date('Y-m-d');
                if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                    return response()->json([
                        "message" => "Ön nem hozhat létre üzenetet, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                    ], 400);
                }

            }
            Post_msg::create(array(
                'users_id' => $request->users_id,
                'posts_id' => $request->posts_id,
                'msg_content' => $request->msg_content,
                'msg_date' => date('Y-m-d H:i:s')
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az üzenetet!"
            ], 200);
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try {
            if (Post_msg::where('posts_id', $id)->exists()) {
                $post_msg = Post_msg::with('user:id,username')->where('posts_id', $id)->get();
                return $post_msg;
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'msg_content' => 'min:10|max:250|nullable'
            ]);
            if (Post_msg::where('id', $id)->exists()) {
                $post_msg = Post_msg::find($id);
                if (Ban_list::where('users_id', $post_msg->users_id)->exists()) {
                    $ban = Ban_list::where('users_id', $post_msg->users_id)->latest('date_end')->first();

                    $date = date('Y-m-d');
                    if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                        return response()->json([
                            "message" => "Sajnos nem változtathatja meg az üzenetet, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                        ], 400);
                    }

                }
                $post_msg->msg_content = is_null($request->msg_content) ? $post_msg->msg_content : $request->msg_content;

                $post_msg->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $post_msg = Post_msg::find($id);
            if (Ban_list::where('users_id', $post_msg->users_id)->exists()) {
                $ban = Ban_list::where('users_id', $post_msg->users_id)->latest('date_end')->first();

                $date = date('Y-m-d');
                if ($ban['date_end'] == $date || $ban['date_end'] > $date) {
                    return response()->json([
                        "message" => "Sajnos nem törölheti az üzenetet, mivel kitiltást kapott! Kitilátst vége: " . $ban['date_end']
                    ], 400);
                }

            }
            if ($post_msg->exists()) {
                $post_msg->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch (Exception $e) {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }
    }
}
