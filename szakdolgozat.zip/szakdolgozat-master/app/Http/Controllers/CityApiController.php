<?php

namespace App\Http\Controllers;

use App\Models\City;
use Exception;
use Illuminate\Http\Request;

class CityApiController extends Controller
{
    public function index()
    {
        try
        {
            $city = City::all();
            return $city;
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }
        
    }
    public function show($id)
    {
        try{
            if(City::where('id', $id)->exists())
            {
                $city = City::find($id);
                return $city;
            }
        }
        catch(Exception $e){
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

}
