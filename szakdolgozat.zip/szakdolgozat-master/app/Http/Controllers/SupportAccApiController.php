<?php

namespace App\Http\Controllers;

use App\Models\Support_acc;
use Exception;
use Illuminate\Http\Request;

class SupportAccApiController extends Controller
{
    public function index()
    {
        try
        {
            $support_acc = Support_acc::with('user:id,username')->get();
            return $support_acc;
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ALL)"
            ], 404);
        }
        
    }

    public function create(Request $request)
    {
        try
        {
            $request->validate([
                'users_id' => 'required',
                'support_id' => 'required'
            ]);

            Support_acc::create(array(
                'users_id' => $request->users_id,
                'support_id' => $request->support_id
            ));

            return response()->json([
                "message" => "Sikeresen létrehozta az üzenetet!"
            ], 200);
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen létrehozás! (CREATE)"
            ], 404);
        }
    }

    public function show($id)
    {
        try{
            if(Support_acc::where('support_id', $id)->exists())
            {
                $support_acc = Support_acc::with('user:id,username')->where('support_id', $id)->get();
                return $support_acc;
            }
        }
        catch(Exception $e){
            return response()->json([
                "message" => "Sikertelen lekérdezés! (ONE)"
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try
        {
            if(Support_acc::where('id', $id)->exists())
            {
                $support_acc = Support_acc::find($id);
                $support_acc->users_id = is_null($request->users_id) ? $support_acc->users_id : $request->users_id;
                $support_acc->save();

                return response()->json([
                    "message" => "Sikeresen frissítette az adatait!"
                ], 200);
            } 
            else 
            {
            return response()->json([
                    "message" => "Sikertelen frissítés!"
                ], 404);
            }
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen frissítés! (UPDATE)"
            ], 404);
        }
        
    }

    public function destroy($id)
    {
        try
        {
            $support_acc = Support_acc::find($id);
            if($support_acc->exists())
            {
                $support_acc->delete();
                return response()->json([
                    "message" => "Sikeres törlés!"
                ], 200);
            }
            else
            {
                return response()->json([
                    "message" => "Sikertelen törlés!"
                ], 404);
            }
        }
        catch(Exception $e)
        {
            return response()->json([
                "message" => "Sikertelen törlés! (DELETE)"
            ], 404);
        }
        
    }
}
