<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToUserAddressTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('user_address', function (Blueprint $table) {
            $table->foreign(['city_id'], 'FK__user_addr__city___4CA06362')->references(['id'])->on('city')->onUpdate('NO ACTION')->onDelete('NO ACTION');
            $table->foreign(['street_id'], 'FK__user_addr__stree__4D94879B')->references(['id'])->on('street')->onUpdate('NO ACTION')->onDelete('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('user_address', function (Blueprint $table) {
            $table->dropForeign('FK__user_addr__city___4CA06362');
            $table->dropForeign('FK__user_addr__stree__4D94879B');
        });
    }
}
