<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuizTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('quiz', function (Blueprint $table) {
            $table->integer('id', true);
            $table->integer('users_id');
            $table->char('quiz_one', 1);
            $table->char('quiz_two', 1);
            $table->char('quiz_three', 1);
            $table->char('quiz_four', 1);
            $table->char('quiz_five', 1);
            $table->char('quiz_six', 1);
            $table->char('quiz_seven', 1);
            $table->char('quiz_eight', 1);
            $table->char('quiz_nine', 1);
            $table->char('quiz_ten', 1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quiz');
    }
}
