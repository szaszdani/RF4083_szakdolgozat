<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToAnalysisMsgTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('analysis_msg', function (Blueprint $table) {
            $table->foreign(['users_id'], 'FK__analysis___users__46E78A0C')->references(['id'])->on('users')->onUpdate('NO ACTION')->onDelete('NO ACTION');
            $table->foreign(['analysis_id'], 'FK__analysis___analy__47DBAE45')->references(['id'])->on('analysis')->onUpdate('NO ACTION')->onDelete('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('analysis_msg', function (Blueprint $table) {
            $table->dropForeign('FK__analysis___users__46E78A0C');
            $table->dropForeign('FK__analysis___analy__47DBAE45');
        });
    }
}
