<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToSupportAnsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('support_ans', function (Blueprint $table) {
            $table->foreign(['users_id'], 'FK__support_a__users__5BE2A6F2')->references(['id'])->on('users')->onUpdate('NO ACTION')->onDelete('NO ACTION');
            $table->foreign(['support_id'], 'FK__support_a__suppo__5CD6CB2B')->references(['id'])->on('support')->onUpdate('NO ACTION')->onDelete('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('support_ans', function (Blueprint $table) {
            $table->dropForeign('FK__support_a__users__5BE2A6F2');
            $table->dropForeign('FK__support_a__suppo__5CD6CB2B');
        });
    }
}
