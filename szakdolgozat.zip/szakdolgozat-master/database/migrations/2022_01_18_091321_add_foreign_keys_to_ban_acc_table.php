<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToBanAccTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ban_acc', function (Blueprint $table) {
            $table->foreign(['users_id'], 'FK__ban_acc__users_i__49C3F6B7')->references(['id'])->on('users')->onUpdate('NO ACTION')->onDelete('NO ACTION');
            $table->foreign(['ban_list_id'], 'FK__ban_acc__ban_lis__4AB81AF0')->references(['id'])->on('ban_list')->onUpdate('NO ACTION')->onDelete('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ban_acc', function (Blueprint $table) {
            $table->dropForeign('FK__ban_acc__users_i__49C3F6B7');
            $table->dropForeign('FK__ban_acc__ban_lis__4AB81AF0');
        });
    }
}
