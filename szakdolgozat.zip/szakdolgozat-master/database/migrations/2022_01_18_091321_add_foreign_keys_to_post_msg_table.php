<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToPostMsgTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('post_msg', function (Blueprint $table) {
            $table->foreign(['users_id'], 'FK__post_msg__users___5441852A')->references(['id'])->on('users')->onUpdate('NO ACTION')->onDelete('NO ACTION');
            $table->foreign(['posts_id'], 'FK__post_msg__posts___5535A963')->references(['id'])->on('posts')->onUpdate('NO ACTION')->onDelete('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('post_msg', function (Blueprint $table) {
            $table->dropForeign('FK__post_msg__users___5441852A');
            $table->dropForeign('FK__post_msg__posts___5535A963');
        });
    }
}
