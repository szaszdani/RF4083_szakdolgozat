<?php

use Illuminate\Support\Facades\Route;

/* |-------------------------------------------------------------------------- | Web Routes |-------------------------------------------------------------------------- | | Here is where you can register web routes for your application. These | routes are loaded by the RouteServiceProvider within a group which | contains the "web" middleware group. Now create something great! | */

Route::get('/', function () {
    return view('welcome');
})->name("/")->middleware('web');

Route::get('/login', function () {
    return view('login');
});

Route::get('/adminpanel', function () {
    return view('admin');
});

Route::get('/registration', function () {
    return view('registration');
});

Route::get('/support', function () {
    return view('support');
});

Route::get('/cryptocurrencies', function () {
    return view('coins');
});

Route::get('/cryptocurrencies/coin={coin}', function () {
    return view('oneCoin');
});

Route::get('/watchlist', function () {
    return view('watchlist');
});

Route::get('/portfolio', function () {
    return view('portfolio');
});

Route::get('/forgot-password', function () {
    return view('forgot-password');
});

Route::get('reset-password/{token}', function () {
    return view('reset-password');
});

Route::get('news', function () {
    return view('news');
});

Route::get('complete-registration', function () {
    return view('complete-registration');
});

Route::get('verify', function () {
    return view('verifytwoauth');
});

Route::get('learning', function () {
    return view('learn');
});

Route::get('swap', function () {
    return view('crypto-swap');
});

Route::get('showTicket/{id}', function () {
    return view('one-ticket');
});

Route::get('settings', function () {
    return view('settings');
});

Route::get('forum', function () {
    return view('forums/forum');
});

Route::get('analysis', function () {
    return view('forums/analysis');
});

Route::get('forum/{id}', function () {
    return view('forums/one-forum');
});

Route::get('analysis/{id}', function () {
    return view('forums/one-analysis');
});

Route::get('vip', function () {
    return view('forums/vip-forum');
});

Route::get('post/{id}', function () {
    return view('forums/post');
});

Route::get('verifyEmail/{token}', function () {
    return view('user-verify');
});
