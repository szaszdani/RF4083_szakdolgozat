<?php

use App\Http\Controllers\AnalysisApiController;
use App\Http\Controllers\AnalysisMsgApiController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BanAccApiController;
use App\Http\Controllers\BanListApiController;
use App\Http\Controllers\ForumApiController;
use App\Http\Controllers\PortfolioApiController;
use App\Http\Controllers\PostMsgApiController;
use App\Http\Controllers\PostsApiController;
use App\Http\Controllers\QuizApiController;
use App\Http\Controllers\SupportAccApiController;
use App\Http\Controllers\SupportAnsApiController;
use App\Http\Controllers\SupportApiController;
use App\Http\Controllers\UserAddressApiController;
use App\Http\Controllers\UsersApiController;
use App\Http\Controllers\UserSecurityApiController;
use App\Http\Controllers\WatchlistApiController;
use Illuminate\Support\Facades\Route;

/* |-------------------------------------------------------------------------- | API Routes |-------------------------------------------------------------------------- | | Here is where you can register API routes for your application. These | routes are loaded by the RouteServiceProvider within a group which | is assigned the "api" middleware group. Enjoy building your API! | */

//Publikus API hívások, amelyhez nem kell auth
Route::group(['middleware' => 'throttle:api'], function() {
    Route::post('/register', [AuthController::class , 'register']);
    Route::post('/login', ['before' => 'csrf', AuthController::class , 'login']);
    Route::post('/forgot-password', [UsersApiController::class , 'forgotPassword']);
    Route::post('/reset-password', [UsersApiController::class , 'resetPassword']);
    Route::post('/createTicket', [SupportApiController::class , 'create']);
    Route::post('/verifyEmail', [AuthController::class , 'verifyEmail']);
    Route::put('/userVerify', [AuthController::class , 'userVerify']);
});


//Védett API hívások
Route::group(['middleware' => ['auth:sanctum'], 'throttle:api'], function () {
    //Kijelentkezés - megszűnik a token
    Route::post('/logout', [AuthController::class , 'logout']);

    //Google 2FA hívások
    Route::post('/gen', [AuthController::class , 'google2FA']);
    Route::post('/ver', [AuthController::class , 'verify2FA']);

    //Csak Admin hívások
    Route::group(['middleware' => ['admin']], function () {
            Route::get('/allUsers', [UsersApiController::class , 'index']);
            Route::get('/allForgotPassword', [UsersApiController::class , 'allForgotPassword']);
            Route::delete('/deleteUser/{id}', [UsersApiController::class , 'destroy']);
            Route::delete('/deleteForgotPassword/{email}', [UsersApiController::class , 'deleteForgotPassword']);

            Route::get('/allBanList', [BanListApiController::class , 'index']);
            Route::get('/oneBanList/{id}', [BanListApiController::class , 'show']);
            Route::post('/createBanList', [BanListApiController::class , 'create']);
            Route::put('/changeBanList/{id}', [BanListApiController::class , 'update']);
            Route::delete('/deleteBanList/{id}', [BanListApiController::class , 'destroy']);
            Route::get('/allBanAcc', [BanAccApiController::class , 'index']);

            Route::get('/allTicketAcc', [SupportAccApiController::class , 'index']);
            Route::post('/createTicketAcc', [SupportAccApiController::class, 'create']);
        }
    );
    

    //Users hívások
    Route::get('/userID', [UsersApiController::class , 'getUserId']);
    Route::get('/users/{id}', [UsersApiController::class , 'show']);
    Route::put('/updateUser/{id}', [UsersApiController::class , 'update']);

    //User_address hívások
    Route::get('/userAddress/{id}', [UserAddressApiController::class , 'show']);
    Route::put('/updateAddress/{id}', [UserAddressApiController::class , 'update']);

    //User_security hívások
    Route::get('/userKey', [UserSecurityApiController::class , 'getSecretKey']);
    Route::get('/sec/{id}', [UserSecurityApiController::class , 'show']);
    Route::put('/updateSecurity/{id}', [UserSecurityApiController::class , 'update']);

    //Portfolio hívások
    Route::get('/portfolio/{id}', [PortfolioApiController::class , 'show']);
    Route::post('/createPortfolio', [PortfolioApiController::class , 'create']);
    Route::put('/portfolioChange', [PortfolioApiController::class , 'update']);
    Route::delete('/portfolioDelete', [PortfolioApiController::class , 'destroy']);

    //Forum hívások
    Route::get('/allForum', [ForumApiController::class , 'index']);
    Route::get('/oneForum/{id}', [ForumApiController::class , 'show']);
    Route::post('/createForum', [ForumApiController::class , 'create']);
    Route::put('/changeForum/{id}', [ForumApiController::class , 'update']);
    Route::delete('/deleteForum/{id}', [ForumApiController::class , 'destroy']);

    //Post hívások
    Route::get('/allPost', [PostsApiController::class , 'index']);
    Route::get('/onePost/{id}', [PostsApiController::class , 'show']);
    Route::get('/onePerForum/{id}', [PostsApiController::class , 'showPerForum']);
    Route::post('/createPost', [PostsApiController::class , 'create']);
    Route::post('/changePost/{id}', [PostsApiController::class , 'update']);
    Route::delete('/deletePost/{id}', [PostsApiController::class , 'destroy']);

    //Post_msg hívások
    Route::get('/allPostMsg', [PostMsgApiController::class , 'index']);
    Route::get('/onePostMsg/{id}', [PostMsgApiController::class , 'show']);
    Route::post('/createPostMsg', [PostMsgApiController::class , 'create']);
    Route::put('/changePostMsg/{id}', [PostMsgApiController::class , 'update']);
    Route::delete('/deletePostMsg/{id}', [PostMsgApiController::class , 'destroy']);

    //Analysis hívások
    Route::get('/allAnalysis', [AnalysisApiController::class , 'index']);
    Route::get('/oneAnalysis/{id}', [AnalysisApiController::class , 'show']);
    Route::post('/createAnalysis', [AnalysisApiController::class , 'create']);
    Route::post('/changeAnalysis/{id}', [AnalysisApiController::class , 'update']);
    Route::delete('/deleteAnalysis/{id}', [AnalysisApiController::class , 'destroy']);

    //Analysis_msg hívások
    Route::get('/allAnalysisMsg', [AnalysisMsgApiController::class , 'index']);
    Route::get('/oneAnalysisMsg/{id}', [AnalysisMsgApiController::class , 'show']);
    Route::post('/createAnalysisMsg', [AnalysisMsgApiController::class , 'create']);
    Route::put('/changeAnalysisMsg/{id}', [AnalysisMsgApiController::class , 'update']);
    Route::delete('/deleteAnalysisMsg/{id}', [AnalysisMsgApiController::class , 'destroy']);

    //Support hívások
    Route::get('/allTicket', [SupportApiController::class , 'index']);
    Route::get('/oneTicket/{id}', [SupportApiController::class , 'show']);
    Route::get('/userTicket/{id}', [SupportApiController::class , 'showByUserId']);
    Route::put('/changeTicket/{id}', [SupportApiController::class , 'update']);
    Route::delete('/deleteTicket/{id}', [SupportApiController::class , 'destroy']);

    //Support_ans hívások
    Route::get('/allTicketAnswers', [SupportAnsApiController::class , 'index']);
    Route::get('/oneTicketAnswer/{id}', [SupportAnsApiController::class , 'show']);
    Route::post('/createTicketAnswer', [SupportAnsApiController::class , 'create']);
    Route::put('/changeTicketAnswer', [SupportAnsApiController::class , 'update']);
    Route::delete('/deleteTicketAnswer/{id}', [SupportAnsApiController::class , 'destroy']);

    //Watchlist hívások
    Route::get('/watchlistAll', [WatchlistApiController::class , 'index']);
    Route::get('/watchlist/{id}', [WatchlistApiController::class , 'show']);
    Route::post('/createWatchlistItem', [WatchlistApiController::class , 'create']);
    Route::put('/watchlistChange', [WatchlistApiController::class , 'update']);
    Route::delete('/watchlistDelete', [WatchlistApiController::class , 'destroy']);

    //Quiz hívások
    Route::get('/userQuiz/{id}', [QuizApiController::class, 'show']);
    Route::put('/updateQuiz/{id}', [QuizApiController::class , 'update']);
});
