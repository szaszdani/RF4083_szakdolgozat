<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta id ="meta_token" content="{{ csrf_token() }}" />
    <title>KriptoBázis - Kriptovaluta lista</title>
    <link href="/css/app.css" rel="stylesheet">
    <style>
        .coinIMG{
            width: 25px;
        }

        .search input {
            background-color: white;
            border-style: solid;
            border-radius: 2px;
            border-top-right-radius: 0px;
            border-bottom-right-radius: 0px;
            font-size: 18px;
            padding: 15px;
            height: 30px;
            width: 300px;
        }

        input:focus {
            outline: none;
        }
        .searchIcon svg {
            font-size: 35px;
        }

        .dataResult {
            margin-top: 5px;
            width: 300px;
            height: 200px;
            background-color: white;
            box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
            overflow: hidden;
            overflow-y: auto;
        }

        .dataResult::-webkit-scrollbar {
            display: none;
        }

        .dataResult .dataItem {
            width: 100%;
            height: 50px;
            display: flex;
            align-items: center;
            color: black;
        }

        .dataItem p {
            margin-left: 10px;
        }

        a {
            text-decoration: none;
        }

        a:hover {
            background-color: lightgrey;
        }

        #clearBtn {
            cursor: pointer;
        }
    </style>

</head>

<body>
    <div id='navbar'></div>
    <div id="coins"></div>
    <div id='footer'></div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <script src="{{ mix('js/app.js') }}" ></script>
</body>
</html>
