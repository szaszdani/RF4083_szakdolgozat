<h1>KriptoBázis</h1>

<p>{!! $body !!}</p>
<br>
<a href="{{ $action_link }}">Kattintson ide</a>