<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta id="meta_token" content="{{ csrf_token() }}" />
        <title>KriptoBázis - Quiz</title>
        <link href="/css/app.css" rel="stylesheet">
    </head>
    <style>

        .app {
            background-color: white;
            width: 450px;
            min-height: 200px;
            height: min-content;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 10px 10px 42px 0px rgba(0, 0, 0, 0.75);
            display: flex;
            justify-content: space-evenly;
        }

        .score-section {
            padding-top: 25px;
            font-size: 24px;
            align-items: center;
        }

        .question-section {
            width: 100%;
            position: relative;
        }

        .question-count {
            margin-bottom: 20px;
        }

        .question-count span {
            font-size: 28px;
        }

        .question-text {
            margin-bottom: 12px;
        }
        .answer-section {
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

    </style>
    <body>
        <div id="navbar"></div>
        <div id="quiz"></div>
        <div class="pt-5" id="footer"></div>
        <script src="{{ mix('js/app.js') }}" ></script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    </body>
</html>
