import axios from 'axios';
import React, {useState, useEffect} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import { config, simpleConfig, getUserId } from '../Commands/Commands';

function Support() {

    const [data, setData] = useState(null);
    const [userId, setUserId] = useState(0);
    const [email, setEmail] = useState("");
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");

    const sendWithoutAuth = () => {
        const formData = new FormData();
        
        if(document.getElementById('text_file').files[0])
        {
            formData.append('img', document.getElementById('text_file').files[0]);
        }
        formData.append('email', email);
        formData.append('title', title);
        formData.append('content', content);
        
        axios.post('http://localhost:8000/api/createTicket', formData, config()).then((res) => {
            swal({
                title: "Segítségkérés",
                text: "Sikeres létrehozás!",
                icon: "success"
            }).then(() => location.reload());
        }).catch((err) => {
            swal({
                title: "Segítségkérés",
                text: "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg!",
                icon: "error"
            });
        });
    }

    if(sessionStorage.getItem('loginToken'))
    {
        useEffect(() => {
            
            getUserId(simpleConfig()).then((response) => {
                var id = response.data.id;
                setUserId(id);
                axios.get('http://localhost:8000/api/userTicket/'+id, simpleConfig()).then((response) => {
                    setData(response.data);
                });
            }).catch((error) => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }, []);

        const redirectToTicket = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var ticket = data[0].innerHTML;
            window.location.href = "http://localhost:8000/showTicket/"+ticket;
        }

        const sendWithAuth = () => {
            const formData = new FormData();
            
            if(document.getElementById('text_file').files[0])
            {
                formData.append('img', document.getElementById('text_file').files[0]);
            }
            formData.append('email', email);
            formData.append('title', title);
            formData.append('content', content);
            formData.append('users_id', userId);
            axios.post('http://localhost:8000/api/createTicket', formData, simpleConfig()).then((res) => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikeres létrehozás!",
                    icon: "success"
                }).then(() => location.reload());
            }).catch((err) => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg!",
                    icon: "error"
                });
            });
        }

        return (
            <div className="pt-5 container" align="center">
                <p className='display-2 pt-5 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Segítség</p>
                <p className='fs-3 pb-5'>Probléma esetén forduljon hozzánk!</p>
                <button className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#all" aria-expanded="false" aria-controls="collapseExample">
                    Az összes segítségkérésem
                </button>
                <div className="collapse p-5" id="all">
                    <div className="card card-body">
                        <div className='table-responsive'>
                            <table className="table table-fluid" id="myTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Cím</th>
                                        <th>E-mal cím</th>
                                        <th>Létrehozás ideje</th>
                                        <th>Állapot</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {!data ? <tr align="center"><td colSpan="8">Ön nem igényelt segítséget még!</td></tr> : data.map((n, idx) =>
                                        (<tr id={idx} key={idx}>
                                            <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                            <td className="row-data align-middle" key={n.title}>{n.title}</td>
                                            <td className="row-data align-middle" key={n.email}>{n.email}</td>
                                            <td className="row-data align-middle" key={n.created_date}>{n.created_date}</td>
                                            <td className="row-data align-middle" key={n.done}>{n.done == 0 ? "Nyitva" : "Lezárva"}</td>
                                            <td><button onClick={(e) => redirectToTicket(e)} type="button" className="btn btn-outline-warning">Megtekintés</button></td>
                                        </tr>))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="form-group pb-5 pt-5">
                    <label>E-mail cím:</label>
                    <input id="email" onChange={(e) => {setEmail(e.target.value)}} className="form-control" type="text" />
                    <small className="form-text text-muted">
                        Valós e-mail címet adjon meg!
                    </small>
                </div>
                <div className="form-group pb-3">
                    <label>Cím:</label>
                    <input id="text_heading" onChange={(e) => {setTitle(e.target.value)}} className="form-control" type="text" />
                    <small className="form-text text-muted">
                        5-20 karakter között legyen a cím!
                    </small>
                </div>
                <div className="form-group pb-3">
                    <label>Probléma kifejtése:</label>
                    <textarea id="text_msg" onChange={(e) => {setContent(e.target.value)}} className="form-control" rows="5" />
                    <small className="form-text text-muted">
                        10-1000 karakterszám között szerepeljen az üzenet
                    </small>
                </div>
                <div className="form-group pb-3">
                    <label>Kép:</label>
                    <input id="text_file" className="form-control" type="file" />
                    <small className="form-text text-muted">
                        Elfogadott típusok: PNG, JPG, JPEG
                    </small>
                </div>
                <button onClick={() => sendWithAuth()} className="btn btn-outline-warning">Küldés</button>
            </div>
        );
    }
    else
    {
        return(
            <div className='container pt-5' align="center">
                <p className='display-2 pt-5 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Segítség</p>
                <p className='fs-3 pb-5'>Probléma esetén forduljon hozzánk!</p>
                <div className="form-group pb-3">
                    <label>E-mail cím:</label>
                    <input id="email" onChange={(e) => {setEmail(e.target.value)}} className="form-control" type="text" />
                    <small className="form-text text-muted">
                        Valós e-mail címet adjon meg!
                    </small>
                </div>
                <div className="form-group pb-3">
                    <label>Cím:</label>
                    <input id="text_heading" onChange={(e) => {setTitle(e.target.value)}} className="form-control" type="text" />
                    <small className="form-text text-muted">
                        5-20 karakter között legyen a cím!
                    </small>
                </div>
                <div className="form-group pb-3">
                    <label>Probléma kifejtése:</label>
                    <textarea id="text_msg" onChange={(e) => {setContent(e.target.value)}} className="form-control" rows="5" />
                    <small className="form-text text-muted">
                        10-1000 karakterszám között szerepeljen az üzenet
                    </small>
                </div>
                <div className="form-group pb-3">
                    <label>Kép:</label>
                    <input id="text_file" className="form-control" type="file" />
                    <small className="form-text text-muted">
                        Elfogadott típusok: PNG, JPG, JPEG
                    </small>
                </div>
                <button onClick={() => sendWithoutAuth()} className="btn btn-outline-warning">Küldés</button>
            </div>
        );
    }
}

export default Support;

if (document.getElementById('support')) {
    ReactDOM.render(<Support />, document.getElementById('support'));
}
