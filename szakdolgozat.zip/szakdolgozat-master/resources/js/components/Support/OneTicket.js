import axios from 'axios';
import React, {useState, useEffect} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import { simpleConfig, getUserId, isLoggedIn } from '../Commands/Commands';

function OneTicket() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [answers, setAnswers] = useState(null);
        const [load, setLoad] = useState(true);
        const [userId, setUserId] = useState(0);
        const [content, setContent] = useState("");
        const path = window.location.pathname;
        const ticketId = path.substring(12);   
        useEffect(() => {

            getUserId(simpleConfig()).then((response) => setUserId(response.data.id)).catch((err) => console.log(err));

            axios.get('http://localhost:8000/api/oneTicket/'+ticketId, simpleConfig()).then((response) => {
                setData([response.data]);
                if(!response.data)
                {
                    setLoad(false);
                }
            }).catch((err) => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });

            axios.get('http://localhost:8000/api/oneTicketAnswer/'+ticketId, simpleConfig()).then((response) => {
                setAnswers(response.data);
            }).catch((err) => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            })
        }, []);

        const createMessage = () => {
            var formData = new FormData();
            formData.append('users_id', userId);
            formData.append('support_id', ticketId);
            formData.append('content', content);
            axios.post('http://localhost:8000/api/createTicketAnswer', formData, simpleConfig()).then(() => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikeres üzenet létrehozás!",
                    icon: "success"
                }).then(() => location.reload());
            }).catch(() => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen üzenet létrehozás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg!",
                    icon: "error"
                });
            });
        }

        return (
            <div className="pt-5 container" align="center">
                {!load ? <h1>Segítségkérés nem található!</h1> : !data ? <h1 align="center">Betöltés...</h1> : data.map((n, idx) =>
                    (<div key={idx}>
                        <p className='display-2 pt-5 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Segítség</p>
                        <p className='fs-3 text-warning'>Cím:</p>
                        <p className='fs-4'>{n.title}</p>
                        <p className='fs-3 text-warning'>Leírás:</p>
                        <p className='fs-4'>{n.content}</p>
                        <p className='fs-3 text-warning'>Kép:</p>
                        {n.support_img != null ? <img src={"http://localhost:8000/storage/images/support/"+ n.support_img}></img> : <p className='fs-4'>Nincsen csatolt kép a segítségkéréshez.</p>}
                        <p className='fs-3 text-warning'>Állapot:</p>
                        {n.done == 0 ? <p className='fs-3 text-success'>Nyitva</p> : <p className='fs-3 text-danger'>Zárva</p>}

                        <div className='pt-5 pb-5'>
                            <p className='fs-4'>Üzenetek</p>
                            {n.done == 0 ? <button className='btn btn-outline-warning' data-toggle="modal" data-target="#createModal">Új üzenet létrehozása</button> : <p className='fs-4'>Már nem tud létrehozni új üzenetet!</p>}
                        </div>
                        <div className='table-responsive'>
                            <table className="table table-fluid" id="myTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Létrehozó</th>
                                        <th>Üzenet ideje</th>
                                        <th>Üzenet tartalma</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {!answers ? <tr align="center"><td colSpan="8">Jelenleg még nem érkezett üzenet ehhez a segítségkéréshez!</td></tr> : answers.map((n, idx) =>
                                        (<tr id={idx} key={idx}>
                                            <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                            <td className="row-data align-middle" >{n.user.username}</td>
                                            <td className="row-data align-middle" key={n.created_date}>{n.created_date}</td>
                                            <td className="row-data align-middle" key={n.content}>{n.content}</td>
                                        </tr>))}
                                </tbody>
                            </table>
                        </div>
                        <div className="modal fade" id="createModal"  role="dialog" aria-labelledby="createModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="createModalLabel">Üzenet létrehozása</h5>
                                </div>
                                <div className="modal-body">
                                    <p>Töltse ki az alábbi mezőt az üzenet küldéséhez!</p>
                                    <div className="form-group pb-3">
                                        <label>Üzenet:</label>
                                        <input id="newText" onChange={(e) => {setContent(e.target.value)}} className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            Minimum 10 karakter legyen az üzenet és maximum 1000.
                                        </small>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={() => createMessage()} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>))
                }
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    
}

export default OneTicket;

if (document.getElementById('one-ticket')) {
    ReactDOM.render(<OneTicket />, document.getElementById('one-ticket'));
}
