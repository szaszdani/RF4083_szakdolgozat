import axios from 'axios';
import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom';
import { simpleConfig, isLoggedIn } from './Commands/Commands';


function Navbar() {

    let token = document.getElementById('meta_token').getAttribute('content');
    const [isAdmin, setAdmin] = useState(false);
    
    if(isLoggedIn())
    {
        useEffect(() => {
        
            axios.get('http://localhost:8000/api/userID', simpleConfig()).then((response) => {
                axios.get('http://localhost:8000/api/users/'+response.data.id, simpleConfig()).then((res) => {
                    if(res.data.user_rank == "3")
                    {
                        setAdmin(true);
                    }
                }).catch((err) => {
                    console.log(err);
                })
            }).catch((err) => {
                console.log(err);
            });
            
            
        }, []);
    
        const logout = (e) => {
            e.preventDefault();
    
            async function fetchData()
            {
               
                axios.post('http://localhost:8000/api/logout', {}, simpleConfig()).then((response) => {
                    sessionStorage.clear();
                    window.location.href = "http://localhost:8000/";
                });
            }
            fetchData();
        }
        return(
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom fs-5">
                    <a className="p-2 fs-5 navbar-brand" href="http://localhost:8000/">Kripto<span className="text-warning">Bázis</span></a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="justify-content-end collapse navbar-collapse" id="navbarNavDropdown">
                        <ul className="navbar-nav">
                            <li className="nav-item active">
                                <a className="nav-link" href="http://localhost:8000/">Főoldal</a>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Kriptovaluta kezelés
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a className="dropdown-item" href="http://localhost:8000/cryptocurrencies">Kriptovaluták listája</a>
                                    <a className="dropdown-item" href="http://localhost:8000/portfolio">Portfolió</a>
                                    <a className="dropdown-item" href="http://localhost:8000/watchlist">Figyelőlista</a>
                                    <a className="dropdown-item" href="http://localhost:8000/swap">SWAP</a>
                                </div>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Elemzések
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="http://localhost:8000/forum">Fórum</a>
                                    <a className="dropdown-item" href="http://localhost:8000/analysis">Felhasználói elemzések</a>
                                    <a className="dropdown-item" href="http://localhost:8000/vip">Előfizetői részleg</a>
                                </div>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:8000/news">Hírek</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:8000/learning">Tanulás</a>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Beállítások
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a className="nav-link" href="http://localhost:8000/settings">Fiók beállítások</a>
                                    {isAdmin ? <a className="nav-link" href="http://localhost:8000/adminpanel">ADMIN</a>: <></>}
                                    <a className="nav-link" href="http://localhost:8000/support">Segítség</a>
                                    <a className="nav-link" href="#" onClick={logout}>Kijelentkezés</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>

        );
    }
    else
    {
        return(
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom fs-5">
                    <a className="p-2 fs-5 navbar-brand" href="http://localhost:8000/">Kripto<span className="text-warning">Bázis</span></a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="justify-content-end collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item active">
                                <a className="nav-link" href="http://localhost:8000/">Főoldal</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:8000/login">Bejelentkezés</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:8000/registration">Regisztráció</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="http://localhost:8000/support">Segítség</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        );
    }
}

export default Navbar;

if (document.getElementById('navbar')) {
    ReactDOM.render(<Navbar />, document.getElementById('navbar'));
}
