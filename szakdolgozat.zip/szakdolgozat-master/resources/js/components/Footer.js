import React from 'react';
import ReactDOM from 'react-dom';

function Footer() {

    return(
        <footer className="mt-auto bg-light border-top text-center p-3">
            <p className="pt-3">Minden jog fenntartva - 2022 Kripto<span className="text-warning">Bázis</span></p>
        </footer>
    );

}

export default Footer;

if (document.getElementById('footer')) {
    ReactDOM.render(<Footer />, document.getElementById('footer'));
}
