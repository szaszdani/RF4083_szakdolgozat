import axios from 'axios';
import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import { isLoggedIn } from '../Commands/Commands';

function Registration() {

    if(!isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [username, setUsername] = useState("");
        const [password, setPassword] = useState("");
        const [passwordAgain, setPasswordAgain] = useState("");
        const [email, setEmail] = useState("");
        const [zipcode, setZipcode] = useState("");
        const [city, setCity] = useState("");
        const [street, setStreet] = useState("");
        const [hnumber, setHNumber] = useState("");
    
        let token = document.getElementById('meta_token').getAttribute('content');
    
        const handleSubmit = (e) => {
            e.preventDefault();
            if(password == passwordAgain)
            {
                const body = {
                    'username': username, 
                    'pwd':password,
                    'email' : email,
                    'zipcode': zipcode,
                    'city_name': city,
                    'street_name': street,
                    'house_number': hnumber
                };
                    let config = {
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                        }
                    }
                axios.post('http://localhost:8000/api/register', body, config).then((response) => {
                    axios.post('http://localhost:8000/api/verifyEmail', {'id': response.data.id, 'email': response.data.email}, config).then(() => {
                        swal({
                            title: "Regisztráció",
                            text: "Sikeres regisztráció! A megadott e-mail címre elküldtünk egy megerősítő e-mail-t!",
                            icon: "success",
                            button: "Bezárás"
                        }).then(() => window.location.href = "http://localhost:8000");
                    }).catch(() => {
                        swal({
                            title: "Regisztráció",
                            text: "Sikertelen regisztráció!",
                            icon: "error",
                            button: "Bezárás"
                        });
                    });
                }).catch((err) => {
                    swal({
                        title: "Regisztráció",
                        text: err.response.data.message,
                        icon: "error",
                        button: "Bezárás"
                    });
                });
            }
            else
            {
                swal({
                    title: "Regisztráció",
                    text: "A megadott jelszavak nem egyeznek!",
                    icon: "error",
                    button: "Bezárás"
                });
            }
            
        }

        return(
            <div className='container pt-5' align="center">
                <p className='display-2 pt-3'>Kripto<span className='text-warning'>Bázis</span> - Regisztráció</p>
                <p className='fs-3'>Üdvözöljük!<br/>Fiók létrehozásához kérem töltse ki az alábbi mezőket!</p>
                <form className='pt-5' onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className='h2 text-warning'>Felhasználónév:</label>
                        <div className='col-sm-3'>
                            <input type="text" className="form-control"  placeholder="pelda.felhasznalonev" value={username} onChange={(e) => {setUsername(e.target.value)}} />
                            <small className="form-text text-muted">
                                A felhasználónév 6-16 karakter között kell szerepeljen.
                            </small>
                        </div>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>Jelszó:</label>
                        <div className='col-sm-3'>
                            <input type="password" className="form-control" placeholder="pelda.jelszo" value={password} onChange={(e) => {setPassword(e.target.value)}}/>
                            
                            <small className="form-text text-muted">
                                A jelszó 6-15 karakter között kell szerepeljen. Tartalmazzon egy nagy betűt és számot is!
                            </small>
                        </div>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>Jelszó mégegyszer:</label>
                        <div className='col-sm-3'>
                            <input type="password" className="form-control" placeholder="pelda.jelszo" value={passwordAgain} onChange={(e) => {setPasswordAgain(e.target.value)}}/>
                        </div>
                        <small className="form-text text-muted">
                                Ugyanazt a jelszót írja be, amit az előbb adott meg!
                        </small>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>E-mail cím:</label>
                        <div className='col-sm-3'>
                            <input type="text" className="form-control" placeholder="pelda.email@gmail.com" value={email} onChange={(e) => {setEmail(e.target.value)}}/>
                        </div>
                        <small className="form-text text-muted">
                                Kérem adja meg az e-mail címét!
                        </small>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>Irányítószám:</label>
                        <div className='col-sm-3'>
                            <input type="number" className="form-control" placeholder="7150" value={zipcode} onChange={(e) => {setZipcode(e.target.value)}}/>
                        </div>
                        <small className="form-text text-muted">
                                Kérem az irányítószám megadásakor csak szám karaktereket alkalmazzon!
                        </small>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>Város:</label>
                        <div className='col-sm-3'>
                            <input type="text" className="form-control" placeholder="Példa város" value={city} onChange={(e) => {setCity(e.target.value)}}/>
                        </div>
                        <small className="form-text text-muted">
                                Kérem csak a város nevét adja meg!
                        </small>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>Utca:</label>
                        <div className='col-sm-3'>
                            <input type="text" className="form-control" placeholder="Példa utca" value={street} onChange={(e) => {setStreet(e.target.value)}}/>
                        </div>
                        <small className="form-text text-muted">
                                Kérem csak az utca nevét adja meg a házszám nélkül!
                        </small>
                    </div>
                    <div className="form-group pt-2" > 
                        <label className='h2 text-warning'>Házszám:</label>
                        <div className='col-sm-3'>
                            <input type="number" className="form-control" placeholder="29" value={hnumber} onChange={(e) => {setHNumber(e.target.value)}}/>
                        </div>
                        <small className="form-text text-muted">
                                Kérem adja meg a házszámot! (Emelet és ajtószám nélkül!)
                        </small>
                    </div>
                    <input type="hidden" name="_token" value={token} />
                    <div className='pt-3'>
                        <button type="submit" className="btn btn-warning"><span className='text-white fs-5 fw-bold'>Regisztráció</span></button>
                    </div>            
                </form>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    
}

export default Registration;

if (document.getElementById('regForm')) {
    ReactDOM.render(<Registration />, document.getElementById('regForm'));
}
