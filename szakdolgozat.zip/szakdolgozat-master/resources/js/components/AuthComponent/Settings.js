import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import VerifyButton from '@passbase/button/react';
import { isLoggedIn, simpleConfig, getUserId } from '../Commands/Commands';

function Settings() {
    if(isLoggedIn())
    {
        const [userData, setUserData] = useState(null);
        const [userAddress, setUserAddress] = useState(null);
        const [userSecurity, setUserSecurity] = useState(null);
        const [kyc, setKYC] = useState(false);
        const [data, setData] = useState(false);
       
        useEffect(() => {
            getUserId(simpleConfig()).then((response) => {
                var id = response.data.id;
                axios.get('http://localhost:8000/api/users/'+id, simpleConfig()).then((response) => {
                    setUserData([response.data]);
                    axios.get('http://localhost:8000/api/userAddress/'+id, simpleConfig()).then((response) => {
                        setUserAddress([response.data]);
                        axios.get('http://localhost:8000/api/sec/'+id, simpleConfig()).then((response) => {
                            setUserSecurity(response.data);
                            setData(true);
                            id = response.data[0]["id"];
                            if(response.data[0]["kyc"] != "0")
                            {
                                axios.get('https://api.passbase.com/verification/v1/identities/'+response.data[0]["kyc"], {headers: {"X-API-KEY" : "mQWFWaDPqaFSyC2HMas7XVu4hD74j1AW6L87Ma6SVbnIrUE2hzNar2SBSBUzrUut40J0JfzjEFdbFLFWrY5Ww15yJJGSG61jLM9JFGNVaW4a0xGD5W9NXvX3POKpA3jw"}}).then((res) => {
                                    if(res.data.status == "approved")
                                    {
                                        setKYC(true);
                                    }
                                    else if(res.data.status == "declined")
                                    {
                                        axios.put('http://localhost:8000/api/updateSecurity/'+id, {'kyc': 0}, simpleConfig()).then(() => {
                                            swal({
                                                title: "KYC",
                                                text: "Sajnos nem fogadtuk el a KYC beállítását, kérem probálkozzon újra!",
                                                icon: "error"
                                            }).then(() => {
                                                location.reload();
                                            });
                                        }).catch((err) => {
                                            swal({
                                                title: "KYC",
                                                text: "Hiba történt a beállítás során!",
                                                icon: "error"
                                            });
                                        });
                                    }
                                }).catch((err) => {
                                    console.log(err);
                                });
                            }
                        }).catch((err) => {
                            swal({
                                title: "Lekérdezés",
                                text: "Sikertelen lekérdezés (SECURITY)!",
                                icon: "error",
                                button: "Bezárás"
                            });
                        });
                    }).catch((err) => {
                        swal({
                            title: "Lekérdezés",
                            text: "Sikertelen lekérdezés (ADDRESS)!",
                            icon: "error",
                            button: "Bezárás"
                        });
                    });
                }).catch((err) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés (DATA)!",
                        icon: "error",
                        button: "Bezárás"
                    });
                });
            }).catch((err) => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés (ID)!",
                    icon: "error",
                    button: "Bezárás"
                });
            });
        }, []);
    
        const changeAddress = () => {
            var body = {
                'zipcode': document.getElementById('newZipcode').value,
                'city_name': document.getElementById('newCityName').value,
                'street_name': document.getElementById('newStreetName').value,
                'house_number': document.getElementById('newHouseNumber').value
            };
            axios.put('http://localhost:8000/api/updateAddress/'+ userAddress[0]["id"], body, simpleConfig()).then(() => {
                swal({
                    title: "Lakcím változtatás",
                    text: "Sikeresen megváltoztatta a lakcímét!",
                    icon: "success",
                    button: "Bezárás"
                }).then(() => {
                    location.reload();
                });
            }).catch((err) => {
                swal({
                    title: "Lakcím változtatás",
                    text: "Sikertelen változtatás! Kérem ellenőrizze, hogy mindent helyesen adott-e meg!",
                    icon: "error",
                    button: "Bezárás"
                });
            });
        }
    
        const changeUsername = () => {
            if(userSecurity[0]["fa"] != "0")
            {
                swal({
                    text: 'Adja meg a kétlépcsős azonosítóját:',
                    content: {
                        element: "input",
                        attributes: {
                            type: "number",
                        },
                    },
                    button: {
                      text: "Tovább",
                    }
                  }).then((content) => {
                      if(content)
                      {
                        var body = {
                            'inputCode' : content,
                            'secretKey' : userSecurity[0]["fa"],
                        };
                        axios.post('http://localhost:8000/api/ver', body, simpleConfig()).then(() => {
                            swal({
                                text: 'Adja meg az új felhasználónevét (5-15 karakter között):',
                                content: "input",
                                button: {
                                    text: "Mentés",
                                }
                            }).then((content) => {
                                if(content)
                                {
                                    body = {
                                        'username': content
                                    }
                                    axios.put('http://localhost:8000/api/updateUser/'+userData[0]['id'], body, simpleConfig()).then(() => {
                                        swal({
                                            title: "Felhasználónév változtatás",
                                            text: "Sikeres változtatás!",
                                            icon: "success"
                                        }).then(() => {
                                            location.reload();
                                        });
                                    }).catch((err) => {
                                        swal({
                                            title: "Felhasználónév változtatás",
                                            text: err.response.data.message,
                                            icon: "error"
                                        });
                                    });
                                }
                                
                            });
                        }).catch((err) => {
                            swal({
                                title: "Felhasználónév változtatás",
                                text: "Sikertelen változtatás!",
                                icon: "error"
                            });
                        });
                      }
                });
            }
            else
            {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Kérem először állítsa be a kétlépcsős azonosítást!",
                    icon: "error"
                });
            }
            
        }
    
        const changeEmail = () => {
            if(userSecurity[0]["fa"] != "0")
            {
                swal({
                    text: 'Adja meg a kétlépcsős azonosítóját:',
                    content: {
                        element: "input",
                        attributes: {
                            type: "number",
                        },
                    },
                    button: {
                      text: "Tovább",
                    }
                  }).then((content) => {
                      if(content)
                      {
                            var body = {
                                'inputCode' : content,
                                'secretKey' : userSecurity[0]["fa"],
                            };
                            axios.post('http://localhost:8000/api/ver', body, simpleConfig()).then(() => {
                                swal({
                                    text: 'Adja meg az új e-mail címét:',
                                    content: "input",
                                    button: {
                                        text: "Mentés",
                                    }
                                }).then((content) => {
                                    if(content)
                                    {
                                        body = {
                                            'email': content
                                        }
                                        axios.put('http://localhost:8000/api/updateUser/'+userData[0]['id'], body, simpleConfig()).then(() => {
                                            swal({
                                                title: "E-mail cím változtatás",
                                                text: "Sikeres változtatás!",
                                                icon: "success"
                                            }).then(() => {
                                                location.reload();
                                            });
                                        }).catch((err) => {
                                            swal({
                                                title: "E-mail cím változtatás",
                                                text: err.response.data.message,
                                                icon: "error"
                                            });
                                        });
                                    }
                                    
                                });
                            }).catch((err) => {
                                swal({
                                    title: "E-mail cím változtatás",
                                    text: "Sikertelen változtatás!",
                                    icon: "error"
                                });
                            });
                      }
                    
                });
            }
            else
            {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Kérem először állítsa be a kétlépcsős azonosítást!",
                    icon: "error"
                });
            }
            
        }
        const changePassword = () => {
            swal({
                text: 'Adja meg az új jelszavát (6-15 karakter között):',
                content: {
                    element: "input",
                    attributes: {
                        type: "password",
                    },
                },
                button: {
                  text: "Tovább",
                }
            }).then((content) => {
                if(content)
                {
                    var pw = content;
                    swal({
                        text: 'Adja meg az új jelszavát mégegyszer:',
                        content: {
                            element: "input",
                            attributes: {
                                type: "password",
                            },
                        },
                        button: {
                            text: "Mentés",
                        }
                    }).then((content) => {
                        if(content == pw)
                        {
                            var body = {
                                'pwd': content
                            }
                            axios.put('http://localhost:8000/api/updateUser/'+userData[0]['id'], body, simpleConfig()).then(() => {
                                swal({
                                    title: "Jelszó változtatás",
                                    text: "Sikeres változtatás!",
                                    icon: "success"
                                }).then(() => {
                                    location.reload();
                                });
                            }).catch((err) => {
                                swal({
                                    title: "Jelszó változtatás",
                                    text: err.response.data.message,
                                    icon: "error"
                                });
                            })
                        }
                        else
                        {
                            swal({
                                title: "Jelszó változtatás",
                                text: "Sikertelen változtatás! A két jelszó nem egyezik meg!",
                                icon: "error"
                            });
                        }
                    });
                }
                
            });
        }
    
        const changeAntiPhising = () => {
            if(userSecurity[0]["fa"] != "0")
            {
                swal({
                    text: 'Adja meg a kétlépcsős azonosítóját:',
                    content: {
                        element: "input",
                        attributes: {
                            type: "number",
                        },
                    },
                    button: {
                      text: "Tovább",
                    }
                  }).then((content) => {
                    if(content)
                    {
                        var body = {
                            'inputCode' : content,
                            'secretKey' : userSecurity[0]["fa"],
                        };
                        axios.post('http://localhost:8000/api/ver', body, simpleConfig()).then(() => {
                            swal({
                                text: 'Adja meg az új Anti-Phisin kódját (4-6 karakter között):',
                                content: {
                                    element: "input",
                                    attributes: {
                                        type: "password",
                                    },
                                },
                                button: {
                                  text: "Mentés",
                                }
                            }).then((content) => {
                                if(content)
                                {
                                    var body = {'anti_phising': content};
                                
                                    axios.put('http://localhost:8000/api/updateSecurity/'+userSecurity[0]['id'], body, simpleConfig()).then(() => {
                                        swal({
                                            title: "Anti-Phising változtatás",
                                            text: "Sikeres változtatás!",
                                            icon: "success"
                                        }).then(() => {
                                            location.reload();
                                        });
                                    }).catch((err) => {
                                        swal({
                                            title: "Anti-Phising változtatás",
                                            text: err.response.data.message,
                                            icon: "error"
                                        });
                                    });
                                }
                                
                            });
                        }).catch((err) => {
                            swal({
                                title: "Anti-Phising változtatás",
                                text: "Sikertelen változtatás!",
                                icon: "error"
                            });
                        });
                    }
                    
                });
            }
            else
            {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Kérem először állítsa be a kétlépcsős azonosítást!",
                    icon: "error"
                });
            }
        }
    
        const changePhoneNumber = () => {
            if(userSecurity[0]["fa"] != "0")
            {
                swal({
                    text: 'Adja meg a kétlépcsős azonosítóját:',
                    content: {
                        element: "input",
                        attributes: {
                            type: "number",
                        },
                    },
                    button: {
                      text: "Tovább",
                    }
                  }).then((content) => {
                      if(content)
                      {
                            var body = {
                                'inputCode' : content,
                                'secretKey' : userSecurity[0]["fa"],
                            };
                            axios.post('http://localhost:8000/api/ver', body, simpleConfig()).then(() => {
                            swal({
                                text: 'Adja meg az új telefonszámát (10-12 karakter között):',
                                content: {
                                    element: "input",
                                    attributes: {
                                        type: "number",
                                    },
                                },
                                button: {
                                text: "Mentés",
                                }
                            }).then((content) => {
                                if(content)
                                {
                                    var body = {'sms': content};                
                                    axios.put('http://localhost:8000/api/updateSecurity/'+userSecurity[0]['id'], body, simpleConfig()).then(() => {
                                        swal({
                                            title: "Telefonszám változtatás",
                                            text: "Sikeres változtatás!",
                                            icon: "success"
                                        }).then(() => {
                                            location.reload();
                                        });
                                    }).catch((err) => {
                                        swal({
                                            title: "Telefonszám változtatás",
                                            text: err.response.data.message,
                                            icon: "error"
                                        });
                                    });
                                }
                                
                            });
                        }).catch((err) => {
                            swal({
                                title: "Telefonszám változtatás",
                                text: "Sikertelen változtatás!",
                                icon: "error"
                            });
                        });
                      }
                   
                    
                });
            }
            else
            {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Kérem először állítsa be a kétlépcsős azonosítást!",
                    icon: "error"
                });
            }
        }
    
        const change2FA = () => {
            
            var body = {'fa': '0'};
            axios.put('http://localhost:8000/api/updateSecurity/'+userSecurity[0]['id'], body, simpleConfig()).then(() => {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Sikeresen kikapcsolta a kétlépcsős azonosítást!",
                    icon: "success"
                }).then(() => {
                    axios.post('http://localhost:8000/api/logout', {}, simpleConfig()).then((response) => {
                        sessionStorage.clear();
                        window.location.href = "http://localhost:8000/";
                    });
                });
            }).catch((err) => {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: err.response.data.message,
                    icon: "error"
                });
            });
            
        }
    
        return(
            <div align='center' className='container py-5'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Fiók beállítások</p>
                <p className='fs-3 pb-5'>Itt beállíthatja az adatait!</p>
                {!data ? <p>Betöltés..</p> : 
                    <div>
                        {!userData ? <></> : userData.map((n, idx) => 
                            (<div className='py-3' key={idx}>
                                <p className='fs-3 py-3'>Fiók beállítások</p>
                                <p className='fs-4 text-warning'>Felhasználónév:</p>
                                <p className='fs-4'>{n.username} <button onClick={changeUsername} className='btn btn-warning'>Változtatás</button></p>
                                <p className='fs-4 text-warning'>Jelszó</p>
                                <button onClick={changePassword} className='btn btn-warning'>Változtatás</button>
                                <p className='pt-3 fs-4 text-warning'>E-mail cím:</p>
                                <p className='fs-4'>{n.email} <button onClick={changeEmail} className='btn btn-warning'>Változtatás</button></p>
                                <p className='fs-4 text-warning'>Pontszámaim:</p>
                                <p className='fs-4'>{n.points}</p>
                            </div>)
                        )}
                        {!userAddress ? <></> : userAddress.map((n, idx) => 
                            (<div key={idx}>
                                <p className='fs-3 py-3'>Lakcím beállítás</p>
                                <button type="button" className="btn btn-warning" data-toggle="modal" data-target="#addressModal">Változtatás</button>
                                <p className='pt-3 fs-4 text-warning'>Irányítószám: </p>
                                <p className='fs-4'>{n.zipcode}</p>
                                <p className='fs-4 text-warning'>Város:</p>
                                <p className='fs-4'>{n.city_name}</p>
                                <p className='fs-4 text-warning'>Utca neve:</p>
                                <p className='fs-4'>{n.street_name}</p>
                                <p className='fs-4 text-warning'>Házszám:</p>
                                <p className='fs-4'>{n.house_number}</p>
                            </div>)
                        )}
                        {!userSecurity ? <></> : userSecurity.map((n, idx) => 
                            (<div key={idx}>
                                <p className='fs-3 py-3'>Biztonsági beállítások</p>
                                <p className='pt-3 fs-4 text-warning'>Anti-Phising Code: </p>
                                <p className='fs-4'>{n.anti_phising == "0" ? <button onClick={changeAntiPhising} className='btn btn-outline-warning'>Beállítás</button> : <button onClick={changeAntiPhising} className='btn btn-warning'>Változtatás</button>}</p>
                                <p className='fs-4 text-warning'>Telefonszám:</p>
                                <p className='fs-4'>{n.sms == "0" ? <button onClick={changePhoneNumber} className='btn btn-outline-warning'>Beállítás</button> : <span>{n.sms} <br /><button onClick={changePhoneNumber} className='btn btn-warning'>Változtatás</button></span> }</p>
                                <p className='fs-4 text-warning'>Kétlépcsős azonosítás:</p>
                                <p className='fs-4'>{n.fa == "0" ? <button onClick={change2FA} className='btn btn-outline-warning'>Bekapcsolás</button> : <button onClick={change2FA} className='btn btn-warning'>Kikapcsolás</button>}</p>
                                <p className='fs-4 text-warning'>KYC:</p>
                                {n.kyc == "0" ? <VerifyButton
                                                apiKey={"BOgHE0Pd0doi4dVT3x3FEuTKCSxecJh5CoDAFhoUwTgz2oODdwPDy11fN0Nv4pfE"}
                                                onSubmitted={(identityAccessKey) => {}}
                                                onFinish={(identityAccessKey) => {
                                                    axios.put('http://localhost:8000/api/updateSecurity/'+userSecurity[0]['id'], {'kyc': identityAccessKey}, simpleConfig()).then(() => {
                                                        swal({
                                                            title: "KYC",
                                                            text: "Sikeresen bekapcsolta a KYC-t!",
                                                            icon: "success"
                                                        }).then(() => {
                                                            location.reload();
                                                        });
                                                    }).catch((err) => {
                                                        swal({
                                                            title: "KYC",
                                                            text: "Hiba történt a beállítás során!",
                                                            icon: "error"
                                                        });
                                                    });
                                                }}
                                                onError={(errorCode) => {}}
                                                onStart={() => {}}
                                            /> : kyc ? <p className='fs-4'>Bekapcsolva</p> : <p className='fs-4'>Folyamatban</p>}
                            </div>)
                        )}
                    </div>
                }
                <div className="modal fade" id="addressModal" role="dialog" aria-labelledby="addressModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="addressModalLabel">KriptoBázis - Új lakcím</h5>
                        </div>
                        <div className="modal-body">
                            <div className="form-group pb-3">
                                <label>Irányítószám:</label>
                                <input id="newZipcode" className="form-control" type="number" />
                                <small className="form-text text-muted">
                                    1-4 közötti karakterszám legyen!
                                </small>
                            </div>
                            <div className="form-group pb-3">
                                <label>Város neve:</label>
                                <input id="newCityName" className="form-control" type="text" />
                                <small className="form-text text-muted">
                                    3-30 közötti karakterszám legyen!
                                </small>
                            </div>
                            <div className="form-group pb-3">
                                <label>Utca megnevezése:</label>
                                <input id="newStreetName" className="form-control" type="text" />
                                <small className="form-text text-muted">
                                    2-15 közötti karakterszám legyen!
                                </small>
                            </div>
                            <div className="form-group pb-3">
                                <label>Házszám:</label>
                                <input id="newHouseNumber" className="form-control" type="number" />
                                <small className="form-text text-muted">
                                    1-3 közötti karakterszám legyen!
                                </small>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                            <button onClick={changeAddress} type="button" className="btn btn-primary">Mentés</button>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
   

}

export default Settings;

if (document.getElementById('settings')) {
    ReactDOM.render(<Settings />, document.getElementById('settings'));
}
