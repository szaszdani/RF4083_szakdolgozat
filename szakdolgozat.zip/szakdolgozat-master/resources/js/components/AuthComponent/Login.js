import axios from 'axios';
import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import { isLoggedIn } from '../Commands/Commands';

function Login() {

    if(isLoggedIn())
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    else
    {
        const [username, setUsername] = useState("");
        const [password, setPassword] = useState("");
        var id;
        let token = document.getElementById('meta_token').getAttribute('content');
    
        
        const handleSubmit = (e) => {
            e.preventDefault();
    
            async function fetchData()
            {
                const body = {'username': username, 'pwd':password};
                let config = {
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                }
                axios.get('/sanctum/csrf-cookie').then(() => {
                    axios.post('http://localhost:8000/api/login', body, config).then((response) => {
                        if(response.data.user.user_rank == 4)
                        {
                            swal({
                                title: "Bejelentkezés",
                                text: "Ön nem jelentkezhet be az oldalra, mivel ki van tiltva!",
                                icon: "error",
                                button: "Bezárás"
                            }).then(() => location.reload());
                        }
                        else
                        {
                            id = response.data.user.id;
                            var token = response.data.token;
                            if(response.data.token != null)
                            {
                                axios.post('http://localhost:8000/api/verifyEmail', {'id': response.data.user.id, 'email': response.data.user.email}, config).then((res) => {
                                    if(res.data.email)
                                    {
                                        swal({
                                            title: "Bejelentkezés",
                                            text: res.data.message,
                                            icon: "warning",
                                            button: "Bezárás"
                                        });
                                    }
                                    else
                                    {
                                        localStorage.setItem('token',token);
                                        swal({
                                            title: "Kétlépcsős azonosítás",
                                            text: "A következő oldalon kérem adja meg a kétlépcsős azonosítóját!",
                                            icon: "success"
                                        }).then(function() {
                                            config = {
                                                headers:{
                                                    'Accept': 'application/json',
                                                    'Content-Type': 'application/json',
                                                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                                                }
                                            };
                                            axios.get('http://localhost:8000/api/sec/'+id, config).then((res) => {
                                                for(var i = 0; i < res.data.length; i++)
                                                {
                                                    if(res.data[i]["fa"] == "0")
                                                    {
                                                        window.location.href = "http://localhost:8000/complete-registration";
                                                    }
                                                    else
                                                    {
                                                        window.location.href = "http://localhost:8000/verify";
                                                    }
                                                }
                                            }).catch((err) => {
                                                console.log(err);
                                            });
                                        });
                                    }
                                }).catch(() => {
        
                                })
                                
                            }
                            else
                            {
                                swal({
                                    title: "Bejelentkezés",
                                    text: "Sikertelen bejelentkezés!",
                                    icon: "error",
                                    button: "Bezárás"
                                });
                            }
                        }
                    }).catch(error => {
                        swal({
                            title: "Bejelentkezés",
                            text: error.response.data.message,
                            icon: "error",
                            button: "Bezárás"
                        });
                    });
                }).catch(error => {
                    swal({
                        title: "Bejelentkezés",
                        text: error.response.data.message,
                        icon: "error",
                        button: "Bezárás"
                    });
                });
            }
            fetchData();
        }
    
        return(
            <div className='container pt-5' align="center">
                 
                <p className='display-2 pt-3'>Kripto<span className='text-warning'>Bázis</span> - Bejelentkezés</p>
                <p className='fs-3'>Üdvözöljük újra!<br/>A sikeres belépés érdekében kérem adja meg a felhasználónevét és jelszavát!</p>
                <form className='pt-5' onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className='h2 text-warning'>Felhasználónév:</label>
                        <div className='col-sm-3'>
                            <input type="text" className="form-control"  placeholder="pelda.felhasznalonev" value={username} onChange={(e) => {setUsername(e.target.value)}} />
                        </div>
                    </div>
                    <div className="form-group pt-2">
                        <label className='h2 text-warning'>Jelszó:</label>
                        <div className='col-sm-3'>
                            <input type="password" className="form-control" placeholder="pelda.jelszo" value={password} onChange={(e) => {setPassword(e.target.value)}}/>
                        </div>
                    </div>
                    <input type="hidden" name="_token" value={token} />
                    <div className='pt-3'>
                        <button type="submit" className="btn btn-warning"><span className='text-white fs-5 fw-bold'>Bejelentkezés</span></button>
                    </div>
                    <div className='pt-3'>
                        <a className='fs-4' href='http://localhost:8000/forgot-password'>Elfelejtett jelszó</a>  
                    </div>        
                </form> 
                
            </div>
        );
    }
   
    
}

export default Login;

if (document.getElementById('loginForm')) {
    ReactDOM.render(<Login />, document.getElementById('loginForm'));
}
