import axios from 'axios';

export const simpleConfig = () => {
    let config = {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + sessionStorage.getItem('loginToken')
        }
    }
    return config;
}

export const config = () => {
    let config = {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    }
    return config;
}

export const getUserId = (config) => {
    return axios.get('http://localhost:8000/api/userID', config);
}

export const isLoggedIn = () => {
    var token = sessionStorage.getItem('loginToken');
    if(token)
    {
        if(token.includes('|'))
        {
            token = token.split('|');
            if(token[0].match(/^[0-9]+$/) != null) return true;
            else return false;
        }
        else
        {
            return false;
        }

    }
    else
    {
        return false;
    }
}
