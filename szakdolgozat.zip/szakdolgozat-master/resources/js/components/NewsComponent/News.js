import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import {isLoggedIn} from '../Commands/Commands';

function News() {
    const [data, setData] = useState(null);

    useEffect(()=> {
        let config = {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        }
        var proxy_url = 'https://cors-anywhere.herokuapp.com/';
        var url = 'https://newsapi.org/v2/everything?q=kriptovalut%C3%A1k&apiKey=5f85b31c950149a9af764ee5c200eb4b';
        var new_url = proxy_url + url
        axios.get(new_url).then((response) => {
            for(var i = 0; i<response.data.articles.length;i++)
            {
                if(response.data.articles[i]["source"]["name"] == "Sg.hu")
                {
                    response.data.articles[i]["urlToImage"] = response.data.articles[i]["urlToImage"].substr(14);
                }
            }
            
            setData(response.data.articles);
        }).catch((err)=>{
            console.log(err);
        })
    }, []);

    return(
        <div align='center' className='container pt-5'>
            {!isLoggedIn() ? <p className='d-none'>{window.location.href="http://localhost:8000/"}</p> : 
            <div className='pt-5 pb-5'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Hírek</p>
                <p className='display-4 pt-3 pb-5'>Magyar kriptovalutával kapcsolatos hírek:</p>
                <div id="hunCrypto" className="carousel slide" data-ride="carousel">
                    <div className="carousel-inner">
                        <div className="carousel-item active">
                            <img className="d-block w-100" src="https://htmlcolorcodes.com/assets/images/colors/golden-yellow-color-solid-background-1920x1080.png" alt="First slide" />
                            <div className="carousel-caption d-none d-md-block">
                                <p className='fs-1 fw-bold'>Magyar kriptovaluta hírek</p>
                                <p className='fw-bold'>Az elmúlt egy hónap legfontosabb híreit olvashatja el!<br /> Lapozzon tovább az izgalmas hírekért!</p>
                            </div>
                        </div>
                        {!data ? <></> : data.map((n, idx) =>
                        (<div key={idx} className='carousel-item'>
                            {n.urlToImage ? <img id='carIMG'  src={n.urlToImage} /> : <></>}
                            <div className="carousel-caption d-none d-md-block">
                                <p className='fs-1 fw-bold'>{n.title}</p>
                                <p className='fw-bold'>{n.description}</p>
                                <a className='fw-bold' href={n.url}>Megtekintés</a>
                            </div>
                        </div>
                        ))}
                    </div>
                    <a className="carousel-control-prev" href="#hunCrypto" role="button" data-slide="prev">
                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span className="fw-bold sr-only">Előző</span>
                    </a>
                    <a className="carousel-control-next" href="#hunCrypto" role="button" data-slide="next">
                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                        <span className="fw-bold sr-only">Következő</span>
                    </a>
                </div>
               
            </div>}
            
        </div>
    );

}

export default News;

if (document.getElementById('news')) {
    ReactDOM.render(<News />, document.getElementById('news'));
}
