import React from 'react';
import ReactDOM from 'react-dom';
import { isLoggedIn } from './Commands/Commands';

function Index() {
    return(
        <div className='container pt-5'>
            <div className='pt-5' align='center'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Főoldal</p>
                <p className='fs-3 pb-5'>Üdvözöljük az oldalunkon! <br />Legyen Ön is a közösség tagja!</p>
            </div>
        </div>
    );

}

export default Index;

if (document.getElementById('index')) {
    ReactDOM.render(<Index />, document.getElementById('index'));
}
