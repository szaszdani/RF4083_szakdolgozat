import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import Parser from "html-react-parser";
import swal from 'sweetalert'
import {simpleConfig, isLoggedIn, getUserId} from '../Commands/Commands'

function AdminPanel() {
    if(isLoggedIn())
    {
        const [head, setHead] = useState("");
        const [data, setData] = useState(null);
        const [userID, setUserID] = useState(0);
        const [forumData, setForumData] = useState("");
        const [forgotPasswordData, setForgotPasswordData] = useState("");
        const [analysisData, setAnalysisData] = useState("");
        const [postData, setPostData] = useState("");
        const [banData, setBanData] = useState("");
        const [banAccData, setBanAccData] = useState("");
        const [ticketData, setTicketData] = useState("");
        const [ticketAccdata, setTicketAccData] = useState("");
        const [header, setHeader] = useState("");
        const [title, setTitle] = useState("");
        const [forumDesc, setForumDesc] = useState("");
        const [text, setText] = useState("");
        
        useEffect(() => {
            
            if(sessionStorage.getItem('loginToken'))
            {
                getUserId(simpleConfig()).then((response) => {
                    var id = response.data.id;
                    setUserID(response.data.id);
                    axios.get('http://localhost:8000/api/users/'+response.data.id, simpleConfig()).then((res) => {
                        if(res.data.user_rank == 3)
                        {
                            setHead("<p className='display-1 justify-content-center'>ADMIN PANEL</p>");
                            document.getElementById('content').classList.remove("d-none");
                        }
                        else
                        {
                            setHead("<p class='pt-5 display-1 justify-content-center'>Önnek nincsen jogosultsága ehhez az oldalhoz!</p>");
                            setTimeout(function(){
                                window.location.href = "http://localhost:8000/";
                            }, 3000);
                        }
                    }).catch((err) => {
                        console.log(err);
                    })
                }).catch((err) => {
                    console.log(err);
                });
            }
            
        }, []);

        const allUser = (evt) => {
            evt.preventDefault();
            setForumData("");
            setForgotPasswordData("");
            setAnalysisData("");
            setPostData("");
            setBanData("");
            setBanAccData("");
            setTicketData("");
            axios.get('http://localhost:8000/api/allUsers', simpleConfig()).then((response) => {
                setData(response.data);
            }).then(() => {
                setHeader("<th>ID</th>" +
                    "<th>Felhasználónév</th>" +
                    "<th>Email</th>" +
                    "<th>Rang</th>" +
                    "<th>VIP</th>" +
                    "<th>Pontok</th>"+
                    "<th>2FA</th>" +
                    "<th>KYC</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }

        const allForum = (evt) => {
            evt.preventDefault();
            setData("");
            setForgotPasswordData("");
            setAnalysisData("");
            setPostData("");
            setBanData("");
            setTicketData("");
            axios.get('http://localhost:8000/api/allForum', simpleConfig()).then((response) => {
                setForumData(response.data);
            }).then(() => {
                setHeader("<th>ID</th>" +
                    "<th>Cím</th>" +
                    "<th>Létrehozó</th>" +
                    "<th>Leírás</th>" +
                    "<th>Létrehozás ideje</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }

        const allAnalysis = (evt) => {
            evt.preventDefault();
            setData("");
            setForumData("");
            setForgotPasswordData("");
            setPostData("");
            setBanData("");
            setBanAccData("");
            setTicketData("");
            axios.get('http://localhost:8000/api/allAnalysis', simpleConfig()).then((response) => {
                setAnalysisData(response.data);
            }).then(() => {
                setHeader("<th>ID</th>" +
                    "<th>Cím</th>" +
                    "<th>Létrehozó</th>" +
                    "<th>Megtekintések száma</th>" +
                    "<th>Kedvelések száma</th>" +
                    "<th>Létrehozás ideje</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }

        const allPosts = (evt) => {
            evt.preventDefault();
            setData("");
            setForumData("");
            setForgotPasswordData("");
            setAnalysisData("");
            setBanData("");
            setBanAccData("");
            setTicketData("");
            axios.get('http://localhost:8000/api/allPost', simpleConfig()).then((response) => {
                setPostData(response.data);
            }).then(() => {
                setHeader("<th>ID</th>" +
                    "<th>Cím</th>" +
                    "<th>Fórum címe</th>" +
                    "<th>Létrehozó</th>" +
                    "<th>Létrehozás ideje</th>" +
                    "<th>Megtekintések száma</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }

        const allBans = (evt) => {
            evt.preventDefault();
            setData("");
            setForgotPasswordData("");
            setForumData("");
            setAnalysisData("");
            setPostData("");
            setTicketData("");
            axios.get('http://localhost:8000/api/allBanList', simpleConfig()).then((response) => {
                setBanData(response.data);
                axios.get('http://localhost:8000/api/allBanAcc', simpleConfig()).then((response) => {
                    setBanAccData(response.data);
                }).catch((error) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error"
                    });
                });
            }).then(() => {
                setHeader("<th>ID</th>" +
                    "<th>Kitiltás létrehozója</th>" +
                    "<th>Kitiltást kapta</th>" +
                    "<th>Kitiltás kezdete</th>" +
                    "<th>Kitiltás vége</th>"+
                    "<th>Indok</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }

        const allTickets = (evt) => {
            evt.preventDefault();
            setData("");
            setForgotPasswordData("");
            setAnalysisData("");
            setForumData("");
            setPostData("");
            setBanData("");
            setBanAccData("");
            axios.get('http://localhost:8000/api/allTicket', simpleConfig()).then((response) => {
                if(response.data)
                {
                    setTicketData(response.data);
                }
                
                axios.get('http://localhost:8000/api/allTicketAcc', simpleConfig()).then((response) => {
                    setTicketAccData(response.data);
                }).catch(() => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error"
                    });
                });
                
            }).then(() => {
                setHeader("<th>ID</th>" +
                    "<th>Létrehozó</th>" +
                    "<th>E-mail cím</th>" +
                    "<th>Cím</th>" +
                    "<th>Létrehozás ideje</th>"+
                    "<th>Készenlét</th>" + 
                    "<th>Elvállalás</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }
        
        const allForgotPassword = (evt) => {
            evt.preventDefault();
            setData("");
            setAnalysisData("");
            setForumData("");
            setPostData("");
            setBanData("");
            setTicketData("");
            setBanAccData("");
            axios.get('http://localhost:8000/api/allForgotPassword', simpleConfig()).then((response) => {
                setForgotPasswordData(response.data);
            }).then(() => {
                setHeader("<th>Létrehozás ideje</th>" +
                    "<th>E-mail cím</th>"+
                    "<th>Token</th>"
                );
            }).catch(error => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }

        const jumpToData = (event, string) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            window.location.href = "http://localhost:8000/"+string+"/"+id;
        }

        const deleteData = (event, string) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            if(string == "deleteForgotPassword")
            {
                id = data[1].innerHTML;
            }
            else
            {
                id = data[0].innerHTML;
            }
            axios.delete('http://localhost:8000/api/'+string+'/'+id, simpleConfig()).then(() => {
                swal({
                    title: "Törlés",
                    text: "Sikeres törlés!",
                    icon: "success"
                }).then(() => location.reload());
            }).catch(() => {
                swal({
                    title: "Törlés",
                    text: "Sikertelen törlés!",
                    icon: "error"
                });
            });
        }

        const changeForum = () => {
            var body;
            if(document.getElementById('newForumHeader').value && document.getElementById('newForumDesc').value){
                body = {
                    'title' : title,
                    'forum_desc': forumDesc
                }
            }
            else if(document.getElementById('newForumDesc').value) body = {'forum_desc': forumDesc};
            else body = {'title' : title}
            
            axios.put('http://localhost:8000/api/changeForum/'+document.getElementById('id').value, body, simpleConfig()).then(() => {
                swal({
                    title: "Fórum",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Fórum",
                    text: "Sikertelen frissítés!",
                    icon: "error"
                });
            })
        }
        const changeAnalysis = () => {
            var postData = new FormData();
            if(document.getElementById('newAnalysisHeader').value){
                postData.append('title', document.getElementById('newAnalysisHeader').value);
            }
            else if(document.getElementById('newAnalysisText').value) postData.append('content', document.getElementById('newAnalysisText').value);
            else if(document.getElementById('newAnalysisImg').files[0]) postData.append('img', document.getElementById('newAnalysisImg').files[0]);
            
            axios.post('http://localhost:8000/api/changeAnalysis/'+document.getElementById('id').value, postData, simpleConfig()).then(() => {
                swal({
                    title: "Elemzés frissítés",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Elemzés frissítés",
                    text: "Sikertelen frissítés!",
                    icon: "error"
                });
            });
        }

        const changePost = () => {
            var postData = new FormData();
            if(document.getElementById('newPostHeader').value){
                postData.append('post_title', title);
            }
            else if(document.getElementById('newPostText').value) postData.append('post_text', text);
            else if(document.getElementById('newPostImg').files[0]) postData.append('img', document.getElementById('newPostImg').files[0]);
            
            axios.post('http://localhost:8000/api/changePost/'+document.getElementById('id').value, postData, simpleConfig()).then(() => {
                swal({
                    title: "Poszt frissítés",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Poszt frissítés",
                    text: "Sikertelen frissítés!",
                    icon: "error"
                });
            });
        }

        const takeTicket = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            getUserId(simpleConfig()).then((res) => {
                axios.post('http://localhost:8000/api/createTicketAcc', {'users_id': res.data.id, 'support_id': id}, simpleConfig()).then(() => {
                    swal({
                        title: "Segítségkérés",
                        text: "Sikeres elvállalta!",
                        icon: "success"
                    }).then(() => {location.reload()});
                }).catch(() => {
                    swal({
                        title: "Segítségkérés",
                        text: "Sikertelen elvállalás!",
                        icon: "error"
                    });
                });
            }).catch(() => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen elvállalás!",
                    icon: "error"
                });
            });
        }

        const closeTicket = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            axios.put('http://localhost:8000/api/changeTicket/'+id, {'done':'1'}, simpleConfig()).then(() => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikeres lezárás!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Segítségkérés",
                    text: "Sikertelen lezárás!",
                    icon: "error"
                });
            });
        }

        const changeBan = () => {
            var body;
            if(document.getElementById('newDate').value && document.getElementById('newReason').value){
                body = {
                    'date_end' : document.getElementById('newDate').value,
                    'reason': document.getElementById('newReason').value
                }
            }
            else if(document.getElementById('newDate').value) body = {'date_end': document.getElementById('newDate').value};
            else body = {'reason' : document.getElementById('newReason').value}
            
            axios.put('http://localhost:8000/api/changeBanList/'+document.getElementById('id').value, body, simpleConfig()).then(() => {
                swal({
                    title: "Kitiltás",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Kitiltás",
                    text: "Sikertelen frissítés!",
                    icon: "error"
                });
            });
        }

        const changeUser = () => {
            var body = {};
            if(document.getElementById('newRank').value != ""){
                body["user_rank"] = document.getElementById('newRank').value
            }
            else if(document.getElementById('newVip').value != ""){
                body["vip"] = document.getElementById('newVip').value
            }
            else if(document.getElementById('newPoints').value){
                body["points"] = document.getElementById('newPoints').value
            }
            axios.put('http://localhost:8000/api/updateUser/'+document.getElementById('id').value, body, simpleConfig()).then(() => {
                swal({
                    title: "Felhasználó frissítás",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Felhasználó frissítás",
                    text: "Sikertelen frissítés!",
                    icon: "error"
                });
            });
        }
        
        const turnOff2FA = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            axios.put('http://localhost:8000/api/updateSecurity/'+id, {'fa': 0}, simpleConfig()).then(() => {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Sikeres kikapcsolás!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Sikertelen kikapcsolás!",
                    icon: "error"
                });
            });
        }

        const turnOffKYC = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            axios.put('http://localhost:8000/api/updateSecurity/'+id, {'kyc': 0}, simpleConfig()).then(() => {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Sikeres kikapcsolás!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Kétlépcsős azonosítás",
                    text: "Sikertelen kikapcsolás!",
                    icon: "error"
                });
            });
        }

        const banUser = () => {
            var body = {
                'users_id': document.getElementById('id').value,
                'ban_acc': userID,
                'date_end': document.getElementById('date_end').value, 
                'reason': document.getElementById('reason').value
            };
            axios.post('http://localhost:8000/api/createBanList', body, simpleConfig()).then(() => {
                swal({
                    title: "Felhasználó kitiltása",
                    text: "Sikeresen kitiltotta a felhasználót!",
                    icon: "success"
                }).then(function() {
                    location.reload();
                });
            }).catch((err) => {
                swal({
                    title: "Felhasználó kitiltása",
                    text: err.response.data.message,
                    icon: "error"
                });
            });
        }

        const setId = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var id = data[0].innerHTML;
            document.getElementById('id').value = id;
        }

        return(
            <div className="container pt-5" align="center">
                {Parser(head)}
                <div id="content" className="d-none">
                    <button className="m-2 btn btn-outline-warning" onClick={allUser}>Felhasználók</button>
                    <button className="m-2 btn btn-outline-warning" onClick={allForgotPassword}>Elfelejtett jelszó</button>
                    <button className="m-2 btn btn-outline-warning" onClick={allForum}>Fórum</button>
                    <button className="m-2 btn btn-outline-warning" onClick={allAnalysis}>Elemzések</button>
                    <button className="m-2 btn btn-outline-warning" onClick={allPosts}>Posztok</button>
                    <button className="m-2 btn btn-outline-warning" onClick={allBans}>Kitiltások</button>
                    <button className="m-2 btn btn-outline-warning" onClick={allTickets}>Segítségkérés</button>
                    <input type="hidden" id="id"></input>
                    <div className='py-5 table-responsive'>
                        <table className="table" id="dataTable">
                            <thead>
                            <tr>
                                {Parser(header)}
                            </tr>
                            </thead>
                            <tbody>
                            {!data ? <></> : data.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.id}</td>
                                <td className="row-data align-middle">{n.username}</td>
                                <td className="row-data align-middle">{n.email}</td>
                                <td className="row-data align-middle">{n.user_rank == "1" ? "Tag" : n.user_rank == "2" ? "Elemző" : "Admin"}</td>
                                <td className="row-data align-middle">{n.vip == 0 ? "Nem" : "Igen"}</td>
                                <td className="row-data align-middle">{n.points}</td>
                                <td className="row-data align-middle">{n.user_sec.fa == "0" ? "Kikapcsolva" : <button className='btn btn-outline-warning' onClick={(e) => turnOff2FA(e)}>Kikapcsolás</button>}</td>
                                <td className="row-data align-middle">{n.user_sec.kyc == "0" ? "Kikapcsolva" : n.user_sec.kyc}</td>
                                <td><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeUser">Módosítás</button></td>
                                <td><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#banUser">Üzenetek tiltása</button></td>
                            </tr>))}

                            {!forumData ? <></> : forumData.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.id}</td>
                                <td className="row-data align-middle"><button className='btn btn-outline-warning' onClick={(e) => jumpToData(e, "forum")}>{n.title}</button></td>
                                <td className="row-data align-middle">{n.user.username}</td>
                                <td className="row-data align-middle">{n.forum_desc}</td>
                                <td className="row-data align-middle">{n.created_date}</td>
                                <td><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeForum">Módosítás</button></td>
                                <td><button onClick={(e) => deleteData(e, "deleteForum")} className="btn btn-outline-warning">Törlés</button></td>
                            </tr>))}

                            {!analysisData ? <></> : analysisData.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.id}</td>
                                <td className="row-data align-middle"><button className='btn btn-outline-warning' onClick={(e) => jumpToData(e, "analysis")}>{n.title}</button></td>
                                <td className="row-data align-middle">{n.user.username}</td>
                                <td className="row-data align-middle">{n.viewing}</td>
                                <td className="row-data align-middle">{n.likes}</td>
                                <td className="row-data align-middle">{n.created_date}</td>
                                <td><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeModal">Módosítás</button></td>
                                <td><button onClick={(e) => deleteData(e, "deleteAnalysis")} className="btn btn-outline-warning">Törlés</button></td>
                            </tr>))}

                            {!postData ? <></> : postData.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.id}</td>
                                <td className="row-data align-middle"><button className='btn btn-outline-warning' onClick={(e) => jumpToData(e, "post")}>{n.post_title}</button></td>
                                <td className="row-data align-middle">{n.forum.title}</td>
                                <td className="row-data align-middle">{n.user.username}</td>
                                <td className="row-data align-middle">{n.post_date}</td>
                                <td className="row-data align-middle">{n.post_viewing}</td>
                                <td><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changePost">Módosítás</button></td>
                                <td><button onClick={(e) => deleteData(e, "deletePost")} className="btn btn-outline-warning">Törlés</button></td>
                            </tr>))}

                            {!forgotPasswordData ? <></> : forgotPasswordData.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.created_at}</td>
                                <td className="row-data align-middle">{n.email}</td>
                                <td className="row-data align-middle">{n.token}</td>
                                <td><button onClick={(e) => deleteData(e, "deleteForgotPassword")} className="btn btn-outline-warning">Törlés</button></td>
                            </tr>))}

                            {!banData ? <></> : banData.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.id}</td>
                                <td className="row-data align-middle">{n.user.username}</td>
                                {!banAccData ? <></> : banAccData.map((n, idx) => <td className="row-data align-middle" key={idx}>{n.user.username}</td>)}
                                <td className="row-data align-middle">{n.date_start}</td>
                                <td className="row-data align-middle">{n.date_end}</td>
                                <td className="row-data align-middle">{n.reason}</td>
                                <td><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeBan">Módosítás</button></td>
                                <td><button onClick={(e) => deleteData(e, "deleteBanList")} className="btn btn-outline-warning">Törlés</button></td>
                            </tr>))}

                            {!ticketData ? <></> : ticketData.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle">{n.id}</td>
                                <td className="row-data align-middle">{n.user.username}</td>
                                <td className="row-data align-middle">{n.email}</td>
                                <td className="row-data align-middle"><button className='btn btn-outline-warning' onClick={(e) => jumpToData(e, "showTicket")}>{n.title}</button></td>
                                <td className="row-data align-middle">{n.created_date}</td>
                                <td className="row-data align-middle">{n.done == 0 ? <button onClick={(e) => closeTicket(e)} type="button" className="btn btn-outline-warning">Lezárás</button> : "Lezárva"}</td>
                                {ticketAccdata == "" ? <td><button onClick={(e) => takeTicket(e)} className='btn btn-outline-warning'>Elvállalás</button></td> : ticketAccdata.map((x, idx) => (x.support_id == n.id ? <td className='align-middle' key={idx}>{x.user.username}</td> : <></>))}
                                <td><button onClick={(e) => deleteData(e, "deleteTicket")} className="btn btn-outline-warning">Törlés</button></td>
                            </tr>))}
                            </tbody>
                        </table>
                    </div>
                    <div className="modal fade" id="changeModal"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="changeModalLabel">Elemzés módosítás</h5>
                            </div>
                            <div className="modal-body">
                                <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                <div className="form-group pb-3">
                                    <label>Új cím:</label>
                                    <input id="newAnalysisHeader" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        5-25 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Új leírás:</label>
                                    <input id="newAnalysisText" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        10-1000 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Új fájl:</label>
                                    <input id="newAnalysisImg" className="form-control" type="file" />
                                    <small className="form-text text-muted">
                                        Elfogadott típusok: PNG, JPG, JPEG
                                    </small>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                <button onClick={changeAnalysis} type="button" className="btn btn-primary">Mentés</button>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal fade" id="changeForum"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="changeModalLabel">Fórum módosítás</h5>
                            </div>
                            <div className="modal-body">
                                <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                <div className="form-group pb-3">
                                    <label>Új cím:</label>
                                    <input onChange={(e) => {setTitle(e.target.value)}} id="newForumHeader" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        5-25 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Új leírás:</label>
                                    <input onChange={(e) => {setForumDesc(e.target.value)}} id="newForumDesc" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        10-100 karakter között szerepeljen!
                                    </small>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                <button onClick={() => changeForum()} type="button" className="btn btn-primary">Mentés</button>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal fade" id="changePost"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="changeModalLabel">Fórum módosítás</h5>
                            </div>
                            <div className="modal-body">
                                <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                <div className="form-group pb-3">
                                    <label>Új cím:</label>
                                    <input onChange={(e) => {setTitle(e.target.value)}} id="newPostHeader" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        5-15 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Új leírás:</label>
                                    <input onChange={(e) => {setText(e.target.value)}} id="newPostText" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        10-1000 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Új fájl:</label>
                                    <input id="newPostImg" className="form-control" type="file" />
                                    <small className="form-text text-muted">
                                        Elfogadott típusok: PNG, JPG, JPEG
                                    </small>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                <button onClick={() => changePost()} type="button" className="btn btn-primary">Mentés</button>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal fade" id="changeBan"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="changeModalLabel">Kitiltás módosítás</h5>
                            </div>
                            <div className="modal-body">
                                <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                <div className="form-group pb-3">
                                    <label>Kitiltás végső időpontja:</label>
                                    <input id="newDate" className="form-control" type="date" />
                                </div>
                                <div className="form-group pb-3">
                                    <label>Indok:</label>
                                    <input id="newReason" className="form-control" type="text" />
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                <button onClick={() => changeBan()} type="button" className="btn btn-primary">Mentés</button>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal fade" id="changeUser"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="changeModalLabel">Felhasználó módosítás</h5>
                            </div>
                            <div className="modal-body">
                                <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                <div className="form-group pb-3">
                                    <label>Felhasználó rangfokozata:</label>
                                    <select id="newRank" className='form-select'>
                                        <option value="">Válasszon a listából</option>
                                        <option value="1">Tag</option>
                                        <option value="2">Elemző</option>
                                        <option value="3">Admin</option>
                                        <option value="4">Kitiltás</option>
                                    </select>
                                </div>
                                <div className="form-group pb-3">
                                    <label>VIP:</label>
                                    <select id="newVip" className='form-select'>
                                        <option value="">Válasszon a listából</option>
                                        <option value="0">Nem</option>
                                        <option value="1">Igen</option>
                                    </select>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Pontok száma:</label>
                                    <input id="newPoints" className="form-control" type="number" />
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                <button onClick={() => changeUser()} type="button" className="btn btn-primary">Mentés</button>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal fade" id="banUser" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="exampleModalLabel">Felhasználó kitiltása</h5>
                                </div>
                                <div className="modal-body">
                                    
                                    <div className="form-group pb-3">
                                        <label>Kitiltás vége:</label>
                                        <input id="date_end" className="form-control" type="date" />
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Indok:</label>
                                        <input id="reason" className="form-control" type="text" />
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={() => banUser()} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
}

export default AdminPanel;

if (document.getElementById('adminPanel')) {
    ReactDOM.render(<AdminPanel />, document.getElementById('adminPanel'));
}
