import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import {simpleConfig, getUserId, isLoggedIn} from '../Commands/Commands';

function Portfolio() {
    if(isLoggedIn())
    {
        const [userId, setUserId] = useState(0);
        const [data, setData] = useState(null);
        const [sellData, setSellData] = useState(null);
        const [searchData, setSearchData] = useState([]);
        const [filteredData, setFilteredData] = useState([]);
        const [wordEntered, setWordEntered] = useState("");
        const [transactionType, setTransactionType] = useState("0");
        const [transactionDate, setTransactionDate] = useState("");
        const [quantity, setQuantity] = useState("");
        const [fullQuantity, setFullQuantity] = useState("");
        const [olderPrice, setOlderPrice] = useState("");
        const [price, setPrice] = useState("");

        useEffect(() => {
            getUserId(simpleConfig()).then((response) => {
                var id = response.data.id;
                setUserId(id);
                axios.get('http://localhost:8000/api/portfolio/'+id, simpleConfig()).then((response) => {
                    var tempTwo = 0;
                    for(var i=0; i < response.data.length; i++)
                    {
                        if(response.data[i]["transaction_type"] == 1)
                        {
                            var dataID = response.data[i]['id'];
                            axios.get('https://api.coingecko.com/api/v3/coins/'+response.data[i]["coin"]+'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((response) => {
                                var body = {'id': dataID, 'users_id': id, 'coin': response.data.id, 'total_value': response.data.market_data.current_price.usd};
                                axios.put('http://localhost:8000/api/portfolioChange', body, simpleConfig()).then(() => {
                                    axios.get('http://localhost:8000/api/portfolio/'+id, simpleConfig()).then((response) => {
                                        var temp = 0;
                                        for(var i = 0; i < response.data.length; i++)
                                        {
                                            if(response.data[i]["transaction_type"] == 1)
                                            {
                                                if(temp == 0)
                                                {
                                                    setData([response.data[i]]);
                                                }
                                                else
                                                {
                                                    setData(prev => [...prev, response.data[i]]);
                                                }
                                                temp++;
                                            }
                                        }
                                    }).catch((error) => {
                                        swal({
                                            title: "Lekérdezés",
                                            text: error.response.data.message,
                                            icon: "error",
                                            button: "Bezárás"
                                        });
                                    });
                                }).catch((error) => {
                                    swal({
                                        title: "Lekérdezés",
                                        text: error.response.data.message,
                                        icon: "error",
                                        button: "Bezárás"
                                    });
                                });
                            }).catch((error) => {
                                swal({
                                    title: "Lekérdezés",
                                    text: error.response.data.message,
                                    icon: "error",
                                    button: "Bezárás"
                                });
                            });
                        }
                        else if(response.data[i]["transaction_type"] == 0)
                        {
                            if(tempTwo == 0)
                            {
                                setSellData([response.data[i]]);
                            }
                            else
                            {
                                setSellData(prev => [...prev, response.data[i]]);
                            }
                            tempTwo++;
                        }
                    }
                }).catch((error) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error",
                        button: "Bezárás"
                    });
                });
            })

            axios.get('https://api.coingecko.com/api/v3/coins/list').then((response) => {
                setSearchData(response.data);
            }).catch((error) => {
                console.log('Hiba lépett fel!');
            });
        }, []);

        const handleFilter = (event) => {
            const searchWord = event.target.value;
            setWordEntered(searchWord);
            const newFilter = searchData.filter((value) => {
                return value.name.toLowerCase().includes(searchWord.toLowerCase());
            });

            if (searchWord === "") {
                setFilteredData([]);
            } else {
                setFilteredData(newFilter);
            }
        };

        const oneCoin = (e) =>
        {
            window.location.href = "http://localhost:8000/cryptocurrencies/coin=" + e.target.getAttribute("name");
        }

        const numberWithSpaces = (x) => {
            if(x === null)
            {
                return "-";
            }
            var parts = x.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
            return parts.join(".");
        }
        const chooseFromList = (e) => {
            setWordEntered(e.target.value);
            setFilteredData([]);
        }

        const addItem = () => {
            axios.get('https://api.coingecko.com/api/v3/coins/'+document.getElementById("coin").value.toLowerCase()+'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((res) => {
                const body = {'users_id': userId,
                            'coin': document.getElementById("coin").value.toLowerCase(),
                            'transaction_type' : transactionType,
                            'transaction_date': transactionDate,
                            'quantity': quantity,
                            'price': price,
                            'price_of_coin': res.data.market_data.current_price.usd};
            
                axios.post('http://localhost:8000/api/createPortfolio', body, simpleConfig()).then(() => {
                    swal({
                        title: "Portfolió hozzáadás",
                        text: "Sikeresen hozzáadta a kiválaszott kriptovalutát a portfoliójához!",
                        icon: "success"
                    }).then(function() {
                        location.reload();
                    });
                }).catch((error) => {
                    swal({
                        title: "Portfolió hozzáadás",
                        text: error.response.data.message,
                        icon: "error",
                        button: "Bezárás"
                    });
                });
            }).catch(() => {
                swal({
                    title: "Portfolió hozzáadás",
                    text: "Ilyen kriptovaluta nincsen!",
                    icon: "error",
                    button: "Bezárás"
                });
            });
            
        }

        const setName = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[4].innerHTML;
            setFullQuantity(parseInt(document.getElementById('quan').innerHTML.replace(' ', '')));
            setOlderPrice(parseInt(document.getElementById('val').innerHTML.replace(' ', '')));
            document.getElementById("coinName").innerHTML = coin.toUpperCase();
        }

        const del = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[4].innerHTML;
            var id = data[5].innerHTML;
            let config = {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem('loginToken')
            }
            axios.delete("http://localhost:8000/api/portfolioDelete", {
                headers: config,
                data: {
                    'id': id,
                    'users_id': userId,
                    'coin': coin
                }
            }).then(() => {
                    swal({
                        title: "Portfolió törlés",
                        text: "Sikeres törlés!",
                        icon: "success"
                    }).then(function() {
                        window.location.href = "http://localhost:8000/portfolio";
                    });
            }).catch((error) => {
                    swal({
                        title: "Portfolió törlés",
                        text: error.response.data.message,
                        icon: "error",
                        button: "Bezárás"
                    });
            });
        }

        const delSellData = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[4].innerHTML;
            var id = data[5].innerHTML;
            let config = {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem('loginToken')
            }
            axios.delete("http://localhost:8000/api/portfolioDelete", {
                headers: config,
                data: {
                    'id': id,
                    'users_id': userId,
                    'coin': coin
                }
            }).then(() => {
                    swal({
                        title: "Portfolió törlés",
                        text: "Sikeres törlés!",
                        icon: "success"
                    }).then(function() {
                        window.location.href = "http://localhost:8000/portfolio";
                    });
            }).catch((error) => {
                    swal({
                        title: "Portfolió törlés",
                        text: error.response.data.message,
                        icon: "error",
                        button: "Bezárás"
                    });
            });
            
        }

        const allSum = () => {
            axios.get('http://localhost:8000/api/portfolio/'+userId, simpleConfig()).then((res) => {
                var sum = 0;
                for(var i = 0; i < res.data.length; i++)
                {
                    if(res.data[i]["transaction_type"] == 1)
                    {
                        sum = sum + parseInt(res.data[i]["total_value"]*res.data[i]["quantity"])
                    }
                    else
                    {
                        sum = sum + parseInt(res.data[i]["price"]);
                    }
                }
                swal({
                    title: "Portfolió érték",
                    text: "Portfoliójának jelenlegi értéke: " + numberWithSpaces(sum) + " $",
                    icon: "info"
                });
            }).catch((err) => {
                console.log(err);
            });
        }

        const newTransaction = () => {
            axios.get('https://api.coingecko.com/api/v3/coins/'+document.getElementById("coinName").innerHTML.toLowerCase()+'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((res) => {
                var body = {
                    'users_id': userId,
                    'coin': document.getElementById("coinName").innerHTML.toLowerCase(),
                    'transaction_type' : transactionType,
                    'transaction_date': transactionDate,
                    'quantity': quantity,
                    'price': price,
                    'price_of_coin': res.data.market_data.current_price.usd
                };
    
                if(document.getElementById('newTransactionType').value == 0)
                {
                    var bodyTwo = {
                        'id': document.getElementById('rowID').innerHTML,
                        'users_id': userId, 
                        'coin': document.getElementById("coinName").innerHTML.toLowerCase(), 
                        'quantity': quantity,
                        'price': (olderPrice/fullQuantity)*quantity
                    };
                    axios.put('http://localhost:8000/api/portfolioChange', bodyTwo, simpleConfig()).then(() => {
                        axios.post('http://localhost:8000/api/createPortfolio', body, simpleConfig()).then(() => {
                            swal({
                                title: "Portfolió változtatás",
                                text: "Sikeresen frissítette a portfolióját!",
                                icon: "success"
                            }).then(function() {
                                window.location.href = "http://localhost:8000/portfolio";
                            });
                        }).catch((error) => {
                            swal({
                                title: "Portfolió változtatás",
                                text: error.response.data.message,
                                icon: "error",
                                button: "Bezárás"
                            });
                        });
                    }).catch((error) => {
                        swal({
                            title: "Portfolió változtatás",
                            text: error.response.data.message,
                            icon: "error",
                            button: "Bezárás"
                        });
                    });
                }
                else
                {
                    axios.post('http://localhost:8000/api/createPortfolio', body, simpleConfig()).then(() => {
                        swal({
                            title: "Portfolió változtatás",
                            text: "Sikeresen frissítette a portfolióját!",
                            icon: "success"
                        }).then(function() {
                            window.location.href = "http://localhost:8000/portfolio";
                        });
                    }).catch((error) => {
                        swal({
                            title: "Portfolió változtatás",
                            text: error.response.data.message,
                            icon: "error",
                            button: "Bezárás"
                        });
                    });
                }
            }).catch(() => {
                swal({
                    title: "Portfolió hozzáadás",
                    text: "Ilyen kriptovaluta nincsen!",
                    icon: "error",
                    button: "Bezárás"
                });
            })
            
        }

        return(
            <div align='center' className='container'>
                <p className='display-2 pt-5 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Portfolió</p>
                <p className='fs-1 pb-5'>Adjon hozzá egy új kriptovalutát a portfoliójához!</p>
                <div className='pb-5'>
                    <div className="form-group pb-3">
                        <label>Tranzakció ideje:</label>
                        <input onChange={(e) => {setTransactionDate(e.target.value)}} id="transactionDate" className="form-control" type="date" />
                    </div>
                    <div className="form-group pb-3">
                        <label>Tranzakció típusa:</label>
                        <select onChange={(e) => {setTransactionType(e.target.value)}} id="transactionType" className="form-select" >
                            <option value="0">Eladás</option>
                            <option value="1">Vásárlás</option>
                        </select>
                    </div>
                    <div className="form-group pb-3">
                        <label>Darabszám:</label>
                        <input onChange={(e) => {setQuantity(e.target.value)}} id="quantity" className="form-control" type="number" />
                    </div>
                    <div className="form-group pb-3">
                        <label>Vásárlási/Eladási ár:</label>
                        <input onChange={(e) => {setPrice(e.target.value)}} id="price" className="form-control" type="number" />
                        <small className="form-text text-muted">
                                Kérem dollárban adja meg a vásárlási/eladási árat
                        </small>
                    </div>
                    <div className="search pb-3">
                        <div className="searchInputs">
                            <label>Vásárolt kriptovaluta:</label>
                            <input className='form-control'
                            id="coin"
                            type="text"
                            placeholder="Keressen egy kriptovalutára..."
                            value={wordEntered}
                            onChange={(e) => handleFilter(e)}
                            />
                        </div>
                        {filteredData.length != 0 && (
                            <div className="dataResult">
                            {filteredData.slice(0, filteredData.length).map((value, key) => {
                                return (
                                <button onClick={(e) => chooseFromList(e)} key={value.id} id={value.id} value={value.id.toUpperCase()} className="dataItem btn btn-outline-warning">
                                    {value.name} - {value.symbol.toUpperCase()}
                                </button>
                                );
                            })}
                            </div>
                        )}
                    </div>
                    <button onClick={addItem} className="btn btn-outline-warning">Hozzáadás</button>
                </div>

                <div className='py-5'>
                    <p className='fs-1'>A saját porfolióm</p>
                    <div className='py-5'>
                        <button className='btn btn-outline-warning' onClick={() => allSum()}>Portfóliom értéke</button>
                    </div>
                    <table className="table table-fluid" id="myTable">
                        <thead>
                            <tr>
                                <th>Megnevezés</th>
                                <th>Eredeti vásárlási ár (összesen)</th>
                                <th>Jelenlegi megmaradt mennyiség</th>
                                <th>Jelenlegi érték</th>
                                <th>Profit/Veszteség</th>
                            </tr>
                        </thead>
                        <tbody>
                        {!data ? <tr align="center"><td colSpan="8">Az Ön portfoliója üres!</td></tr> : data.map((n, idx) =>
                                (<tr id={idx} key={idx}>
                                    <td className="row-data align-middle" key={n.coin}><button onClick={(e) => oneCoin(e)} name={n.coin} type="button" className="btn btn-outline-warning">{n.coin.toUpperCase()}</button></td>
                                    <td className="row-data align-middle" ><span id="val">{numberWithSpaces(n.price)}</span>$</td>
                                    <td className="row-data align-middle"><span id="quan">{numberWithSpaces(n.quantity)}</span> darab</td>
                                    <td className="row-data align-middle" >{numberWithSpaces(n.total_value*n.quantity)}$</td>
                                    <td className='align-middle'>{numberWithSpaces(n.total_value*n.quantity - n.price)}$</td>
                                    <td className='align-middle'><button className="btn btn-outline-warning" data-toggle="modal" onClick={(e) => setName(e)} data-target="#newTransaction">Új tranzakció</button></td>
                                    <td className='align-middle'><button className="btn btn-outline-warning" onClick={(e) => del(e)}>Törlés</button></td>
                                    <td className='d-none row-data'>{n.coin}</td>
                                    <td id="rowID" className='d-none row-data'>{n.id}</td>
                                </tr>))}
                        </tbody>
                    </table>
                </div>

                <div className='py-5'>
                    <p className='fs-1'>Korábbi eladások</p>
                    <table className="table table-fluid" id="myTable">
                        <thead>
                            <tr>
                                <th>Megnevezés</th>
                                <th>Eladás időpontja</th>
                                <th>Eladott mennyiség</th>
                                <th>Eladási ár</th>
                            </tr>
                        </thead>
                        <tbody>
                        {!sellData ? <tr align="center"><td colSpan="8">Az Ön portfoliója üres!</td></tr> : sellData.map((n, idx) =>
                                (<tr id={!data ? idx : (idx+data.length)+1} key={idx}>
                                    <td className="row-data align-middle" key={n.coin}><button onClick={(e) => oneCoin(e)} name={n.coin} type="button" className="btn btn-outline-warning">{n.coin.toUpperCase()}</button></td>
                                    <td className="row-data align-middle" >{n.transaction_date}</td>
                                    <td className="row-data align-middle" key={n.price}>{n.quantity} darab</td>
                                    <td className="row-data align-middle">{numberWithSpaces(n.price)}$</td>
                                    <td className='align-middle'><button className="btn btn-outline-warning" onClick={(e) => delSellData(e)}>Törlés</button></td>
                                    <td className='d-none row-data'>{n.coin}</td>
                                    <td className='d-none row-data'>{n.id}</td>
                                </tr>))}
                        </tbody>
                    </table>
                </div>

                <div className="modal fade" id="newTransaction" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Új tranzakció</h5>
                            </div>
                            <div className="modal-body">
                                <p>Kriptovalute neve: <br/><span id="coinName"></span></p>
                                <div className="form-group pb-3">
                                    <label>Tranzakció típus:</label>
                                    <select onChange={(e) => {setTransactionType(e.target.value)}} id="newTransactionType" className='form-select'>
                                        <option value="0">Eladás</option>
                                        <option value="1">Vásárlás</option>
                                    </select>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Tranzakció ideje:</label>
                                    <input onChange={(e) => {setTransactionDate(e.target.value)}} id="newTransactionDate" className="form-control" type="date" />
                                </div>
                                <div className="form-group pb-3">
                                    <label>Darabszám:</label>
                                    <input onChange={(e) => {setQuantity(e.target.value)}} id="newQuantity" className="form-control" type="number" />
                                </div>
                                <div className="form-group pb-3">
                                    <label>Eladási/Vásárlási ár:</label>
                                    <input onChange={(e) => {setPrice(e.target.value)}} id="newPrice" className="form-control" type="number" />
                                    <small className="form-text text-muted">
                                            Kérem dollárban adja meg a vásárlási/eladási árat!
                                    </small>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                <button onClick={() => newTransaction()} type="button" className="btn btn-primary">Mentés</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    
}

export default Portfolio;

if (document.getElementById('portfolio')) {
    ReactDOM.render(<Portfolio />, document.getElementById('portfolio'));
}