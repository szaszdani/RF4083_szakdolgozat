import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import { isLoggedIn, getUserId, simpleConfig } from '../Commands/Commands';

function OneCoin() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const path = window.location.pathname;
        const coin = path.substring(23);
        
        useEffect(() => {
            var watchlistData = [];
            getUserId(simpleConfig()).then((res) => {
                var id =res.data.id;
                axios.get('http://localhost:8000/api/watchlist/'+id, simpleConfig()).then((res) => {
                    watchlistData = res.data;
                }).then(() => {
                    axios.get('https://api.coingecko.com/api/v3/coins/'+coin+'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((response) => {
                        document.getElementById("symbol").innerHTML = response.data.symbol.toUpperCase();
                        for(var i = 0; i < watchlistData.length; i++)
                        {
                            if(response.data["id"] == watchlistData[i]["coin"])
                            {
                                response.data["watchlistItem"] = true;
                            }
                        }
                        setData([response.data]);
                    }).catch((error) => {
                        swal({
                            title: "Lekérdezés",
                            text: "Hiba lépett fel a lekérdezés során!",
                            icon: "error",
                            button: "Bezárás",
                        });
                    });
                });
            });
        }, []);

        const numberWithSpaces = (x) => {
            if(x === null)
            {
                return "-";
            }
            var parts = x.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
            return parts.join(".");
        }

        const reload = () => {
            axios.get('https://api.coingecko.com/api/v3/coins/'+coin+'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((response) => {
                setData([response.data]);
            }).catch((error) => {
                console.log('Hiba lépett fel!');
            });
        }

        const add = () => {
            
            getUserId(simpleConfig()).then((response) => {
                var body = {'users_id': response.data.id, 'coin': coin, 'fav': 1};
                axios.post('http://localhost:8000/api/createWatchlistItem', body, simpleConfig()).then(() => {
                    swal({
                        title: "Figyelőlista hozzáadás",
                        text: "Sikeresen hozzáadta a figyelőlistához!",
                        icon: "success",
                        button: "Bezárás",
                    }).then(() => {
                        location.reload();
                    });
                }).catch(() => {
                    swal({
                        title: "Figyelőlista hozzáadás",
                        text: "Sikertelen hozzáadás! Lehetséges, hogy ezt már egyszer hozzáadta!",
                        icon: "error",
                        button: "Bezárás",
                    });
                })
            }).catch(() => {
                swal({
                    title: "Figyelőlista hozzáadás",
                    text: "Sikertelen hozzáadás! Lehetséges, hogy ezt már egyszer hozzáadta!",
                    icon: "error",
                    button: "Bezárás",
                });
            });
        }

        const delWatchlist = () => {
            getUserId(simpleConfig()).then((response) => {
                axios.delete("http://localhost:8000/api/watchlistDelete", {
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + sessionStorage.getItem('loginToken')
                    },
                    data: {
                    'users_id': response.data.id,
                    'coin': coin
                    }
                }).then(() => {
                        swal({
                            title: "Figyelőlista törlés",
                            text: "Sikeres törlés!",
                            icon: "success"
                        }).then(function() {
                            location.reload();
                        });
                }).catch(() => {
                        swal({
                            title: "Figyelőlista törlés",
                            text: "Sikertelen törlés!",
                            icon: "error",
                            button: "Bezárás"
                        });
                });
            }).catch(() => {
                swal({
                    title: "Figyelőlista törlés",
                    text: "Sikertelen törlés!",
                    icon: "error",
                    button: "Bezárás",
                });
            });
            
        }

        return(
            <div className='container pt-5'>
                <p className='d-none' id="symbol"></p>
                <div className='row'>
                    <div align='center' className='col pt-3'>
                        <p className='display-2 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />{coin.toUpperCase()}</p>
                    </div>
                    <div align = 'center' className='col'>
                    {!data ? <></> : data.map((n, idx) =>
                            (<img className='coinIMG pt-4' key={n.image.large} src={n.image.large}></img>))}
                    </div>
                </div>
                <div align='center' className='row pt-5'>
                    <div className='col'>
                        <p className='fs-1'>Figyelőlistához adás/eltávolitás:</p>
                        {!data ? <></> : data.map((n, idx) =>
                            (
                                <div key={idx}>
                                    {n.watchlistItem ? <button onClick={(e) => delWatchlist(e)} className="btn btn-warning">☆</button> : <button onClick={(e) => add(e)} className="btn btn-outline-warning">☆</button>}
                                </div>
                            ))}
                    </div>
                </div>
                <div align='center' className='row pt-3'>
                    <div className='col'>
                        <p className='fs-1'>Fontosabb információk:</p>
                    </div>
                </div>
                <div align='center' className='row pt-3'>
                    <div className='col'>
                        <p className='fs-4'>A grafikon bal felső sarkában rákereshet az összes kriptovaluta grafikonjára!</p>
                    </div>
                </div>
                <div className="tradingview-widget-container pt-5 pb-5">
                    <div id="tradingview_f7db8"></div>
                </div>
                <div className='row pb-5'>
                    <table align="center" className="table table-fluid">
                        <thead>
                            <tr>
                                <th>Megnevezés</th>
                                <th>Érték</th>
                            </tr>
                        </thead>
                        {!data ? 
                        <tbody>
                            <tr>
                                <td>Betöltés...</td>
                                <td>Betöltés...</td>
                            </tr>
                        </tbody> 
                        : data.map((n, idx) =>
                        (<tbody key={n.id}>
                            <tr>
                                <td>Kriptovaluta neve:</td>
                                <td key={n.name}>{n.name}</td>
                            </tr>
                            <tr>
                                <td>Rövidítése:</td>
                                <td key={n.symbol}>{n.symbol.toUpperCase()}</td>
                            </tr>
                            <tr>
                                <td>Weboldal:</td>
                                <td key={n.links.homepage}>{n.links.homepage}</td>
                            </tr>
                            <tr>
                                <td>Létrehozás ideje:</td>
                                <td key={n.genesis_date}>{!n.genesis_date ? "-" : n.genesis_date}</td>
                            </tr>
                            <tr>
                                <td>Piaci kapitalizáció szerinti rangja:</td>
                                <td key={n.market_cap_rank}>{n.market_cap_rank}</td>
                            </tr>
                            <tr>
                                <td>Piaci kapitalizáció (dollár - euró - forint):</td>
                                <td key={n.market_data.market_cap}>{numberWithSpaces(n.market_data.market_cap.usd)}$</td>
                            </tr>
                            <tr>
                                <td>Jelenlegi ár (dollár - euró - forint):</td>
                                <td key={n.market_data.current_price.usd}>{numberWithSpaces(n.market_data.current_price.usd)}$</td>
                            </tr>
                            <tr>
                                <td>Legmagasabb ár (dollár - euró - forint):</td>
                                <td key={n.market_data.ath.usd}>{numberWithSpaces(n.market_data.ath.usd)}$</td>
                            </tr>
                            <tr>
                                <td>Legalacsonyabb ár (dollár - euró - forint):</td>
                                <td key={n.market_data.atl.usd}>{numberWithSpaces(n.market_data.atl.usd)}$</td>
                            </tr>
                            <tr>
                                <td>Átforgatott tőke (dollár - euró - forint):</td>
                                <td key={n.market_data.total_volume.usd}>{numberWithSpaces(n.market_data.total_volume.usd)}$</td>
                            </tr>
                            <tr>
                                <td>24 órás csúcs (dollár - euró - forint):</td>
                                <td key={n.market_data.high_24h.usd}>{numberWithSpaces(n.market_data.high_24h.usd)}$</td>
                            </tr>
                            <tr>
                                <td>Legalacsonyabb ár az elmúlt 24 órában (dollár - euró - forint):</td>
                                <td key={n.market_data.low_24h.usd}>{numberWithSpaces(n.market_data.low_24h.usd)} $</td>
                            </tr>
                            <tr>
                                <td>Elmúlt 7 nap változása százalékban:</td>
                                <td key={n.market_data.low_24h.usd}>{n.market_data.price_change_percentage_7d} %</td>
                            </tr>
                            <tr>
                                <td>Elmúlt 14 nap változása százalékban:</td>
                                <td key={n.market_data.price_change_percentage_14d}>{n.market_data.price_change_percentage_14d} %</td>
                            </tr>
                            <tr>
                                <td>Elmúlt 30 nap változása százalékban:</td>
                                <td key={n.market_data.price_change_percentage_30d}>{n.market_data.price_change_percentage_30d} %</td>
                            </tr>
                            <tr>
                                <td>Jelenlegi készlet:</td>
                                <td key={n.market_data.circulating_supply}>{numberWithSpaces(n.market_data.circulating_supply)} darab</td>
                            </tr>
                            <tr>
                                <td>Maximális készlet:</td>
                                <td key={n.market_data.max_supply}>{!n.market_data.max_supply ? "-" : numberWithSpaces(n.market_data.max_supply)} darab</td>
                            </tr>
                        </tbody>
                        ))}
                    </table>
                </div>
                <div className="row pb-5">
                    <button className="btn btn-outline-warning" onClick={(e) => reload(e)}>Táblázat frissítése</button>
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    
}

export default OneCoin;

if (document.getElementById('oneCoin')) {
    ReactDOM.render(<OneCoin />, document.getElementById('oneCoin'));
}
