import axios from 'axios';
import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import {getUserId, simpleConfig, isLoggedIn} from '../Commands/Commands';

function CryptoSwap() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [inputCode, setInputCode] = useState("");
        const [showSwap, setShowSwap] = useState(false);

        useEffect(() => {
            var id = 0;
            getUserId(simpleConfig()).then((response) => {
                id = response.data.id;
            }).then(() => {
                axios.get('http://localhost:8000/api/sec/' + id, simpleConfig()).then((response) => {
                    setData(response.data);
                    if(response.data[0]["anti_phising"] == 0)
                    {
                        swal({
                            title: "KriptoBázis - Swap",
                            text: "Önnek nincsen beállítva az Anti-Phising Code.",
                            icon: "warning"
                        }).then(function() {
                            window.location.href = "http://localhost:8000/settings";
                        });
                    }
                }).catch((error) => {
                    swal({
                            title: "KriptoBázis - Swap",
                            text: "Hiba történt a lekérdezés során!",
                            icon: "error"
                        });
                });
            }).catch((error) => {
                swal({
                    title: "KriptoBázis - Swap",
                    text: "Hiba történt a lekérdezés során!",
                    icon: "error"
                });
            });
        }, []);
        

        const chechAntiPhising = () => {
            if(data[0]["anti_phising"] == inputCode && inputCode != 0)
            {
                swal({
                    title: "KriptoBázis - Swap",
                    text: "Sikeres kód megadás!",
                    icon: "success"
                });
                setShowSwap(true);
            }
            else
            {
                swal({
                    title: "KriptoBázis - Swap",
                    text: "Rossz kódot adott meg!",
                    icon: "error"
                });
            }
        }

        return(
            <div align="center" className='container'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Swap</p>
                <p className='fs-3 pb-5'>Ezen az oldalon Ön képes kriptovalutákat cserélni egymással. <br /> Elsősorban kérem adja meg az Anti-Phising kódját, majd ezek után már neki is kezdhet a cserélésnek. <br />Kérem ügyeljen arra, hogy a MetaMask tárca fel van telepítve a böngészőjére. Abban az esetben, ha ez nincsen feltelepítve a következő oldalon megteheti: <br/> <button className='btn btn-outline-warning'><a className='text-decoration-none text-warning' href='https://metamask.io/'>MetaMask telepítése</a></button></p>
                {!showSwap ? <div><p className='fs-3 pt-5 pb-3'>Kérem adja meg az Anti-Phising kódját: </p>
                <input value={inputCode} onChange={(e) => {setInputCode(e.target.value)}} className='form-control' id="inputCode" type="password"/>
                <div className='pt-5'><button onClick={() => chechAntiPhising()} className='btn btn-outline-warning'>Tovább</button></div></div> : 
                <div>
                    <iframe src="https://app.uniswap.org/#/swap?exactField=input&exactAmount=10&inputCurrency=0x6b175474e89094c44da98b954eedeac495271d0f" height="660px" width="100%"></iframe>
                </div>}
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    

}

export default CryptoSwap;

if (document.getElementById('swap')) {
    ReactDOM.render(<CryptoSwap />, document.getElementById('swap'));
}
