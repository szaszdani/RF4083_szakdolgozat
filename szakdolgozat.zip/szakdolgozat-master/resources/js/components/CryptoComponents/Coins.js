import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import swal from 'sweetalert';
import {getUserId, simpleConfig, isLoggedIn} from '../Commands/Commands';

function Coins() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [page, setPage] = useState(1);
        const [searchData, setSearchData] = useState([]);
        const [filteredData, setFilteredData] = useState([]);
        const [wordEntered, setWordEntered] = useState("");

        useEffect(() => {
            onRefresh();
            axios.get('https://api.coingecko.com/api/v3/coins/list').then((response) => {
                setSearchData(response.data);
            }).catch(() => {
                swal({
                    title: "Lekérdezés",
                    text: "Hiba lépett fel a lekérdezés során!",
                    icon: "error",
                    button: "Bezárás",
                });
            });
        }, []);
        
        const onRefresh = () => {
            let num = page;
            var watchlistData = [];
            getUserId(simpleConfig()).then((res) => {
                var id =res.data.id;
                axios.get('http://localhost:8000/api/watchlist/'+id, simpleConfig()).then((res) => {
                    watchlistData = res.data;
                }).then(() => {
                    axios.get('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page='+ num +'&sparkline=false').then((response) => {
                        for(var i = 0; i < watchlistData.length; i++)
                        {
                            for(var j = 0; j < response.data.length; j++)
                            {
                                if(response.data[j]["id"] == watchlistData[i]["coin"])
                                {
                                    response.data[j]["watchlistItem"] = true;
                                }
                            }
                        }
                        setData(response.data);
                    }).catch((error) => {
                        swal({
                            title: "Lekérdezés",
                            text: "Hiba lépett fel a lekérdezés során!",
                            icon: "error",
                            button: "Bezárás",
                        });
                    });
                });
            });
        }

        const intoNextPage = (num) => {
            axios.get('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page='+ num +'&sparkline=false').then((response) => {
                setData(response.data);   
            }).then(() => {
                setPage(num);
            }).catch((error) => {
                swal({
                    title: "Lekérdezés",
                    text: "Hiba lépett fel a lekérdezés során!",
                    icon: "error",
                    button: "Bezárás",
                });
            });
        }

        const nextPage = (e) => {
            e.preventDefault();
            let num = page + 1;
            intoNextPage(num);
            
        }

        const prevPage = (e) => {
            e.preventDefault();
            let num = page;
            if(num != 1)
            {
                num = page - 1;
            }
            intoNextPage(num);
        }

        const numberWithSpaces = (x) => {
            if(x === null)
            {
                return "-";
            }
            var parts = x.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
            return parts.join(".");
        }

        const reload = () => {
            onRefresh();
        }

        const buildOptions = () => {
            var opt = [];
            for(var i = 1; i <= 133; i++)
            {
                opt.push(<option key={i} value={i}>{i}</option>);
            }
            return opt;
        }

        const changePage = (e) => {
            let num = parseInt(e.target.value);
            intoNextPage(num);
        }

        const oneCoin = (e) =>
        {
            window.location.href = "http://localhost:8000/cryptocurrencies/coin=" + e.target.getAttribute("name");
        }

        const add = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[7].innerHTML;
            
            getUserId(simpleConfig()).then((response) => {
                var body = {'users_id': response.data.id, 'coin': coin, 'fav': 1};
                axios.post('http://localhost:8000/api/createWatchlistItem', body, simpleConfig()).then(() => {
                    swal({
                        title: "Figyelőlista hozzáadás",
                        text: "Sikeresen hozzáadta a figyelőlistához!",
                        icon: "success",
                        button: "Bezárás",
                    }).then(() => {
                        onRefresh();
                    });
                }).catch(() => {
                    swal({
                        title: "Figyelőlista hozzáadás",
                        text: "Sikertelen hozzáadás! Lehetséges, hogy ezt már egyszer hozzáadta!",
                        icon: "error",
                        button: "Bezárás",
                    });
                })
            }).catch(() => {
                swal({
                    title: "Figyelőlista hozzáadás",
                    text: "Sikertelen hozzáadás! Lehetséges, hogy ezt már egyszer hozzáadta!",
                    icon: "error",
                    button: "Bezárás",
                });
            });
        }

        const delWatchlist = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[7].innerHTML;
            getUserId(simpleConfig()).then((response) => {
                axios.delete("http://localhost:8000/api/watchlistDelete", {
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + sessionStorage.getItem('loginToken')
                    },
                    data: {
                    'users_id': response.data.id,
                    'coin': coin
                    }
                }).then(() => {
                        swal({
                            title: "Figyelőlista törlés",
                            text: "Sikeres törlés!",
                            icon: "success"
                        }).then(function() {
                            onRefresh();
                        });
                }).catch(() => {
                        swal({
                            title: "Figyelőlista törlés",
                            text: "Sikertelen törlés!",
                            icon: "error",
                            button: "Bezárás"
                        });
                });
            }).catch(() => {
                swal({
                    title: "Figyelőlista törlés",
                    text: "Sikertelen törlés!",
                    icon: "error",
                    button: "Bezárás",
                });
            });
            
        }

        const handleFilter = (event) => {
            const searchWord = event.target.value;
            setWordEntered(searchWord);
            const newFilter = searchData.filter((value) => {
                return value.name.toLowerCase().includes(searchWord.toLowerCase());
            });

            if (searchWord === "") {
                setFilteredData([]);
            } else {
                setFilteredData(newFilter);
            }
        };

        return(
            <div align='center' className="container pt-5 pb-5">
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Kriptovaluták listája</p>
                <p className='fs-5 pb-5'>Ezen az oldalon megtalálja az összes kriptovalutát, és a hozzátartozó adatokat!<br /> Amennyiben szeretné figyelőlistára helyezni valamelyiket, abban az esetben kérem kattintson a csillagjelre.</p>
                <div align="center" className="search pb-5">
                    <p className='fs-3 pt-3'>Keresés:</p>
                    <div className="searchInputs">
                        <input
                        type="text"
                        placeholder="Keressen egy kriptovalutára..."
                        value={wordEntered}
                        onChange={(e) => handleFilter(e)}
                        />
                    </div>
                    {filteredData.length != 0 && (
                        <div className="dataResult">
                        {filteredData.slice(0, filteredData.length).map((value, key) => {
                            return (
                            <button onClick={(e) => oneCoin(e)} name={value.id} key={value.id} className="dataItem btn btn-outline-warning">
                                {value.name} - {value.symbol.toUpperCase()}
                            </button>
                            );
                        })}
                        </div>
                    )}
                </div>
                    
                <div className="row pt-2 pb-2">
                    <div align="left" className="col-sm">
                        <button className="btn btn-outline-warning" onClick={(e) => prevPage(e)}>Előző oldal</button>
                    </div>
                    <div className="col-sm">
                        <button className="btn btn-outline-warning" onClick={(e) => reload(e)}>Frissítés</button>
                    </div>
                    <div align='right' className="col-sm">
                        <button className="btn btn-outline-warning" onClick={(e) => nextPage(e)}>Következő oldal</button>
                    </div>
                </div>
                <table className="table table-fluid" id="myTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Képe</th>
                            <th>Megnevezés</th>
                            <th>Rövidítése</th>
                            <th>Jelenlegi ár</th>
                            <th>Piaci kapitalizáció</th>
                            <th>Állapotnyi készlet</th>
                        </tr>
                    </thead>
                    <tbody>
                    {!data ? <></> : data.map((n, idx) =>
                            (<tr id={idx} key={idx}>
                                <td className="row-data align-middle" key={n.market_cap_rank}>{n.market_cap_rank}</td>
                                <td className="row-data align-middle"><img className='coinIMG pt-1 mr-4' src={n.image}></img></td>
                                <td className="row-data align-middle" key={n.name}><button onClick={(e) => oneCoin(e)} name={n.id} type="button" className="btn btn-outline-warning">{n.name}</button></td>
                                <td className="row-data align-middle">{n.symbol.toUpperCase()}</td>
                                <td className="row-data align-middle">{numberWithSpaces(n.current_price)} $</td>
                                <td className="row-data align-middle">{numberWithSpaces(n.market_cap)} $</td>
                                <td className="row-data align-middle">{numberWithSpaces(n.circulating_supply)} darab</td>
                                <td className='align-middle'>{n.watchlistItem ? <button onClick={(e) => delWatchlist(e)} className="btn btn-warning">☆</button> : <button onClick={(e) => add(e)} className="btn btn-outline-warning">☆</button>}</td>
                                <td className='d-none row-data'>{n.id}</td>
                            </tr>))}
                    </tbody>
                </table>
                <div className='pt-5'>
                    <p className='fs-2'>Ugrás a következő oldalra:</p>
                    <select onChange={() => changePage()} className='form-select'>
                        {buildOptions()}
                    </select>
                </div>
            </div>
            
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    

}

export default Coins;

if (document.getElementById('coins')) {
    ReactDOM.render(<Coins />, document.getElementById('coins'));
}