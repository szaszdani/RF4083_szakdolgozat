import axios from 'axios';
import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import { getUserId, simpleConfig, isLoggedIn } from '../Commands/Commands';

function Watchlist() {
    if(isLoggedIn())
    {
        const [userID, setID] = useState(null);
        const [data, setData] = useState(null);
        const [first, setFirst] = useState(null);
        const [second, setSecond] = useState(null);
        const [third, setThird] = useState(null);

        useEffect(() => {
            var id = 0;
            getUserId(simpleConfig()).then((response) => {
                id = response.data.id;
                setID(id);
            }).then(() => {
                axios.get('http://localhost:8000/api/watchlist/' + id, simpleConfig()).then((response) => {
                    var temp = 0;
                    var dataTemp = 0;
                    var tempTwo = 0;
                    var tempThree = 0;
                    for(var i=0;i<response.data.length;i++)
                    {
                        if(response.data[i]["fav"] == 1)
                        {
                            axios.get('https://api.coingecko.com/api/v3/coins/'+ response.data[i]["coin"] +'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((response) => {
                                if(temp == 0)
                                {
                                    setFirst([response.data]);
                                }
                                else
                                {
                                    setFirst(prev => [...prev, response.data]);
                                }

                                if(dataTemp == 0)
                                {
                                    setData([response.data]);
                                }
                                else
                                {
                                    setData(prev => [...prev, response.data]);
                                }
                                dataTemp++;
                                temp++;
                            }).catch((error) => {
                                console.log(error);
                            });
                        }
                        else if(response.data[i]["fav"] == 2)
                        {
                            axios.get('https://api.coingecko.com/api/v3/coins/'+ response.data[i]["coin"] +'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((response) => {
                                if(tempTwo == 0)
                                {
                                    setSecond([response.data]);
                                }
                                else
                                {
                                    setSecond(prev => [...prev, response.data]);
                                }

                                if(dataTemp == 0)
                                {
                                    setData([response.data]);
                                }
                                else
                                {
                                    setData(prev => [...prev, response.data]);
                                }
                                dataTemp++;
                                tempTwo++;
                            }).catch((error) => {
                                console.log(error);
                            });
                        }
                        else
                        {
                            axios.get('https://api.coingecko.com/api/v3/coins/'+ response.data[i]["coin"] +'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false').then((response) => {
                                if(tempThree == 0)
                                {
                                    setThird([response.data]);
                                }
                                else
                                {
                                    setThird(prev => [...prev, response.data]);
                                }

                                if(dataTemp == 0)
                                {
                                    setData([response.data]);
                                }
                                else
                                {
                                    setData(prev => [...prev, response.data]);
                                }
                                dataTemp++;
                                tempThree++;
                            }).catch((error) => {
                                console.log(error);
                            });
                        }
                    }
                }).catch((error) => {
                    swal({
                        title: "Figyelőlista lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error",
                        button: "Bezárás"
                    });
                });
            }).catch((error) => {
                swal({
                    title: "Figyelőlista lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error",
                    button: "Bezárás"
                });
            });
        }, []);

        const oneCoin = (e) =>
        {
            window.location.href = "http://localhost:8000/cryptocurrencies/coin=" + e.target.getAttribute("name");
        }

        const numberWithSpaces = (x) => {
            if(x === null)
            {
                return "-";
            }
            var parts = x.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
            return parts.join(".");
        }

        const deleteCoin = (event) => {

            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[6].innerHTML;
            axios.delete("http://localhost:8000/api/watchlistDelete", {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + sessionStorage.getItem('loginToken')
                },
                data: {
                'users_id': userID,
                'coin': coin
                }
            }).then(() => {
                    swal({
                        title: "Figyelőlista törlés",
                        text: "Sikeres törlés!",
                        icon: "success"
                    }).then(function() {
                        window.location.href = "http://localhost:8000/watchlist";
                    });
            }).catch((error) => {
                    swal({
                        title: "Figyelőlista törlés",
                        text: "Sikertelen törlés!",
                        icon: "error",
                        button: "Bezárás"
                    });
            });
        }

        const set = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var coin = data[6].innerHTML;
            document.querySelector('.modal-body').innerHTML = "<p class='fs-5'>Kriptovaluta neve:<br /><span id='coinName'>"+ coin.toUpperCase() + "</span><br /><p class='fs-5'>Áthelyezés helye:<br />"+
            "<select id='selectValue' class='form-select'><option value=1>1</option><option value=2>2</option><option value=3>3</option></select>";
        }

        const changeCoin = () => {
            var coin = document.getElementById('coinName').innerHTML;
            var newFav = document.getElementById('selectValue').value;
            var body = {'users_id': userID, 'coin': coin.toLowerCase(), 'fav': newFav}
            axios.put('http://localhost:8000/api/watchlistChange', body, simpleConfig()).then((response) => {
                swal({
                    title: "Figyelőlista frissítés",
                    text: "Sikeres frissítés!",
                    icon: "success",
                    button: "Bezárás"
                }).then(() => window.location.href = "http://localhost:8000/watchlist");
            }).catch((error) => {
                swal({
                    title: "Figyelőlista frissítés",
                    text: "Sikertelen frissítés!",
                    icon: "error",
                    button: "Bezárás"
                });
            });
        }

        return (<div align="center" className='container pt-5 pb-5'>
                    <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Figyelőlista</p>
                    <p className='fs-3 pb-3 pt-3'>A figyelőlista oldalon láthatja azokat a kriptovalutákat, amelyeket a lista oldalon becsillagozott. <br /> A kriptovalutákat fontossági sorrend szerint rendezheti, ahogyan csak szeretné.</p>
                    <div className='pt-5 pb-5'>
                        <button className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#all" aria-expanded="false" aria-controls="collapseExample">
                            Figyelőlista kezelése
                        </button>
                    </div>

                    <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLabel">Figyelőlista áthelyezés</h5>
                        </div>
                        <div className="modal-body">
                            
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                            <button onClick={() => changeCoin()} type="button" className="btn btn-primary">Mentés</button>
                        </div>
                        </div>
                    </div>
                    </div>
                    <div className="collapse p-5" id="all">
                        <div className="card card-body">
                            <div className='table-responsive'>
                                <table className="table table-fluid" id="myTable">
                                    <thead>
                                        <tr>
                                            <th>Képe</th>
                                            <th>Megnevezés</th>
                                            <th>Rövidítése</th>
                                            <th>Jelenlegi ár</th>
                                            <th>Piaci kapitalizáció</th>
                                            <th>Állapotnyi készlet</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {!data ? <tr align="center"><td colSpan="8">Az Ön figyelőlistája üres!</td></tr> : data.map((n, idx) =>
                                            (<tr id={idx} key={idx}>
                                                <td className="row-data align-middle" key={n.image.small}><img className='coinIMG' src={n.image.small}></img></td>
                                                <td className="row-data align-middle" key={n.name}><button onClick={(e) => oneCoin(e)} type="button" name={n.id} className="btn btn-outline-warning">{n.name}</button></td>
                                                <td className="row-data align-middle" key={n.symbol}>{n.symbol.toUpperCase()}</td>
                                                <td className="row-data align-middle" key={n.market_data.current_price.usd}>{numberWithSpaces(n.market_data.current_price.usd)}$</td>
                                                <td className="row-data align-middle" key={n.market_data.market_cap}>{numberWithSpaces(n.market_data.market_cap.usd)}$</td>
                                                <td className="row-data align-middle" key={n.market_data.circulating_supply}>{numberWithSpaces(n.market_data.circulating_supply)} darab</td>
                                                <td><button onClick={(e) => set(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#exampleModal">
                                                        Áthelyezés
                                                    </button>
                                                </td>
                                                <td className='align-middle'><button onClick={(e) => deleteCoin(e)} className="btn btn-outline-warning">Törlés</button></td>
                                                <td className='d-none row-data'>{n.id}</td>
                                            </tr>))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <p className='fs-3 pt-5 pb-5'><span className='text-warning'>Első</span> lista</p>
                    <div className='table-responsive'>
                        <table className="table table-fluid" id="myTable">
                            <thead>
                                <tr>
                                    <th>Képe</th>
                                    <th>Megnevezés</th>
                                    <th>Rövidítése</th>
                                    <th>Jelenlegi ár</th>
                                    <th>Piaci kapitalizáció</th>
                                    <th>Állapotnyi készlet</th>
                                </tr>
                            </thead>
                            <tbody>
                                {!first ? <tr align="center"><td colSpan="8">Az Ön figyelőlistája üres!</td></tr> : first.map((n, idx) =>
                                    (<tr id={idx} key={idx}>
                                        <td className="row-data align-middle" key={n.image.small}><img className='coinIMG' src={n.image.small}></img></td>
                                        <td className="row-data align-middle" key={n.name}><button onClick={(e) => oneCoin(e)} type="button" name={n.id} className="btn btn-outline-warning">{n.name}</button></td>
                                        <td className="row-data align-middle" key={n.symbol}>{n.symbol.toUpperCase()}</td>
                                        <td className="row-data align-middle" key={n.market_data.current_price.usd}>{numberWithSpaces(n.market_data.current_price.usd)}$</td>
                                        <td className="row-data align-middle" key={n.market_data.market_cap}>{numberWithSpaces(n.market_data.market_cap.usd)}$</td>
                                        <td className="row-data align-middle" key={n.market_data.circulating_supply}>{numberWithSpaces(n.market_data.circulating_supply)} darab</td>
                                    </tr>))}
                            </tbody>
                        </table>
                    </div>
                    <p className='fs-3 pt-5 pb-5'><span className='text-warning'>Második</span> lista</p>
                    <div className='table-responsive'>
                        <table className="table table-fluid" id="myTable">
                            <thead>
                                <tr>
                                    <th>Képe</th>
                                    <th>Megnevezés</th>
                                    <th>Rövidítése</th>
                                    <th>Jelenlegi ár</th>
                                    <th>Piaci kapitalizáció</th>
                                    <th>Állapotnyi készlet</th>
                                </tr>
                            </thead>
                            <tbody>
                                {!second ? <tr align="center"><td colSpan="8">Az Ön figyelőlistája üres!</td></tr> : second.map((n, idx) =>
                                    (<tr id={idx} key={idx}>
                                        <td className="row-data align-middle" key={n.image.small}><img className='coinIMG' src={n.image.small}></img></td>
                                        <td className="row-data align-middle" key={n.name}><button onClick={(e) => oneCoin(e)} type="button" name={n.id} className="btn btn-outline-warning">{n.name}</button></td>
                                        <td className="row-data align-middle" key={n.symbol}>{n.symbol.toUpperCase()}</td>
                                        <td className="row-data align-middle" key={n.market_data.current_price.usd}>{numberWithSpaces(n.market_data.current_price.usd)}$</td>
                                        <td className="row-data align-middle" key={n.market_data.market_cap}>{numberWithSpaces(n.market_data.market_cap.usd)}$</td>
                                        <td className="row-data align-middle" key={n.market_data.circulating_supply}>{numberWithSpaces(n.market_data.circulating_supply)} darab</td>
                                    </tr>))}
                            </tbody>
                        </table>
                    </div>
                    <p className='fs-3 pt-5 pb-5'><span className='text-warning'>Harmadik</span> lista</p>
                    <div className='table-responsive'>
                        <table className="table table-fluid" id="myTable">
                            <thead>
                                <tr>
                                    <th>Képe</th>
                                    <th>Megnevezés</th>
                                    <th>Rövidítése</th>
                                    <th>Jelenlegi ár</th>
                                    <th>Piaci kapitalizáció</th>
                                    <th>Állapotnyi készlet</th>
                                </tr>
                            </thead>
                            <tbody>
                                {!third ? <tr align="center"><td colSpan="8">Az Ön figyelőlistája üres!</td></tr> : third.map((n, idx) =>
                                    (<tr id={idx} key={idx}>
                                        <td className="row-data align-middle" key={n.image.small}><img className='coinIMG' src={n.image.small}></img></td>
                                        <td className="row-data align-middle" key={n.name}><button onClick={(e) => oneCoin(e)} type="button" name={n.id} className="btn btn-outline-warning">{n.name}</button></td>
                                        <td className="row-data align-middle" key={n.symbol}>{n.symbol.toUpperCase()}</td>
                                        <td className="row-data align-middle" key={n.market_data.current_price.usd}>{numberWithSpaces(n.market_data.current_price.usd)}$</td>
                                        <td className="row-data align-middle" key={n.market_data.market_cap}>{numberWithSpaces(n.market_data.market_cap.usd)}$</td>
                                        <td className="row-data align-middle" key={n.market_data.circulating_supply}>{numberWithSpaces(n.market_data.circulating_supply)} darab</td>
                                    </tr>))}
                            </tbody>
                        </table>
                    </div>
                    
                </div>);
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    
}

export default Watchlist;

if (document.getElementById('watchlist')) {
    ReactDOM.render(<Watchlist />, document.getElementById('watchlist'));
}
