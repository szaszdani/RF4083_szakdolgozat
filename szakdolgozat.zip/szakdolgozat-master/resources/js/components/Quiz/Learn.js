import axios from 'axios';
import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom';
import {quiz_one, quiz_two, quiz_three, quiz_four, quiz_five, quiz_six, quiz_seven, quiz_eight, quiz_nine, quiz_ten} from './QuizQuestions';
import { simpleConfig, getUserId, isLoggedIn } from '../Commands/Commands';
import swal from 'sweetalert';

function Learn() {
    if(isLoggedIn())
    {
        const [currentQuestion, setCurrentQuestion] = useState(0);
        const [showScore, setShowScore] = useState(false);
        const [score, setScore] = useState(0);
        const [userId, setUserId] = useState(0);
        const [exactQuiz, setExactQuiz] = useState("");
        const [userPoints, setUserPoints] = useState(0);

        useEffect(() => {
            getUserId(simpleConfig()).then((res) => {
                setUserId(res.data.id)
                var id = res.data.id;
                axios.get('http://localhost:8000/api/users/'+id, simpleConfig()).then((res) => {
                    setUserPoints(res.data.points);
                }).catch((err) => {
                    console.log(err);
                })
            }).catch((err) => {
                console.log(err)    
            });
        },[])

        const handleAnswerOptionClick = (isCorrect) => {
            if (isCorrect) {
                setScore(score + 1);
            }

            const nextQuestion = currentQuestion + 1;
            if (nextQuestion < quiz_one().length) {
                setCurrentQuestion(nextQuestion);
            } else {
                if(score + 1 == 5)
                {
                    axios.get('http://localhost:8000/api/userQuiz/'+userId, simpleConfig()).then((res) => {
                        var [firstKey] = Object.keys(exactQuiz);
                        if(res.data[0][firstKey] == 0)
                        {
                            axios.put('http://localhost:8000/api/updateQuiz/'+userId, exactQuiz, simpleConfig()).then((res) => {
                                var body = {'points': (parseInt(userPoints)+100).toString()};
                                axios.put('http://localhost:8000/api/updateUser/'+userId, body, simpleConfig()).then((res) => {
                                    swal({
                                        title: "Kvíz kitöltés",
                                        text: "Ön kapott 100 pontot!",
                                        icon: "success"
                                    }).then(() => location.reload());
                                }).catch((error) => {
                                    swal({
                                        title: "Kvíz kitöltés",
                                        text: "Sikertelen kitöltés!",
                                        icon: "error"
                                    });
                                });
                            }).catch((error) => {
                                swal({
                                    title: "Kvíz kitöltés",
                                    text: "Sikertelen kitöltés!",
                                    icon: "error"
                                });
                            });
                        }
                        else
                        {
                            swal({
                                title: "Kvíz kitöltés",
                                text: "Ön már egyszer kitöltötte ezt a kvízt, ezért nem kap pontot!",
                                icon: "success"
                            }).then(() => location.reload());
                        }
                    });
                }
                setShowScore(true);
            }
        };

        const restart = () => {
            setShowScore(false);
            setCurrentQuestion(0);
            setScore(0);
        }

        const setQuiz = (data) => {
            setExactQuiz(data);
        }

        return (
            <div className='container' align="center">
                <p className='display-2 pt-5 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Tanulás</p>
                <p className='fs-3 pb-5'>Az alábbi tananyagokból megtanulhatja az alapokat, illetve egy kvíz kitöltésével, akár pontokat is szerezhet!</p>
                <div className="card">
                    <div className="card-header" id="headingOne">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                Tananyag #1
                            </button>
                        </h5>
                    </div>
                    <div id="collapseOne" className="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>Alapfogalmak - 1</span><br />
                                <span className='fw-bold'>Bitcoin/altcoin</span><br />
                                Kettő fő csoportja van a kriptovalutáknak: a Bitcoin és az altcoinok. Az
                                altok alternatívák a Bitcoinra, tehát BTC-n kívül az összes többi
                                kriptovalutát jelöli a csoport. Az altok mozgása erősen függ a Bitcoin
                                mozgásától, mert altokat csak Bitcoinból lehet vásárolni.<br />
                                <span className='fw-bold'>Valutapár</span><br />
                                Kettő valuta, amivel szemben a tőzsdén nyithatsz pozíciót. A két
                                leggyakrabban használt valutapár a Bitcoin és az USD, vagy a Tether
                                (USDT). 1USDT=1USD.<br />
                                <span className='fw-bold'>Day trade</span><br /> 
                                Napi kereskedés. Rövid távra nyitott tradek, kereskedések. A daytrade
                                nem jelenti azt, hogy minden nap alkalmas a kereskedésre. A
                                kereskedéshez nagy lendületre van szükség a piacon, ezt a volume
                                (kereslet) nagysága jelzi a grafikonokon. Rövid távú pozíciók esetén
                                célszerű nagyobb nevekkel foglalkozni.<br />
                                <span className='fw-bold'>Swing trade</span><br />
                                Hosszabb, pár hetes időtartamra nyitott pozíciók. Alkalmas időtávok:
                                4h, 1d, 1w<br />
                                <span className='fw-bold'>Long</span><br /> 
                                Árfolyamemelkedésre történő spekulálás. Alacsonyabb áron történő
                                vétel, magasabb áron történő eladás. Ez adja a profitot.<br />
                                <span className='fw-bold'>Short </span><br />
                                Csökkenésre való spekuláció. Eladással kezdődik, és vétellel fejeződik
                                be. Kölcsönügylet.<br />
                                <span className='fw-bold'>Célár</span><br /> 
                                Target price (TP). Akár longra, akár shortra nyitunk pozíciót, célszerű
                                előre meghatározni a célárat, célárakat.<br />
                                <span className='fw-bold'>Tőkeáttét</span><br /> 
                                Arra szolgál, hogy kölcsönbe kapott pénzzel megnöveljük a letétként
                                elhelyezett összeget, és így sokkal nagyobb piaci pozíciót tudjunk
                                nyitni. A befektetők a tőkeáttétel révén remélnek nagyobb hozamot. Ha
                                minden jól alakul, a végső nyereség, levonva belőle a tartozást, sokkal
                                nagyobb lehet, mint az eredetileg befektetett készpénz. Ha a dolgok nem
                                alakulnak jól, komoly veszteség keletkezhet.<br />
                                <span className='fw-bold'>Limit order</span><br /> 
                                Meghatározott áron, meghatározott mennyiségre történő vétel, eladás.<br />
                                <span className='fw-bold'>Market order</span><br />
                                Piaci áron, meghatározott mennyiségre történő vétel, eladás. Piaci ár =abban a pillanatban a legjobban elérhető ár
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_one": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="collapseExample">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_one().length}
                                                </div>
                                                <div className='question-text'>{quiz_one()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_one()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingTwo">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Tananyag #2
                            </button>
                        </h5>
                    </div>
                    <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>Alapfogalmak - 2</span><br />
                                <span className='fw-bold'>Stop-limit</span><br /> 
                                Ha az ár elér egy bizonyos szintet, akkor helyez el a tőzsde megbízást vételre. Feltételes vétel.<br /> 
                                <span className='fw-bold'>Stop-loss </span><br />
                                Veszteség vágást jelent. Ha az ár elér egy adott szintet, akkor helyez el a tőzsde limit vagy market áron megbízást eladásra. Eladásnál alkalmazzák.<br /> 
                                <span className='fw-bold'>Kockázat/hozam tényező</span><br />
                                Risk/reward tényező R/R. A nyitott pozícióknak van beszálló ára, célára és stop-loss-a. Ezek aránya a risk reward tényező. Gyakorta használt R/R = 2. Kétszer akkora a remélt profit (célár), mint a bevállalt kockázat, tehát stop-loss mértéke. Pl: beszálló árhoz képest +10% remélt profit, -5% a max vállalt veszteség.<br /> 
                                <span className='fw-bold'>Eladási ár</span><br />
                                Az eladási ár olyan, mint a kikiáltási ár egy aukción: lényegében azt azárat mutatja, melyen valaki hajlandó eladni egy értékpapírt. A vételiajánlattal vethető össze, mely azt az árat jelenti, amelyen a vevőszívesen megvásárolná az adott értékpapírt. Ezért egy eszköz vagy értékpapír vásárlásakor az eladási árat kell megfizetnünk.<br /> 
                                <span className='fw-bold'>Vételi ár</span><br /> 
                                Az az árfolyam, amin eladunk. Mindig kisebb, mint az eladási ár. <br />
                                <span className='fw-bold'>Volatilitás</span><br /> 
                                Az ármozgások mértéke és gyorsasága. Az elemzők a piac volatilitását, egy indexet és bizonyos értékpapírokat figyelnek. A volatilitás megfigyelésével lehetőség van a kockázat becslésére.<br /> 
                                <span className='fw-bold'>Piaci kapitalizáció</span><br />  
                                A piaci kapitalizáció egyszerű mutató, amely a részvényárfolyamon alapul. A vállalat piaci kapitalizációjának kiszámításához a részvények számát az egy részvény árával kell összeszorozni. Például egy vállalatnak, aminek 10 millió részvénye van és 100 dollár egy részvény ára, a piaci kapitalizációja 1 milliárd dollár<br /> 
                                <span className='fw-bold'>Kis kapitalizáció</span><br />
                                Új nevek a kriptopiacon (RVN, MATIV, WAN...)<br /> 
                                <span className='fw-bold'>Közepes kapitalizáció</span><br /> 
                                TOP 50 kriptovaluta (ZRX, VET, NEO...)<br /> 
                                <span className='fw-bold'>Nagy kapitalizáció</span><br />
                                Top kripto nevek (BTC, ETH, XRP)
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_two": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizTwo" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizTwo">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_two().length}
                                                </div>
                                                <div className='question-text'>{quiz_two()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_two()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingThree">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Tananyag #3
                            </button>
                        </h5>
                    </div>
                    <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>Mi ez és hogyan működik</span><br />    
                                A kriptovaluta egy digitális valuta, ami azt jelenti, hogy kizárólag online lehet vele kereskedni,
                                nincs jelen fizikai formában. Ez rendkívül nagy kontraszt a hagyományos valutához képest,
                                aminek általában egy értékes nemesfém szolgál alapjául, mint például az arany. Azonban amíg
                                a hagyományos valutát a kormány vagy közösség alapján generálják, ezt a virtuális pénzt
                                titkosítási technikákkal hozzák létre. A programozása szabályozza a használatát és a
                                kriptovaluta kibocsátási időpontját.
                                A titkosítási technikák garantálják az értéket és a folyamat megbízhatóságát - attól függően
                                hogyan programozták őket.
                                A decentralizáció ebben az esetben azt jelenti, hogy a kormányok, bankok és a pénzintézetek
                                sem férhetnek hozzá ehhez a kriptopénzhez... kivéve természetesen azt az esetet, amikor a
                                kormány megtiltja a digitális valutával való kereskedést
                                A neve a kriptográfia miatt, az angol crypto szóból illetve előtagból származik, ami jelentése
                                szerint a hagyományos szöveget kiismerhetetlenné és titkossá változtatja; ez a folyamata a
                                titkos adat kóddá változtatásának az extra biztonság eléréséhez. Ehhez hasonlóan a
                                kriptovaluta egyenleged bizalmas információt tartalmaz, ami értelmezhetetlen más számára,
                                valamint az elszámolási folyamat sem változtatható meg, ha a bejegyzést már véglegesítették.
                                A kriptovalutát nem nyomtatják, mint a hagyományos pénzt és nem is engedélyezi egyetlen
                                hatóság sem - automatikusan és pontosan generálódik meghatározott algoritmus szabályok
                                szerint. Az adott valutától függ, hogy milyen algoritmusok ezek.
                                Amikor a felhasználók bitcoint utalnak peer-to-peer hálózatot használnak: közvetlen
                                kapcsolatot a szerverek között, harmadik fél nélkül. A kriptovalutát digitálisan alkották meg,
                                és csak így is lehet őket használni. Megvásárolhatod azokat, amiket már kibányásztak, vagy
                                akár bányászhatsz magadnak is.
                                Minden tranzakció rögzítésre kerül egy nagy főkönyvben, amit blokkláncnak neveznek. Mivel
                                ez a főkönyv mindig publikus, elérhető és minden egyes coint elszámolnak benne, a csalás
                                ezzel a rendszerrel lehetetlen. Folyamatosan frissül az érték fenntartása érdekében.
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_three": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizThree" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizThree">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_three().length}
                                                </div>
                                                <div className='question-text'>{quiz_three()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_three()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingFour">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Tananyag #4
                            </button>
                        </h5>
                    </div>
                    <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                        <div className="card-body">
                        <p className='fs-5'>
                                <span className='fw-bold fs-2'>Mi az a blokklánc?</span><br />
                                A blokklánc egy nyitott, elosztott főkönyv, amely tranzakciókat kódban rögzít. A gyakorlatban
                                kicsit olyan, mint egy főkönyv, amelyet a világ számtalan számítógépén osztanak szét. A
                                tranzakciókat „blokkokban” rögzítik, amelyek aztán összekapcsolódnak a korábbi kriptopénz-
                                utalások „láncán”. Képzeljünk el egy könyvet, ahol minden leírásra kerül, amire az emberek
                                minden nap pénzt költenek. Minden oldal hasonló egy blokkhoz, és az egész könyv ami az
                                oldalak láncba kötve egy blokkláncot alkotnak.
                                A blokklánccal mindenkinek, aki kriptovalutát használ, megvan a saját példánya erről a
                                könyvről az egységes tranzakciós rekord létrehozásához. A szoftver naplózza az összes új
                                tranzakciót, amint bekövetkezik, és a blokklánc minden példányát az új információkkal
                                egyidejűleg frissítik, az összes rekord azonos és pontos megtartása mellett. A csalás
                                megelőzése érdekében minden tranzakciót a két fő ellenőrzési technika egyikével
                                ellenőriznek: a munka igazolása vagy a betét igazolása... Avagy Proof of Work (PoW) és Proof
                                of Stake (PoS).
                            </p>
                            <button onClick={() => {setQuiz({"quiz_four": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizFour" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizFour">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_four().length}
                                                </div>
                                                <div className='question-text'>{quiz_four()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_four()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingFive">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                Tananyag #5
                            </button>
                        </h5>
                    </div>
                    <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>NFT - 1</span><br />
                                A NON-FUNGIBLE TOKEN, azaz a nem-helyettesíthető tokenek hasonlóak a bitcoinhoz és más
                                kriptovalutákhoz, egy kulcsfontosságú különbséggel: míg minden bitcoin cserélhető
                                egymással, ezek nem. Ahogy a neve is sugallja, a nem-helyettesíthető tokenek egyediek. A
                                tokenek virtuális okiratként működnek, és egy digitális eszköz/alkotás tulajdonjogát testesítik
                                meg. Egy digitális főkönyvbe töltődnek fel, ahol a legfontosabb információkat tárolják róluk:
                                a létrehozás dátumát, mikor adták el, mennyiért és kinek.
                                Egyes kivitelekben ezeket az információbiteket egy kriptográfiai hash funkció közvetíti, amely
                                algoritmus ezeket az információkat átveszi és egyedi azonosítóvá alakítja. Ezen információk
                                legkisebb változása más azonosítót generálna. Ez lehetővé teszi a leendő vásárlók számára,
                                hogy egy eszközt ne hamisítsanak meg. Más dizájnokban a metaadatokat egymástól
                                függetlenül tárolják.
                                A nem-helyettesíthető tokenek lehetővé teszik, hogy a digitális művészettől kezdve a
                                pop albumokig bizonyíthatóan eredeti változatokat vásárolj.
                                Más digitális eszközökkel, játékokkal, alkotásokkal ellentétben itt csak egyetlen ember
                                birtokolhatja valóban az NFT tokenekkel támogatott digitális eszközöket, alkotásokat. Olyan,
                                mint az eszköz vagy alkotás digitális útlevele, amely lehetővé teszi hitelességnek
                                megalapozását.
                                Amikor valaki NFT-t vásárol, a digitális termék eredeti jogait szerzi meg, legyen szó zenéről
                                vagy képekről. A vevő megszerzi a digitális termék tulajdonjogát, amelyet feltöltenek egy
                                digitális főkönyvbe, ahol nyomon lehet követni, illetve bizonyítani lehet, a mű keletkezésének
                                idejét, a szerzés vagy továbbértékesítés időpontját, valamint magát a tulajdonjogot.
                                Az érték nagy részét a presztízs jelenteni és maga a tudat, hogy egy eredeti alkotással
                                rendelkezünk. Státusz jár a dolog birtoklásával, ugyanis teljesen más az eredetit tulajdonolni,
                                mint egy másolat.
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_five": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizFive" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizFive">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_five().length}
                                                </div>
                                                <div className='question-text'>{quiz_five()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_five()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingSix">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                Tananyag #6
                            </button>
                        </h5>
                    </div>
                    <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>NFT - 2</span><br />
                                Az NFT felhasználhatók decentralizált alkalmazásokhoz, például kripto-gyűjteményekben
                                vagy kripto-játékokban. Ezenkívül bármilyen bizonyítványt (vezetői engedély, tudományos
                                fokozat és egyéb oklevelek) képviselhetnek, valamint kulcsokat, igazolványokat,
                                személyazonosságokat, végrendeleteket, szavazati jogokat, jegyeket és bármilyen típusú
                                hozzáférési jogot, hűségprogramokat, szerzői jogokat, orvosi adatokat, és még sok mást. Az
                                NFT-k lehetővé teszik bármilyen típusú eszköz, akár digitális, akár valódi, tokenizálását.
                                Ezek a nem helyettesíthető tokenek lehetővé teszik a fizikai tárgyhoz kötött egyedi
                                befektetéseket, mint például egyedi műalkotásokat, ingatlant vagy bármilyen más valós
                                eszközt és értékpapírt. Biztosítják az olyan áruk részleges tulajdonjogát is, amelyek korábban
                                nem voltak könnyen oszthatók, például ingatlanok, műalkotások vagy egyéb emléktárgyak. A
                                fizikai eszközök tokenizálása nagyobb likviditást biztosít a befektetők számára. Lehetőség van
                                egy épület tokenizálására is, ahol egyes tokenek egyszerű tulajdonjogokat képviselhetnek,
                                míg más tokenek különleges kiváltságokat, például hozzáférési jogokat biztosíthatnak. Az NFT-
                                k a digitális művészetben való potenciális felhasználást is segítik az eredetiség, a hitelesség és
                                a tulajdonjog bizonyításában.
                                Az NBA egyes csapatai már használnak NFT-ket például kosárlabda kártya létrehozására és
                                árusítására, de megemlíthetjük a 2018-ban útjára indult Crypto Kitties játékot is, amiben
                                digitális macskákat gyűjtögethettünk. A Nike is hozott már létre digitális cipőket NFT alapon.
                                Ezeket adhatjuk-vehetjük, cserélhetjük, ahogy tehetjük azt fizikai tárgyakkal is. Az egyik
                                legértékesebb NFT, amit eddig eladtak egy Formula 1-es autó digitális változata volt, ami bő
                                százezer dollárért kelt el. Az NFT-k minden bizonnyal komoly jövő előtt állnak, vannak már
                                olyan platformok, amik kifejezetten gyűjthető NFT kereskedését teszi lehetővé. Tucatnyi
                                meghatározó focicsapat is beszállt az utóbbi hónapok során, az NBA csapatokhoz hasonlóan
                                digitális kártyákat hoznak létre a rajongók számára.
                                Persze a sportrajongókon túl másokat is vár a terület, említettük a műkincseket és az
                                ingatlanokat, de ki tudja, hogy mi mindenre lesz használatos a jövőben. Az mindenesetre
                                biztos, hogy érdemes már most megismerkednünk a fogalommal, hiszen jó eséllyel sokszor
                                fogunk még találkozni vele a következő évek során.
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_six": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizSix" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizSix">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_six().length}
                                                </div>
                                                <div className='question-text'>{quiz_six()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_six()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingSeven">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                Tananyag #7
                            </button>
                        </h5>
                    </div>
                    <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>Alapfogalmak mélyebben - 3 </span><br />
                                <span className='fw-bold'>Technikai elemzés</span><br /> 
                                Olyan módszer, amellyel különféle előrejelzéseket készíthetünk az
                                árfolyamok mozgásának irányára vonatkozóan.<br />
                                <span className='fw-bold'>SAFU</span><br /> 
                                „Secure Asset Fund for Users”, azaz Biztonságos Eszköz Alap a Felhasználók számára. A biztonságos eszközöket jelölik így.<br />
                                <span className='fw-bold'>Pump and dump</span><br />
                                Adott cégek részvényeiről hamis előrejelzéseket közölnek. Ezzel
                                vásárlásra ösztönzik a potenciális befektetőket. Amint a téves reklám véget ér, a részvények árai zuhanni kezd, a befektetők pedig elvesztik pénzüket. A csalók úgy nyernek az üzleten, hogy amikor alacsonyak voltak az árak bevásároltak a részvényekből, amikor viszont megugrottak az árak, gyorsan eladták.<br />
                                <span className='fw-bold'>OTC</span><br /> 
                                Over the Counter Market, azaz a tőzsdén kívüli piac.<br />
                                <span className='fw-bold'>Nyílt piaci műveletek</span><br />
                                A deviza-, pénz-, és tőkepiacokon végrehajtott műveletek a központi
                                bankok által.<br />
                                <span className='fw-bold'>Medvecsapda</span><br />
                                A kereskedők egy csoportja azonos időben eladja a kriptovalutáját,
                                ezért az zuhanni kezd. A többi kereskedő látva az árcsökkenést
                                szintén elad, így az árak tovább esnek. A trükköt kitervelő kereskedők ekkor visszavásárolják az eladott kriptovalutáikat, így az ár ismét nőni fog, azaz profitálni fognak.<br />
                                <span className='fw-bold'>Margin </span><br />
                                Fedezeti követelmény, letét egy adott pozíció felvételéhez.<br />
                                <span className='fw-bold'> Margin call </span><br />
                                Akkor kapunk margin callt, ha a számlánkon lévő értékpapír vagy pénz értéke egy adott szint alá esik. A call arra szól, hogy tegyünk pénzt a számlánkra, vagy adjunk el valamennyit a papírjainkból, hogy a fedezeti egyenleg nagyobb legyen.<br />
                                <span className='fw-bold'>Likviditás </span><br />
                                Egy adott eszköz pénzzé tehetőségét jelenti.<br />
                                <span className='fw-bold'>Középárfolyam </span><br />
                                A vételi és az eladási ár számtani átlaga.<br />
                                <span className='fw-bold'>Korrekció </span><br /> 
                                Nagyobb növekedés vagy esés után az árfolyam visszaesik a reálisabb
                                árfolyam tartomány irányába.<br />
                                <span className='fw-bold'>Keresztárfolyam</span><br /> 
                                A nemzetközi piacokon az olyan árfolyam elnevezése, mely két deviza között áll fenn és egyik deviza sem az USD. A magyar terminológiában a fentieknek megfelelően azon árfolyamokat hívjuk keresztárfolyamnak, melyben nem szerepel a magyar forint (HUF).<br />
                                <span className='fw-bold'>Indikátor</span><br /> 
                                A technikai elemzésben során használják az árfolyam trendek és alakzatok előrejelzésére.<br />
                                <span className='fw-bold'>HODL</span><br /> 
                                A befektetés tartása hosszú távon. Az angol „hold” elírásából
                                származik
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_seven": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizSeven" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizSeven">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_seven().length}
                                                </div>
                                                <div className='question-text'>{quiz_seven()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_seven()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingEight">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                Tananyag #8
                            </button>
                        </h5>
                    </div>
                    <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordion">
                        <div className="card-body">
                        <p className='fs-5'>
                                <span className='fw-bold fs-2'>Alapfogalmak mélyebben - 4 </span><br />
                                <span className='fw-bold'>Határidős ügyletek</span><br /> 
                                Tőzsdéken forgalmazott termékek ügyeletei, ahol a szerződő felek megegyeznek egy termék jövőbeni árában.<br />
                                <span className='fw-bold'>Gyertya</span><br /> 
                                Árfolyam grafikon, amely az árfolyam nyitó, záró, minimum és
                                maximum pontjait mutatja meg.<br />
                                <span className='fw-bold'>Gap</span><br />
                                Az árfolyam az előző záráshoz képest nagy ugrással nyit bármelyik
                                irányba. Általában valamilyen bejelentés következménye szokott lenni.
                                <br />
                                <span className='fw-bold'>Fundamentális elemzés</span><br /> 
                                A technikai elemzéstől eltérően, amely elsősorban az árakra, a
                                trendekre és az alakzatokra összpontosít, a fundamentális elemzés
                                inkább az összes rendelkezésre álló adatot veszi figyelembe és az
                                alapján próbálja meghatározni egy piac relatív értékét. Ezután keres
                                eltéréseket a jelenlegi piaci ár és a saját értékelés között, hogy
                                meghatározza a kereskedési lehetőségeket.
                                <br />
                                <span className='fw-bold'>FIFO</span><br />
                                First in, first out. A pozíciók a megnyitás sorrendjében záródnak.<br />
                                <span className='fw-bold'>Fibonacci számok</span><br />
                                Leonardo Fibonacci egy XII. századi olasz matematikus volt, aki egy
                                olyan számsort talált fel, ahol minden egymást követő szám az előző számok összege. Pl.: 1, 1, 2, 3, 5, 8, 13 stb. Bármelyik szám
                                nagyságrendileg az 1,618-szorosa az azt megelőző számnak. A
                                technikai elemzésben használhatóak ezek a számok, amikor a
                                trendekben bekövetkező árfolyam változások közelítenek a Fibonacci számok által meghúzott vonalakhoz.
                                <br />
                                <span className='fw-bold'>Kriptovaluta címek</span><br />
                                A kriptovalutáknak egyedi címük van, amivel meghatározható, hogy
                                hol helyezkedik el a blokkláncon. Ez a cím a kriptovaluta tárolására
                                jött létre. Itt rögzítenek minden tranzakció miatt bekövetkezett
                                változást. Általában 30 karakterből állnak.
                                <br />
                                <span className='fw-bold'> Double spending  </span><br />
                                Dupla költés, ha valaki egyszere két címre is elküldi a kriptovalutáit. A bányászokon és a blokkláncon múlik, hogy melyik tranzakció lesz
                                érvényes.
                                <br />
                                <span className='fw-bold'>BTC árindex  </span><br />
                                (BPI) Bitcoin price index, az átlagos árszintek arányát mutatja meg adott
                                időintervallumban.
                                <br />
                                <span className='fw-bold'>Bálna  </span><br />
                                Nagy mennyiségű digitális valutákkal rendelkező magánszemély vagy szervezet.<br />
                                <span className='fw-bold'>Arbitrázs </span><br /> 
                                Az arbitrázs kereskedési stratégia. Célja profit elérése hasonló vagy
                                megegyező eszközök csekély árfolyam-különbözetének
                                kihasználásával. Az e stratégiát követő befektető rendszerint az egyik
                                helyen vett eszközt azonnal eladja máshol, többnyire magasabb
                                árfolyamon.
                                <br />
                                <span className='fw-bold'>AML </span><br /> 
                                Az EU 2005 óta irányelvek, rendeletek megalkotásával küzd a
                                pénzmosás ellen és a terrorizmus finanszírozásának megszüntetéséért
                                (AML: Anti Money Laundering - Pénzmosás elleni küzdelem)
                                <br />
                                
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_eight": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizEight" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizEight">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_eight().length}
                                                </div>
                                                <div className='question-text'>{quiz_eight()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_eight()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingNine">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                Tananyag #9
                            </button>
                        </h5>
                    </div>
                    <div id="collapseNine" className="collapse" aria-labelledby="headingNIne" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>Elemzés alapok</span><br />
                                Grafikonok vizsgálata által, múltbéli árfolyammozgásokból következtetés a várható
                                árfolyammozgásra. A múltbeli eredmények nem garantálják a jövőbeni eredményeket, ezért
                                fontos a rugalmasság! Minden gyertya egy időintervallumot jelöl. Van 1 perces, 1 órás, 4 órás, 1 napos, 1 hetes és
                                így tovább. Kifejezi az adott időtávon az árváltozást. Kifejezi a nyitó, a záró, a legmagasabb és
                                a legalacsonyabb árat az adott időperiódusban. Testből és kanócból épül fel. A test a nyitó és
                                a záróárakat mutatja be, a kanóc két vége a legmagasabb és a legalacsonyabb árakat
                                szemlélteti. Minél nagyobb a test mérete, annál nagyobb a piaci aktivitás, tehát a vásárlási
                                vagy az eladási nyomás. Hosszú zöld gyertyáknál agresszív vásárlásról, hosszú piros
                                gyertyáknál agresszív eladásról van szó. A kanóc és a test hosszának aránya is sok mindent
                                elárulhat nekünk. Minél közelebb zár, minél hosszabb testtel a kanóc felső végéhez, annál
                                bikább az adott szakasz. Minél közelebb zár, minél hosszabb testtel a kanóc alsó végéhez,
                                annál medvébb az adott szakasz.Az árak trendeket formálnak. Ezeknek 3 fajtája létezik: emelkedő trend, csökkenő trend,
                                oldalazó trend.
                                Az árak trendeket formálnak. Ezeknek 3 fajtája létezik: emelkedő trend, csökkenő trend,
                                oldalazó trend.
                                Az emelkedő trend elsődleges feltétele az előző völgyhöz képest egy újabb magasabb völgy
                                kialakulása. Másodlagos feltétele az egyre magasabb csúcspontok. Ha mindkettő teljesül,
                                akkor állíthatjuk határozottan, hogy emelkedő trenddel van dolgunk. Az emelkedő trendvonal
                                letörése egy bizonyos fokú trendfordulást eredményez.
                                A csökkenő trend elsődleges feltétele, hogy az előző csúcshoz képest újabb alacsonyabb
                                csúcspont alakul ki. Másodlagos feltétele, hogy az előzőnél alacsonyabb aljak jöjjenek létre.
                                Ha mind a két feltétel teljesül, akkor beszélhetünk eső trendről.A támasz szint mindig az eszköz aktuális ára alatt található és általában ott van, ahol a
                                csökkenő árak egy támaszt, pihenőt találnak. Ezen szintek közelében az ár nagyobb
                                valószínűséggel "visszapattan" erről a szintről, mintsem egyből áttörné.
                                Az ellenállási szint mindig feljebb helyezkedik el, mint az eszköz aktuális árfolyama és az árakat
                                felső küszöbként visszatartja az emelkedéstől. A támasz szintekkel ellentétben az ellenállási
                                szintek azt jelentik, hogy az árfolyam nagyobb valószínűséggel visszafordul erről a szintről,
                                mint hogy elsőre áthaladjon rajta. Az ellenállás szintekre vonatkozó általános szabály az, hogy
                                hajlamosak megállítani az árfolyamot a további emelkedések előtt.</p>
                        
                            <button onClick={() => {setQuiz({"quiz_nine": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizNine" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizNine">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_nine().length}
                                                </div>
                                                <div className='question-text'>{quiz_nine()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_nine()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card-header" id="headingTen">
                        <h5 className="mb-0">
                            <button className="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                Tananyag #10
                            </button>
                        </h5>
                    </div>
                    <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordion">
                        <div className="card-body">
                            <p className='fs-5'>
                                <span className='fw-bold fs-2'>További alapok</span><br />
                                <span className='fw-bold'>Airdrop</span><br />
                                A kriptovilágban az airdrop “ingyen kriptopénzt” (tokent vagy coinokat) jelent. Ezt a
                                bizonyos blokkláncokra épülő projektek keretein belül osztanak szét a regisztrálóknak vagy
                                felhasználóknak. Most, hogy már tudod, mi az airdrop, nézzük meg, melyek a legkedveltebb
                                airdrop oldalak.<br />
                                1. Az airdropok teljesen ingyenesek<br />
                                2. Soha ne utalj senkinek előre<br />
                                3. Ha valaki rád ír 98%-hogy átverés. Mindig villanjon fel a sárga lámpa a fejedben.<br />
                                4. Előértékesítésben kizárólag saját felelősségre vásárolj, hiszen a kripto populáris
                                jelenségéből adódóan elképesztően nehéz kiszűrni a hiteles dolgokat<br />
                                5. Amennyiben azt látod, hogy X számú meghívás szükséges ahhoz, hogy megkapd az
                                airdropodat, ez is újból egy sárga jel. A szimpla feladatok után jogosultnak kell lenned
                                az airdropra.<br />
                                6. Mindig nézz utána alaposan mindennek, mielőtt döntést hozol<br />
                                <span className='fw-bold'>Tárcák</span><br />
                                Rengeteg kriptotárca bukkan elő, mióta rohamosan növekedni kezdett a kriptopiac. A sok új
                                lehetőség miatt könnyen bőségzavara lehet az embernek, éppen ezért segíteni szeretnénk
                                ebben. Nézzük meg mit tud a Metamask, ami szerintünk egy nagyon megbízható,
                                felhasználóbarát és esztétikus kriptotárca.
                                Ha DeFi (Decentralised Finance) tokenekhez keresel tárcát, akkor ez a tökéletes választás.
                                Különböző Ethereum alapú, tehát ERC-20-as tokeneket tárolhatunk rajta. A Metamask
                                elérhető böngésző kiegészítésként a Chrome-hoz és a Brave-hez, elérhető az Androidos és
                                ios-es okostelefonokhoz. Telepítéséhez keressünk rá a böngészőben a Metamask kulcssszóra.<br />
                                <span className='fw-bold'>Portfolió kezelés</span><br />
                                A kriptovalutákba való befektetés a kockázatos befektetések közé tartoznak!
                                Azt ajánljuk, mindenki csak annyi tőkét fektessen bele, amennyit nem bán,
                                ha elveszít. Jelenleg rengeteg törvényi kérdés lehet hatással a kriptopiacra.
                                Javasolt tőkefelosztás:<br />
                                1. 30% 2-4db biztos hátterű coin hosszú távra<br />
                                2. 40% 5-10db coinnal való kereskedés megadott célárakkal<br />
                                3. A maradék 30% a jobb áron való pozíciónyitásokhoz. Pl: beszálló 40-50
                                szint között, de az ár leesik 35-ig, akkor ez egy jobb nyitási lehetőség,
                                és ilyeneknél érdemes ezt a 30%-nyi tőkét felhasználni.<br />
                                Ha elértük a 100%-ot kiszedhetjük a beszálló tőkét és onnantól, ahogy megy
                                felfelé apránként szedjük ki a profitot a bika időszak végéig.
                                Az is jó stratégia lehet, ha az adott coin 50%-os növekedésénél 25%-ot
                                realizálunk.
                            </p>
                        
                            <button onClick={() => {setQuiz({"quiz_ten": 1}); setShowScore(false);setCurrentQuestion(0);setScore(0);}} className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#quizTen" aria-expanded="false" aria-controls="collapseExample">
                                Quiz kitöltése
                            </button>
                            <div className="collapse pt-5" id="quizTen">
                                <div className='app'>
                                {showScore ? (
                                    <div className='score-section'>
                                        <p>{score == 5 ? "Sikeresen kitöltötte ezt a kérdéssort!" : "Sajnos nem sikerült helyesen kitöltetnie a kérdéssort!"}</p>
                                        <button className='btn btn-outline-warning' onClick={restart}>Újrakezdés</button>
                                    </div>
                                    ) : (
                                        <>
                                            <div className='question-section'>
                                                <div className='question-count'>
                                                    <span>Kérdés {currentQuestion + 1}</span>/{quiz_ten().length}
                                                </div>
                                                <div className='question-text'>{quiz_ten()[currentQuestion].questionText}</div>
                                                
                                            </div>
                                            <div className='answer-section'>
                                                {quiz_ten()[currentQuestion].answerOptions.map((answerOption, idx) => (
                                                    <button key={idx} className='btn btn-outline-warning' onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                                ))}
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
	

}

export default Learn;

if (document.getElementById('quiz')) {
    ReactDOM.render(<Learn />, document.getElementById('quiz'));
}
