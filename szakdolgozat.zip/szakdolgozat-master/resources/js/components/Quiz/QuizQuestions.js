export const quiz_one = () => {
    const questions = [
		{
			questionText: 'Melyik a leggyakrabban használt valutapár?',
			answerOptions: [
				{ answerText: 'USDT/EUR', isCorrect: false },
				{ answerText: 'USDT/HUF', isCorrect: false },
				{ answerText: 'USDT/USD', isCorrect: true },
				{ answerText: 'USD/EUR', isCorrect: false },
			],
		},
		{
			questionText: 'Mit jelent a napi kereskedés?',
			answerOptions: [
				{ answerText: 'Hosszú távú tradek', isCorrect: false },
				{ answerText: 'Rövid távú tradek', isCorrect: true },
				{ answerText: 'Egésznapos tradek', isCorrect: false },
				{ answerText: 'Havi tradek', isCorrect: false },
			],
		},
		{
			questionText: 'Mit jelent a shortolás?',
			answerOptions: [
				{ answerText: 'Spekuláció csökkenésre', isCorrect: true },
				{ answerText: 'Árfolyamemelkedés', isCorrect: false },
				{ answerText: 'Nyitott pozíció', isCorrect: false },
				{ answerText: 'Bitcoin zuhanás', isCorrect: false },
			],
		},
		{
			questionText: 'Mit jelent a swing trade ?',
			answerOptions: [
				{ answerText: 'Rövidtávú kereskedés', isCorrect: false },
				{ answerText: 'Hosszútávú kereskedés', isCorrect: false },
				{ answerText: 'Havi kereskedés', isCorrect: false },
				{ answerText: 'Heti kereskedés', isCorrect: true },
			],
		},
        {
			questionText: 'Mit jelent a tőkeáttét?',
			answerOptions: [
				{ answerText: 'Nagyobb esély a nyereségre', isCorrect: false },
				{ answerText: 'Kevesebb pénzünk lesz', isCorrect: false },
				{ answerText: 'Megnöveljük az összegünket', isCorrect: true },
				{ answerText: 'Felesleges dolog', isCorrect: false },
			],
		}
	];
    return questions;
}

export const quiz_two = () => {
    const questions = [
		{
			questionText: 'Mi a stop-limit?',
			answerOptions: [
				{ answerText: 'Feltétel nélküli vétel', isCorrect: false },
				{ answerText: 'Feltételes vétel', isCorrect: true },
				{ answerText: 'Bitcoin vásárlás', isCorrect: false },
				{ answerText: 'Tőzsdei vásárlás', isCorrect: false },
			],
		},
		{
			questionText: 'Mi jellemző a kis kapitalizációs kriptovalutákra?',
			answerOptions: [
				{ answerText: 'Ezek a top kriptok', isCorrect: false },
				{ answerText: 'A legmagabiztosabbak', isCorrect: false },
				{ answerText: 'Új nevek a blokkláncon', isCorrect: true },
				{ answerText: 'Top 50 része', isCorrect: false },
			],
		},
		{
			questionText: 'Mi a stop-loss?',
			answerOptions: [
				{ answerText: 'Veszteség vágás', isCorrect: true },
				{ answerText: 'Nyereségi vágás', isCorrect: false },
				{ answerText: 'Vásárlási alkalom', isCorrect: false },
				{ answerText: 'Valuta vásár', isCorrect: false },
			],
		},
		{
			questionText: 'Mi a volatilitás?',
			answerOptions: [
				{ answerText: 'Profit számlálás', isCorrect: false },
				{ answerText: 'Altcoin növekedés', isCorrect: false },
				{ answerText: 'Bitcoin mozgása', isCorrect: false },
				{ answerText: 'Mértéke és gyorsasága', isCorrect: true },
			],
		},
        {
			questionText: 'Mit jelent a piaci kapitalizáció?',
			answerOptions: [
				{ answerText: 'Bitcoin ára', isCorrect: false },
				{ answerText: 'Ethereum szerződés', isCorrect: false },
				{ answerText: 'Egyszerű mutató', isCorrect: true },
				{ answerText: 'Egy kriptovaluta', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_three = () => {
    const questions = [
		{
			questionText: 'Mi a kriptovaluta?',
			answerOptions: [
				{ answerText: 'Maga a Forint', isCorrect: false },
				{ answerText: 'Fizikális pénznem', isCorrect: false },
				{ answerText: 'Digitális valuta', isCorrect: true },
				{ answerText: 'Bitcoin', isCorrect: false },
			],
		},
		{
			questionText: 'Miért jó a decentralizáltság?',
			answerOptions: [
				{ answerText: 'Egyáltalán nem jó', isCorrect: false },
				{ answerText: 'Senki nem fér hozzá', isCorrect: true },
				{ answerText: 'Sok pénzt kereshetünk', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
			],
		},
		{
			questionText: 'Mit szabályoz a kriptovaluta programozása?',
			answerOptions: [
				{ answerText: 'Használatát', isCorrect: true },
				{ answerText: 'Az árát', isCorrect: false },
				{ answerText: 'Kik cserélhetik', isCorrect: false },
				{ answerText: 'Semmit sem', isCorrect: false },
			],
		},
		{
			questionText: 'Hogyan jön létre a kriptovaluta',
			answerOptions: [
				{ answerText: 'Az USA gyártja', isCorrect: false },
				{ answerText: 'Európa által', isCorrect: false },
				{ answerText: 'Kormány által', isCorrect: false },
				{ answerText: 'Automatikusan', isCorrect: true },
			],
		},
        {
			questionText: 'Milyen hálózatot használunk Bitcoin cseréhez?',
			answerOptions: [
				{ answerText: 'Titkos hálózatot', isCorrect: false },
				{ answerText: 'Magát az internetet', isCorrect: false },
				{ answerText: 'Peer-to-Peer', isCorrect: true },
				{ answerText: 'Semmilyet sem', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_four = () => {
    const questions = [
		{
			questionText: 'Mi a blokklánc?',
			answerOptions: [
				{ answerText: 'Elosztott könyvek', isCorrect: false },
				{ answerText: 'Tranzakciók sokasága', isCorrect: false },
				{ answerText: 'Elosztott főkönyv', isCorrect: true },
				{ answerText: 'Nem tudom', isCorrect: false },
			],
		},
		{
			questionText: 'Miben rögzülnek a tranzakciók?',
			answerOptions: [
				{ answerText: 'Sehol', isCorrect: false },
				{ answerText: 'A könyvben', isCorrect: false },
				{ answerText: 'Blokkokban', isCorrect: true },
				{ answerText: 'A gépemen', isCorrect: false },
			],
		},
		{
			questionText: 'Szoftver naplózza az összes tranzakciót?',
			answerOptions: [
				{ answerText: 'Igen', isCorrect: true },
				{ answerText: 'Nem', isCorrect: false },
				{ answerText: 'Egy részét', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
			],
		},
		{
			questionText: 'Mindenkinek van saját példánya a blokkláncról?',
			answerOptions: [
				{ answerText: 'Csak egy részéről', isCorrect: false },
				{ answerText: 'Nem, mivel lehetetlen', isCorrect: false },
				{ answerText: 'Nem', isCorrect: false },
				{ answerText: 'Igen', isCorrect: true },
			],
		},
        {
			questionText: 'Mivel kapcsolódnak össze az új blokkok?',
			answerOptions: [
				{ answerText: 'Bitcoinra', isCorrect: false },
				{ answerText: 'Semmihez', isCorrect: false },
				{ answerText: 'A korábbi lánchoz', isCorrect: true },
				{ answerText: 'A többi blokkhoz', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_five = () => {
    const questions = [
		{
			questionText: 'Mi az NFT?',
			answerOptions: [
				{ answerText: 'Egy kriptovaluta', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
				{ answerText: 'Cserélhető tárgy', isCorrect: false },
				{ answerText: 'Egyedi eszköz', isCorrect: true },
			],
		},
		{
			questionText: 'Mit tárolnak el az NFT-ről feltöltés után?',
			answerOptions: [
				{ answerText: 'Bitcoin születését', isCorrect: false },
				{ answerText: 'Eladási árát', isCorrect: true },
				{ answerText: 'Kriptovalutákat', isCorrect: false },
				{ answerText: 'NFT piaic információit', isCorrect: false },
			],
		},
		{
			questionText: 'Hány ember birtokolhatja az NFT-t?',
			answerOptions: [
				{ answerText: 'Egy ember', isCorrect: true },
				{ answerText: 'Akár többen', isCorrect: false },
				{ answerText: 'Senki sem', isCorrect: false },
				{ answerText: 'Elon Musk', isCorrect: false },
			],
		},
		{
			questionText: 'Abban az esetben, ha készítek egy képernyőképet, akkor az enyém lesz az NFT?',
			answerOptions: [
				{ answerText: 'Nem tudom', isCorrect: false },
				{ answerText: 'Tulajdonosa leszek', isCorrect: false },
				{ answerText: 'Igen', isCorrect: false },
				{ answerText: 'Nem', isCorrect: true },
			],
		},
        {
			questionText: 'Létezik két egyenlő NFT?',
			answerOptions: [
				{ answerText: 'Rengeteg létezhet', isCorrect: false },
				{ answerText: 'Igen', isCorrect: false },
				{ answerText: 'Nem, más a meta adat.', isCorrect: true },
				{ answerText: 'Fogalmam sincsen', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_six = () => {
    const questions = [
		{
			questionText: 'Az NFT-k lehetővé teszik, hogy minden akár egy digitális token legyen?',
			answerOptions: [
				{ answerText: 'Természetesen igen', isCorrect: true },
				{ answerText: 'Nem, ez lehetetlen', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
				{ answerText: 'Talán', isCorrect: false },
			],
		},
		{
			questionText: 'A jövőben elképzelhető, hogy mindenhez tartozni fog egy NFT?',
			answerOptions: [
				{ answerText: 'Nem megoldható', isCorrect: false },
				{ answerText: 'Igen, nagyrészt', isCorrect: true },
				{ answerText: 'Elon Muskon múlik', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
			],
		},
		{
			questionText: 'Mely nagy cég vetette már bele magát?',
			answerOptions: [
				{ answerText: 'Nike', isCorrect: true },
				{ answerText: 'Under Armour', isCorrect: false },
				{ answerText: 'Intel', isCorrect: false },
				{ answerText: 'Apple', isCorrect: false },
			],
		},
		{
			questionText: 'Ön szerint lehetséges átverés az NFT piacon belül?',
			answerOptions: [
				{ answerText: 'Meta adat miatt nem lehet', isCorrect: false },
				{ answerText: 'Nem megoldható', isCorrect: false },
				{ answerText: 'Nagyon könnyen igen', isCorrect: true },
				{ answerText: 'Nem tudom', isCorrect: false },
			],
		},
        {
			questionText: 'Mi a legnagyobb veszélye az átverésnek?',
			answerOptions: [
				{ answerText: 'Lementett képek másik NFT-ről', isCorrect: false },
				{ answerText: 'Semmi sem veszélyes', isCorrect: false },
				{ answerText: 'A kamu projektek', isCorrect: true },
				{ answerText: 'A meta adatok', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_seven = () => {
    const questions = [
		{
			questionText: 'Mi a SAFU?',
			answerOptions: [
				{ answerText: 'Biztonságos eszközök', isCorrect: true },
				{ answerText: 'Nem biztonságos eszköz', isCorrect: false },
				{ answerText: 'Fogalmam sincsen', isCorrect: false },
				{ answerText: 'Sok mindent jelent', isCorrect: false },
			],
		},
		{
			questionText: 'Mi a medvecsapda?',
			answerOptions: [
				{ answerText: 'Az erdőben található csapda', isCorrect: false },
				{ answerText: 'Sokan vesznek egyidőben', isCorrect: false },
				{ answerText: 'Sok eladás egy időben', isCorrect: true },
				{ answerText: 'Semmit sem jelent', isCorrect: false },
			],
		},
		{
			questionText: 'Mit jelent a korrekció?',
			answerOptions: [
				{ answerText: 'Árfolyam visszesés', isCorrect: true },
				{ answerText: 'Árfolyam növekedés', isCorrect: false },
				{ answerText: 'Sok pénz jövetelét', isCorrect: false },
				{ answerText: 'Semmit sem', isCorrect: false },
			],
		},
		{
			questionText: 'Mi jellemző a HODL-re?',
			answerOptions: [
				{ answerText: 'Azonnali eladás', isCorrect: false },
				{ answerText: 'Azonnali vétel', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
				{ answerText: 'Hosszútávú tartás', isCorrect: true },
			],
		},
        {
			questionText: 'Mi a likviditás?',
			answerOptions: [
				{ answerText: 'Pénzzé tehetőség', isCorrect: true },
				{ answerText: 'Pénz vesztés', isCorrect: false },
				{ answerText: 'Profit jövetel', isCorrect: false },
				{ answerText: 'Profit vesztés', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_eight = () => {
    const questions = [
		{
			questionText: 'Kik a bálnák?',
			answerOptions: [
				{ answerText: 'Elon Musk', isCorrect: false },
				{ answerText: 'Egy cég', isCorrect: false },
				{ answerText: 'Magánszemélyek', isCorrect: true },
				{ answerText: 'Egy csoport', isCorrect: false },
			],
		},
		{
			questionText: 'Mi a gyertya?',
			answerOptions: [
				{ answerText: 'Meggyújtható tárgy', isCorrect: false },
				{ answerText: 'Árfolyam grafikon', isCorrect: true },
				{ answerText: 'Maga az árfolyam', isCorrect: false },
				{ answerText: 'Semmi sem', isCorrect: false },
			],
		},
		{
			questionText: 'Mit tartalmaz a gyertya?',
			answerOptions: [
				{ answerText: 'Nyitó pontokat', isCorrect: true },
				{ answerText: 'Eladási árámat', isCorrect: false },
				{ answerText: 'Vételi áramat', isCorrect: false },
				{ answerText: 'Az összesen innen', isCorrect: false },
			],
		},
		{
			questionText: 'Mit mondhatunk el a fundamentális elemzésről?',
			answerOptions: [
				{ answerText: 'Gyertya elemzés', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
				{ answerText: 'Grafikon elemzés', isCorrect: false },
				{ answerText: 'Minden adatot figyelembe vesz', isCorrect: true },
			],
		},
        {
			questionText: 'Ön szerint bárki lehet bálna?',
			answerOptions: [
				{ answerText: 'Nem lehet mindenki', isCorrect: false },
				{ answerText: 'Csak Elon Musk lehet', isCorrect: false },
				{ answerText: 'Persze', isCorrect: true },
				{ answerText: 'Jó kapcsolatok kellenek', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_nine = () => {
    const questions = [
		{
			questionText: 'Mit jelöl egy gyertya?',
			answerOptions: [
				{ answerText: 'Eladási árakat', isCorrect: false },
				{ answerText: 'Grafikont', isCorrect: false },
				{ answerText: 'Ármozgást', isCorrect: false },
				{ answerText: 'Időintervallumot', isCorrect: true },
			],
		},
		{
			questionText: 'A felsoroltak közül, miket fejez ki egy gyertya?',
			answerOptions: [
				{ answerText: 'Nyitó árat', isCorrect: false },
				{ answerText: 'Záró árat', isCorrect: false },
				{ answerText: 'Az összeset innen', isCorrect: true },
				{ answerText: 'Legmagasabb árat', isCorrect: false },
			],
		},
		{
			questionText: 'Miből épül fel a gyertya?',
			answerOptions: [
				{ answerText: 'Test és kanócból', isCorrect: true },
				{ answerText: 'Viaszból', isCorrect: false },
				{ answerText: 'Az árakból', isCorrect: false },
				{ answerText: 'Semmiből', isCorrect: false },
			],
		},
		{
			questionText: 'Milyen trendek léteznek?',
			answerOptions: [
				{ answerText: 'Emelkedő trend', isCorrect: false },
				{ answerText: 'Csökkenő trend', isCorrect: false },
				{ answerText: 'Oldalazó trend', isCorrect: false },
				{ answerText: 'Az összes innen', isCorrect: true },
			],
		},
        {
			questionText: 'Mi a feltétele a csökkenő trendnek?',
			answerOptions: [
				{ answerText: 'Nagyobb csúcs alakul ki', isCorrect: false },
				{ answerText: 'Semmi sem', isCorrect: false },
				{ answerText: 'Alacsonyabb csúcs alakul ki', isCorrect: true },
				{ answerText: 'Az ármozgás', isCorrect: false },
			],
		}
	];
	return questions;
}

export const quiz_ten = () => {
    const questions = [
		{
			questionText: 'Mi az Airdrop?',
			answerOptions: [
				{ answerText: 'Ingyen kriptopénz', isCorrect: true },
				{ answerText: 'Fizetett eszköz', isCorrect: false },
				{ answerText: 'Nem tudom', isCorrect: false },
				{ answerText: 'Egy kriptovaluta', isCorrect: false },
			],
		},
		{
			questionText: 'Mi a teendő, ha valaki rád ír, hogy van egy jó lehetőség?',
			answerOptions: [
				{ answerText: 'Elfogadom', isCorrect: false },
				{ answerText: 'Átverés, nem érdekel', isCorrect: true },
				{ answerText: 'Utalok neki pénzt', isCorrect: false },
				{ answerText: 'Elküldöm másnak is', isCorrect: false },
			],
		},
		{
			questionText: 'Milyen kriptovalutákat tárolhatunk MetaMask-on?',
			answerOptions: [
				{ answerText: 'ERC-20 tokeneket', isCorrect: true },
				{ answerText: 'Az összeset', isCorrect: false },
				{ answerText: 'Shiba Inu tokenjeit', isCorrect: false },
				{ answerText: 'Csak Bitcoin', isCorrect: false },
			],
		},
		{
			questionText: 'Mennyi pénz a megfelelő a kriptovaluta befektetéshez?',
			answerOptions: [
				{ answerText: 'A fele pénzem', isCorrect: false },
				{ answerText: 'Semennyi sem', isCorrect: false },
				{ answerText: 'Összes vagyonom', isCorrect: false },
				{ answerText: 'Amennyit nem bánok', isCorrect: true },
			],
		},
        {
			questionText: 'Mi a jó teendő növekedés esetén?',
			answerOptions: [
				{ answerText: 'Semmit sem teszek', isCorrect: false },
				{ answerText: 'Várom a nagyobb nyereséget', isCorrect: false },
				{ answerText: 'Kiszedjük a tőkét, amit beleraktunk', isCorrect: true },
				{ answerText: 'Eladok mindent', isCorrect: false },
			],
		}
	];
	return questions;
}