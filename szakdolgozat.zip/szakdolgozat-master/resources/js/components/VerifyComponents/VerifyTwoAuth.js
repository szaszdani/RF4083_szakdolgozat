import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';

function VerifyTwoAuth() {
    
    const [data, setData] = useState(null);
    let config = {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
    }
    useEffect(() => {
        axios.get('http://localhost:8000/api/userKey', config).then((res) => {
            for(var i = 0; i < res.data.length; i++)
            {
                setData([res.data[i]["fa"]]);
            }
        }).catch((err) => {
            console.log(err);
        });
    }, []);

    const complete2FA = () => {
        const body = {'inputCode': document.getElementById('inputCode').value,'secretKey': document.getElementById('secretKey').value};
        axios.post('http://localhost:8000/api/ver', body, config).then((res) => {
            sessionStorage.setItem('loginToken', localStorage.getItem('token'));
            localStorage.removeItem('token');
            swal({
                title: "Bejelentkezés",
                text: "Sikeresesen bejelentkezés!",
                icon: "success"
            }).then(function() {
                window.location.href = "http://localhost:8000/";
            });
        }).catch((error) => {
            swal({
                title: "Kétlépcsős azonosítás",
                text: error.response.data.message,
                icon: "error",
                button: "Bezárás"
            });
        });
    }
    return(
        <div className='container py-5'>
            <div className='pt-5' align='center'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Kétlépcsős azonosítás</p>
                <p className='fs-3 pt-5 pb-5'>A kétlépcsős azonosításhoz kérem használja a Google Authenticator applikációt a telefonján!</p>
                <p className='fs-4'>Kérem adja meg a hitelesítő számát: </p>
                <input className='form-control' id="inputCode" type="number"/>
                {!data ? <></> : data.map((n, idx) =>
                    ( <input key={idx} id="secretKey" type="hidden" value={n} />))
                }
                <div className='pt-5'><button onClick={complete2FA} className='btn btn-outline-warning'>Bejelentkezés</button></div>
                
            </div>
        </div>
    );

}

export default VerifyTwoAuth;

if (document.getElementById('verifytwoauth')) {
    ReactDOM.render(<VerifyTwoAuth />, document.getElementById('verifytwoauth'));
}
