import axios from 'axios';
import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import {config} from '../Commands/Commands';

function ForgotPassword() {

    const [email, setEmail] = useState("");
    let token = document.getElementById('meta_token').getAttribute('content');

    const handleSubmit = (e) => {
        e.preventDefault();
        var body = {'email': email};
        axios.post('/api/forgot-password', body, config()).then(() => {
            swal({
                title: "Jelszó változtatás",
                text: "Sikeresen elküldtünk Önnek egy e-mailt!",
                icon: "success",
                button: "Bezárás"
            }).then(function() {
                window.location.href = "http://localhost:8000/forgot-password";
            });
        }).catch((error) => {
            swal({
                title: "Jelszó változtatás",
                text: error.response.data.message,
                icon: "error",
                button: "Bezárás"
            });
        });
    }

    return(
        <div className='container pt-5' align="center">
            <p className='display-2 pt-3'>Kripto<span className='text-warning'>Bázis</span> - Elfelejtett jelszó</p>
            <p className='fs-3'>A sikeres jelszó visszaállításhoz, kérem adja meg az e-mail címét!</p>
            <form className='pt-5' onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className='h2 text-warning'>E-mail cím:</label>
                    <div className='col-sm-3'>
                        <input type="text" className="form-control"  placeholder="pelda.email@pelda.com" value={email} onChange={(e) => {setEmail(e.target.value)}} />
                    </div>
                </div>
                <input type="hidden" name="_token" value={token} />
                <div className='pt-3'>
                    <button type="submit" className="btn btn-outline-warning"><span className='fs-5 fw-bold'>Küldés</span></button>
                </div>            
            </form>
        </div>
    );
    
}

export default ForgotPassword;

if (document.getElementById('forgot-password')) {
    ReactDOM.render(<ForgotPassword />, document.getElementById('forgot-password'));
}
