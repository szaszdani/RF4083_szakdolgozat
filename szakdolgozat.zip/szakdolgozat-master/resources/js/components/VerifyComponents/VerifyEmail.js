import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import {config} from '../Commands/Commands';

function VerifyEmail() {

    const [token, setToken] = useState("");
    const path = window.location.pathname;
    
    useEffect(() => {
        setToken(path.substring(13));
    },[]);
    

    const verify = () => {
        axios.put('http://localhost:8000/api/userVerify', {'token': token}, config()).then(() => {
            swal({
                title: "Megerősítés",
                text: 'Sikeresen megerősítette a fiókját! Innentől kezdve bejelentkezhet!',
                icon: "success"
            }).then(() => window.location.href = "http://localhost:8000/login");
        }).catch((err) => {
            swal({
                title: "Sikertelen megerősítés",
                text: err.response.data.message,
                icon: "error"
            });
        })
    }
    return(
        <div align="center" className='container py-5'>
            <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />E-mail megerősítés</p>
            <p className='fs-3 pt-5 pb-5'>A fiók megerősítéshez kérem kattintson a megerősítés gombra!</p>
            <button onClick={() => verify()} className='btn btn-outline-warning'>Megerősítés</button>
        </div>
    );

}

export default VerifyEmail;

if (document.getElementById('verify-email')) {
    ReactDOM.render(<VerifyEmail />, document.getElementById('verify-email'));
}
