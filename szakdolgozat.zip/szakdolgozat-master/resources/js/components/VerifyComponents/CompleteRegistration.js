import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';

function CompleteRegistration() {
    const [data, setData] = useState(null);
    const [inputCode, setInputCode] = useState("");
    var token;
    if(localStorage.getItem('token'))
    {
        token = localStorage.getItem('token')
    }
    else
    {
        token = sessionStorage.getItem('loginToken')
    }

    let config = {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
    }

    useEffect(() => {
        const body = {};
        axios.post('http://localhost:8000/api/gen', body, config).then((res) => {
            setData([res.data]);
        }).catch((error) => {
            swal({
                title: "Kétlépcsős azonosítás",
                text: error.response.data.message,
                icon: "error",
                button: "Bezárás"
            });
        });
    }, []);

    const showInput = () => {
        var input = document.getElementById('inputField');
        input.classList.remove("d-none");
        input.classList.add("d-inline");
    }

    const complete2FA = () => {
        const body = {'inputCode': inputCode,'secretKey': document.getElementById('secretKey').value};
        axios.post('http://localhost:8000/api/ver', body, config).then((res) => {
            swal({
                title: "Kétlépcsős azonosítás",
                text: "Sikeresesen beállította a kétlépcsős azonosítást!",
                icon: "success"
            }).then(function() {
                if(!sessionStorage.getItem('loginToken'))
                {
                    sessionStorage.setItem('loginToken', localStorage.getItem('token'));
                }
                localStorage.removeItem('token');
                window.location.href = "http://localhost:8000/";
            });
        }).catch((error) => {
            swal({
                title: "Kétlépcsős azonosítás",
                text: error.response.data.message,
                icon: "error",
                button: "Bezárás"
            });
        });
    }

    return(
        <div className='container py-5'>
            <div className='pt-5' align='center'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Kétlépcsős azonosítás</p>
                <p className='fs-3 pt-5 pb-5'>A kétlépcsős azonosításhoz kérem használja a Google Authenticator applikációt a telefonján!</p>
                {!data ? <p>Betöltés</p> : data.map((n, idx) =>
                    (<div key={idx}>
                        <p className='fs-5'>Ezt a titkos kulcsot kérem mentse el: {n.secretKey}</p><br />
                        <img className='py-5' src={"http://localhost:8000/storage/"+ n.email +".svg"}></img><br />
                        <button className='btn btn-outline-warning' onClick={() => showInput()}>Következő</button>
                        <div id="inputField" className='d-none'>
                            <p className='pt-5 fs-4'>Kérem adja meg a hitelesítő számát: </p>
                            <input className='form-control' id="inputCode" onChange={(e) => {setInputCode(e.target.value)}} type="number"/>
                            <input id="secretKey" type="hidden" value={n.secretKey}/><br/>
                            <button onClick={() => complete2FA()} className='btn btn-outline-warning'>Tovább</button>
                        </div>
                    </div>))
                }
            </div>
        </div>
    );

}

export default CompleteRegistration;

if (document.getElementById('complete-registration')) {
    ReactDOM.render(<CompleteRegistration />, document.getElementById('complete-registration'));
}
