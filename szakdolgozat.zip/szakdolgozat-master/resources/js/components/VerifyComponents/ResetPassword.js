import axios from 'axios';
import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import {config} from '../Commands/Commands';

function ResetPassword() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");

    let token = document.getElementById('meta_token').getAttribute('content');
    const path = window.location.pathname;
    const tokenP = path.substring(16);
    
    const handleSubmit = (e) => {
        e.preventDefault();
        var body = {'email': email, 'password':password, 'password_verify':newPassword, 'token': tokenP};
        axios.post('/api/reset-password', body, config()).then(() => {
            swal({
                title: "Jelszó változtatás",
                text: "Sikeresen megváltoztatta a jelszavát!",
                icon: "success",
                button: "Bezárás"
            }).then(function() {
                window.location.href = "http://localhost:8000/login";
            });
        }).catch((error) => {
            swal({
                title: "Jelszó változtatás",
                text: error.response.data.message,
                icon: "error",
                button: "Bezárás"
            });
        });
    }

    return(
        <div className='container pt-5' align="center">
            <p className='display-2 pt-3'>Kripto<span className='text-warning'>Bázis</span> - Elfelejtett jelszó</p>
            <p className='fs-3'>A sikeres jelszó visszaállításhoz, kérem töltse ki az alábbi mezőket!</p>
            <form className='pt-5' onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className='h2 text-warning'>E-mail cím:</label>
                    <div className='col-sm-3'>
                        <input type="text" className="form-control"  placeholder="pelda.email@pelda.com" value={email} onChange={(e) => {setEmail(e.target.value)}} />
                    </div>
                    <label className='pt-2 h2 text-warning'>Új jelszó:</label>
                    <div className='col-sm-3'>
                        <input type="password" className="form-control"  placeholder="pelda.jelszo" value={password} onChange={(e) => {setPassword(e.target.value)}} />
                        <small className="form-text text-muted">
                            6-15 közötti karakterszám legyen!
                        </small>
                    </div>
                    
                    <label className='pt-2 h2 text-warning'>Új jelszó mégegyszer:</label>
                    <div className='col-sm-3'>
                        <input type="password" className="form-control"  placeholder="pelda.jelszo" value={newPassword} onChange={(e) => {setNewPassword(e.target.value)}} />
                    </div>
                    <small className="form-text text-muted">
                        6-15 közötti karakterszám legyen!
                    </small>
                </div>
                <input type="hidden" name="_token" value={token} />
                <div className='pt-3'>
                    <button type="submit" className="btn btn-outline-warning"><span className='fs-5 fw-bold'>Küldés</span></button>
                </div>            
            </form>
        </div>
    );
    
}

export default ResetPassword;

if (document.getElementById('reset-password')) {
    ReactDOM.render(<ResetPassword />, document.getElementById('reset-password'));
}
