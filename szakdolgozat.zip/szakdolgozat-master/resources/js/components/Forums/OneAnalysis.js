import React, {useState, useEffect} from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import swal from 'sweetalert';
import {getUserId, simpleConfig, isLoggedIn} from '../Commands/Commands';

function OneAnalysis() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [userId, setUserId] = useState(0);
        const [like, setLike] = useState(false);
        const [userRank, setUserRank] = useState(null);
        const [answers, setAnswers] = useState(null);
        const [load, setLoad] = useState(true);
        const path = window.location.pathname;
        const analysisId = path.substring(10);
        
        useEffect(() => {
        getUserId(simpleConfig()).then((response) => {
                var id = response.data.id;
                setUserId(id);
                axios.get('http://localhost:8000/api/users/'+id, simpleConfig()).then((response) => {
                    setUserRank(response.data.user_rank);
                }).catch((err) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error"
                    });
                });
            }).catch((error) => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
            axios.get('http://localhost:8000/api/oneAnalysis/'+analysisId, simpleConfig()).then((response) => {
                setData([response.data]);
                if(!response.data)
                {
                    setLoad(false);
                }
                else
                {
                    axios.get('http://localhost:8000/api/oneAnalysisMsg/'+analysisId, simpleConfig()).then((response) => {
                        setAnswers(response.data);
                    }).catch((err) => {
                        swal({
                            title: "Üzenetek lekérdezése",
                            text: "Sikertelen lekérdezés!",
                            icon: "error"
                        });
                    });
                    var countView = parseInt(response.data.viewing)+1;
                    axios.post('http://localhost:8000/api/changeAnalysis/'+analysisId, {'viewing' : countView}, simpleConfig()).then(() => {
                    }).catch(() => {
                        swal({
                            title: "Elemzés frissítés",
                            text: "Sikertelen frissítés!",
                            icon: "error"
                        });
                    });
                }
                
            }).catch((err) => {
                swal({
                    title: "Elemzés lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }, []);

        const changeAnswer = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var analysisMsgId = data[0].innerHTML;
            swal({
                text: 'Adjon meg egy új leírást! (5-250 karakter között)',
                content: "input",
                button: {
                text: "Mentés",
                }
            }).then((content) => {
                if(content)
                {
                    var body = {'msg_content' : content};
                    axios.put('http://localhost:8000/api/changeAnalysisMsg/'+analysisMsgId, body, simpleConfig()).then(() => {
                        swal({
                            title: "Üzenet frissítés",
                            text: "Sikeresen frissítette a leírást!",
                            icon: "success"
                        }).then(function() {
                            location.reload();
                        });
                    }).catch((err) => {
                        swal({
                            title: "Üzenet frissítés",
                            text: err.response.data.message,
                            icon: "error"
                        });
                    });
                }
            });
        }

        const createAnalysisMsg = () => {
            swal({
                text: 'Adjon meg az üzenet tartalmát! (5-250 karakter között)',
                content: "input",
                button: {
                text: "Mentés",
                }
            }).then((content) => {
                if(content)
                {
                    var body = {'users_id': userId, 'analysis_id' : analysisId, 'msg_content': content};
                    axios.post('http://localhost:8000/api/createAnalysisMsg', body, simpleConfig()).then(() => {
                        swal({
                            title: "Üzenet létrehozása",
                            text: "Sikeresen létrehozta az üzenetet!",
                            icon: "success"
                        }).then(function() {
                            location.reload();
                        });
                    }).catch((err) => {
                        swal({
                            title: "Üzenet létrehozása",
                            text: err.response.data.message,
                            icon: "error"
                        });
                    });
                }
            });
        }

        const deleteAnalysisMsg = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var analysisMsg = data[0].innerHTML;
            axios.delete('http://localhost:8000/api/deleteAnalysisMsg/'+analysisMsg, simpleConfig()).then(() => {
                swal({
                    title: "Üzenet törlés",
                    text: "Sikeresen törölte az üzenetet!",
                    icon: "success"
                }).then(function() {
                    location.reload();
                });
            }).catch((err) => {
                swal({
                    title: "Üzenet törlés",
                    text: err.response.data.message,
                    icon: "error"
                });
            });
        }

        const setId = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var userId = data[3].innerHTML;
            document.getElementById('users_id').value = userId;
        }

        const banUser = () => {
            var body = {
                'users_id': document.getElementById('users_id').value,
                'ban_acc': userId,
                'date_end': document.getElementById('date_end').value, 
                'reason': document.getElementById('reason').value
            };
            axios.post('http://localhost:8000/api/createBanList', body, simpleConfig()).then(() => {
                swal({
                    title: "Felhasználó kitiltása",
                    text: "Sikeresen kitiltotta a felhasználót!",
                    icon: "success"
                }).then(function() {
                    location.reload();
                });
            }).catch((err) => {
                swal({
                    title: "Felhasználó kitiltása",
                    text: err.response.data.message,
                    icon: "error"
                });
            });
        }
        const likeAnalysis = () => {   
            var body = {'likes': (parseInt(data[0].likes)+1).toString()};
            axios.post('http://localhost:8000/api/changeAnalysis/'+analysisId,body, simpleConfig()).then(() => {
                setLike(true);
                swal({
                    title: "Elemzés kedvelése",
                    text: "Sikeresen kedvelte ezt az elemzést!",
                    icon: "success"
                });
            }).catch(() => {
                swal({
                    title: "Elemzés kedvelése",
                    text: "Sikertelen kedvelés",
                    icon: "error"
                });
            });
        }
        return (
            <div className="pt-5 container" align="center">
                {!load ? <h1>Elemzés nem található!</h1> : !data ? <h1 align="center">Betöltés...</h1> : data.map((n, idx) =>
                    (<div key={idx}>
                        <p className='display-2 pt-5 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Felhasználói elemzés</p>
                        <p className='fs-3 text-warning'>Cím:</p>
                        <p className='fs-4'>{n.title}</p>
                        <p className='fs-3 text-warning'>Leírás:</p>
                        <p className='fs-4'>{n.content}</p>
                        <p className='fs-3 text-warning'>Kép:</p>
                        {n.img != null ? <img src={"http://localhost:8000/storage/images/analysis/"+ n.img}></img> : <p className='fs-4'>Nincsen csatolt kép a poszthoz.</p>}<br /><br />
                        {!like ? <button onClick={() => likeAnalysis()} className='btn btn-outline-warning'>Kedvelés</button> : <button className='btn btn-warning'>Kedvelés</button>}
                        <div className='pt-5 pb-5'>
                            <p className='fs-3'>Üzenetek</p>
                            <button onClick={() => createAnalysisMsg()} className='btn btn-outline-warning'>Új üzenet létrehozása</button>
                        </div>
                        <div className='table-responsive'>
                            <table className="table table-fluid" id="myTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Létrehozó</th>
                                        <th>Üzenet tartalma</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {!answers ? <tr align="center"><td colSpan="8">Jelenleg még nem érkezett üzenet ehhez a poszthoz!</td></tr> : answers.map((n, idx) =>
                                        (<tr id={idx} key={idx}>
                                            <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                            <td className="row-data align-middle" >{n.user.username}</td>
                                            <td className="row-data align-middle" key={n.msg_content}>{n.msg_content}</td>
                                            <td className="row-data align-middle d-none" >{n.users_id}</td>
                                            {n.users_id == userId || userRank == 3 ? <td><button onClick={(e) => changeAnswer(e)} type="button" className="btn btn-outline-warning">Módosítás</button></td> : <></>}
                                            {userRank == 3 ? <td><button type="button" onClick={(e) => setId(e)} className="btn btn-outline-warning" data-toggle="modal" data-target="#banuser">Kitiltás</button></td> : <></>} 
                                            {userRank == 2 || n.users_id == userId ? <td><button className='btn btn-outline-warning' onClick={(e) => deleteAnalysisMsg(e)}>Törlés</button></td> : <></>}
                                        </tr>))}
                                </tbody>
                            </table>
                        </div>
                        <div className="modal fade" id="banuser" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="exampleModalLabel">Felhasználó kitiltása</h5>
                                </div>
                                <div className="modal-body">
                                    
                                    <div className="form-group pb-3">
                                        <label>Kitiltás vége:</label>
                                        <input id="date_end" className="form-control" type="date" />
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Indok:</label>
                                        <input id="reason" className="form-control" type="text" />
                                    </div>
                                    <input id="users_id" type="hidden" />
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={() => banUser()} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>))
                }
            </div>
        );
    }   
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    

}

export default OneAnalysis;

if (document.getElementById('one-analysis')) {
    ReactDOM.render(<OneAnalysis />, document.getElementById('one-analysis'));
}
