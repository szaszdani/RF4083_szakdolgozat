import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import {simpleConfig, getUserId, isLoggedIn} from '../Commands/Commands';

function Forum() {

    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [userRank, setUserRank] = useState(null);
        const [userId, setUserId] = useState(0);

        useEffect(() => {
            getUserId(simpleConfig()).then((response) => {
                var id = response.data.id;
                setUserId(id);
                axios.get('http://localhost:8000/api/users/'+id, simpleConfig()).then((response) => {
                    setUserRank(response.data.user_rank);
                    axios.get('http://localhost:8000/api/allForum', simpleConfig()).then((res) => {
                        var temp = 0;
                        for(var i = 0; i < res.data.length; i++)
                        {
                            if(res.data[i]["vip"] == 0)
                            {
                                if(temp == 0)
                                {
                                    setData([res.data[i]]);
                                }
                                else
                                {
                                    setData(prev => [...prev, res.data[i]]);
                                }
                                temp++;
                            }
                        }
                    }).catch((err) => {
                        swal({
                            title: "Lekérdezés",
                            text: "Sikertelen lekérdezés!",
                            icon: "error"
                        });
                    })
                }).catch((err) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error"
                    });
                })
            }).catch((error) => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }, []);

        const createForum = () => {
            var body = {
                'forum_owner': userId,
                'title' : document.getElementById('newHeader').value,
                'forum_desc' : document.getElementById('newDesc').value,
                'vip' : document.getElementById('newVIP').value
            };
            axios.post('http://localhost:8000/api/createForum',body, simpleConfig()).then(() => {
                swal({
                    title: "Fórum",
                    text: "Sikeres létrehozás!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch((error) => {
                swal({
                    title: "Fórum",
                    text: error.response.data.message,
                    icon: "error"
                });
            });
        }

        const openForum = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var forum = data[0].innerHTML;
            window.location.href = "http://localhost:8000/forum/"+forum;
        }

        const changeForum = () => {
            var body;
            if(document.getElementById('newForumHeader').value && document.getElementById('newForumDesc').value){
                body = {
                    'title' : document.getElementById('newForumHeader').value,
                    'forum_desc': document.getElementById('newForumDesc').value
                }
            }
            else if(document.getElementById('newForumDesc').value) body = {'forum_desc': document.getElementById('newForumDesc').value};
            else body = {'title' : document.getElementById('newForumHeader').value}
            
            axios.put('http://localhost:8000/api/changeForum/'+document.getElementById('id').value, body, simpleConfig()).then(() => {
                swal({
                    title: "Fórum",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Fórum",
                    text: "Sikertelen frissítés! Kérem ellenőrizze, hogy mindent helyesen adott-e meg!",
                    icon: "error"
                });
            })
        }

        const setId = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var forum = data[0].innerHTML;
            document.getElementById('id').value = forum;
        }

        const deleteForum = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var forum = data[0].innerHTML;
            axios.delete('http://localhost:8000/api/deleteForum/'+forum, simpleConfig()).then(() => {
                swal({
                    title: "Fórum",
                    text: "Sikeres törlés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Fórum",
                    text: "Sikertelen törlés!",
                    icon: "error"
                });
            });
        }

        return(
            <div className='container pt-5'>
                <div className='pt-5' align='center'>
                <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Fórum</p>
                    <p className='fs-3 pb-5'>Az alábbiakban láthatja az elemzők által létrehozott fórumokat, amelyekben elolvashatja az általuk létrehozott posztokat!</p>
                    
                    {!userRank ? <></> : 
                        userRank == 2 || userRank == 3 ? 
                    <div>
                        <div className='pb-5'>
                            <button className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#all" aria-expanded="false" aria-controls="collapseExample">
                                Fórum létrehozása
                            </button> 
                        </div>
                        <div className="collapse p-5" id="all">
                            <div className="card card-body">
                                <div className="form-group pb-3">
                                    <label>Fórum címe:</label>
                                    <input id="newHeader" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        5-25 közötti karakterszám legyen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Leírás:</label>
                                    <input id="newDesc" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        10-100 közötti karakterszám legyen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>VIP Fórum:</label>
                                    <select id="newVIP" className='form-select'>
                                        <option value="0">Nem</option>
                                        <option value="1">Igen</option>
                                    </select>
                                </div>
                                <input id="id" value="" type="hidden"></input>
                                <button onClick={createForum} className='btn btn-outline-warning'>Létrehozás</button>
                            </div>
                        </div>
                        <div className="modal fade" id="changeModal"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="changeModalLabel">Fórum módosítás</h5>
                                </div>
                                <div className="modal-body">
                                    <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                    <div className="form-group pb-3">
                                        <label>Új cím:</label>
                                        <input id="newForumHeader" className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            5-25 közötti karakterszám legyen!
                                        </small>
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Új leírás:</label>
                                        <input id="newForumDesc" className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            10-100 közötti karakterszám legyen!
                                        </small>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={changeForum} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div> : <></>
                    }
                    <div className='table-responsive'>
                        <table className="table table-fluid" id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Cím</th>
                                    <th>Leírás</th>
                                    <th>Létrehozás ideje</th>
                                </tr>
                            </thead>
                            <tbody>
                                {!data ? <tr align="center"><td colSpan="8">Nincsen elérhető fórum!</td></tr> : data.map((n, idx) =>
                                    (<tr id={idx} key={idx}>
                                        <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                        <td id="title" className="row-data align-middle"><button onClick={(e) => openForum(e)} className='btn btn-outline-warning'>{n.title}</button></td>
                                        <td id="desc" className="row-data align-middle">{n.forum_desc}</td>
                                        <td className="row-data align-middle">{n.created_date}</td>
                                        {userRank == 2 || userRank == 3 ? <td className="align-middle" ><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeModal">Módosítás</button></td> : <></>}
                                        {userRank == 2 || userRank == 3 ? <td className="align-middle" ><button onClick={(e) => deleteForum(e)} className='btn btn-outline-warning'>Törlés</button></td> : <></>}
                                    </tr>))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href="http://localhost:8000/"}</p>)
    }
    
}

export default Forum;

if (document.getElementById('forum')) {
    ReactDOM.render(<Forum />, document.getElementById('forum'));
}
