import React, {useState, useEffect} from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import swal from 'sweetalert';
import {simpleConfig, isLoggedIn, getUserId} from '../Commands/Commands';

function OneForum() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [userRank, setUserRank] = useState(null);
        const [userId, setUserId] = useState(0);
        const path = window.location.pathname;
        const forumID = path.substring(7);
    
        useEffect(() => {
            getUserId(simpleConfig()).then((response) => {
                var id = response.data.id;
                setUserId(id);
                axios.get('http://localhost:8000/api/users/'+id, simpleConfig()).then((response) => {
                    setUserRank(response.data.user_rank);
                    var vip = response.data.vip;
                    var rank = response.data.user_rank;
                    axios.get('http://localhost:8000/api/onePerForum/'+forumID, simpleConfig()).then((res) => {
                        setData(res.data);
                        if(res.data)
                        {
                            if(res.data[0].forum.vip == "1" && vip == "0" && rank == "1")
                            {
                                swal({
                                    title: "Fórum VIP",
                                    text: "Ön nem VIP!",
                                    icon: "error"
                                }).then(() => window.location.href = "http://localhost:8000/");
                            }
                        }
                    }).catch((err) => {
                        swal({
                            title: "Lekérdezés",
                            text: "Sikertelen lekérdezés!",
                            icon: "error"
                        });
                    })
                }).catch((err) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error"
                    });
                })
            }).catch((error) => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }, []);
    
        const createPost = () => {
            
            var formData = new FormData();
            formData.append('forum_id', forumID);
            formData.append('users_id', userId);
            formData.append('post_title', document.getElementById('newHeader').value);
            formData.append('post_text', document.getElementById('newText').value);
            if(document.getElementById('newFile').files[0])
            {
                formData.append('img', document.getElementById('newFile').files[0]);
            }
            axios.post('http://localhost:8000/api/createPost',formData, simpleConfig()).then(() => {
                swal({
                    title: "Poszt létrehozás",
                    text: "Sikeres létrehozás!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch((error) => {
                swal({
                    title: "Poszt létrehozás",
                    text: error.response.data.message,
                    icon: "error"
                });
            });
        }
    
        const openPost = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var post = data[0].innerHTML;
            window.location.href = "http://localhost:8000/post/"+post;
        }
    
        const changePost = () => {
            var postData = new FormData();
            if(document.getElementById('newPostHeader').value){
                postData.append('post_title', document.getElementById('newPostHeader').value);
            }
            else if(document.getElementById('newPostText').value) postData.append('post_text', document.getElementById('newPostText').value);
            else if(document.getElementById('newPostImg').files[0]) postData.append('img', document.getElementById('newPostImg').files[0]);
            
            axios.post('http://localhost:8000/api/changePost/'+document.getElementById('id').value, postData, simpleConfig()).then(() => {
                swal({
                    title: "Poszt frissítés",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Poszt frissítés",
                    text: "Sikertelen frissítés!",
                    icon: "error"
                });
            });
        }
    
        const setId = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var post = data[0].innerHTML;
            document.getElementById('id').value = post;
        }
    
        const deletePost = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var post = data[0].innerHTML;
            axios.delete('http://localhost:8000/api/deletePost/'+post, simpleConfig()).then(() => {
                swal({
                    title: "Poszt törlés",
                    text: "Sikeres törlés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Poszt törlés",
                    text: "Sikertelen törlés!",
                    icon: "error"
                });
            });
        }
    
        return(
            <div className='container pt-5'>
                <div className='pt-5' align='center'>
                    <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Fórum posztok</p>
                    <p className='fs-3 pb-5'>Az alábbiakban láthatja az előbbi fórumhoz tartozó posztokat!</p>
                        
                    {!userRank ? <></> : 
                        userRank == 2 || userRank == 3 ? 
                    <div>
                        <div className='pb-5'>
                            <button className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#all" aria-expanded="false" aria-controls="collapseExample">
                                Poszt létrehozása
                            </button>
                        </div>
                        <div className="collapse p-5" id="all">
                            <div className="card card-body">
                                <div className="form-group pb-3">
                                    <label>Poszt címe:</label>
                                    <input id="newHeader" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        5-15 közötti karakterszám legyen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Szöveg:</label>
                                    <input id="newText" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        10-1000 közötti karakterszám legyen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Fájl csatolása:</label>
                                    <input id="newFile" type="file" className='form-control'></input>
                                    <small className="form-text text-muted">
                                        Elfogadott típusok: PNG, JPG, JPEG
                                    </small>
                                </div>
                                <button onClick={createPost} className='btn btn-outline-warning'>Létrehozás</button>
                            </div>
                        </div>
    
                        <div className="modal fade" id="changeModal"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="changeModalLabel">Fórum módosítás</h5>
                                </div>
                                <div className="modal-body">
                                    <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                    <div className="form-group pb-3">
                                        <label>Új cím:</label>
                                        <input id="newPostHeader" className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            5-15 közötti karakterszám legyen!
                                        </small>
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Új leírás:</label>
                                        <input id="newPostText" className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            10-1000 közötti karakterszám legyen!
                                        </small>
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Új fájl:</label>
                                        <input id="newPostImg" className="form-control" type="file" />
                                        <small className="form-text text-muted">
                                            Elfogadott típusok: PNG, JPG, JPEG
                                        </small>
                                        <input id="id" value="" type="hidden"></input>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={changePost} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div> : <></>
                    }
                    <div className='table-responsive'>
                        <table className="table table-fluid" id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Poszt címe</th>
                                    <th>Fórum</th>
                                    <th>Létrehozó</th>
                                    <th>Létrehozás ideje</th>
                                    <th>Megtekintések száma</th>
                                </tr>
                            </thead>
                            <tbody>
                                {!data ? <tr align="center"><td colSpan="8">Nincsen elérhető poszt!</td></tr> : data.map((n, idx) =>
                                    (<tr id={idx} key={idx}>
                                        <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                        <td id="title" className="row-data align-middle"><button onClick={(e) => openPost(e)} className='btn btn-outline-warning'>{n.post_title}</button></td>
                                        <td id="desc" className="row-data align-middle">{n.forum.title}</td>
                                        <td className="row-data align-middle">{n.user.username}</td>
                                        <td className="row-data align-middle">{n.post_date}</td>
                                        <td className="row-data align-middle">{n.post_viewing}</td>
                                        {userRank == 2 || userRank == 3 ? <td className="align-middle" ><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeModal">Módosítás</button></td> : <></>}
                                        {userRank == 2 || userRank == 3 ? <td className="align-middle" ><button onClick={(e) => deletePost(e)} className='btn btn-outline-warning'>Törlés</button></td> : <></>}
                                    </tr>))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
   
}

export default OneForum;

if (document.getElementById('one-forum')) {
    ReactDOM.render(<OneForum />, document.getElementById('one-forum'));
}
