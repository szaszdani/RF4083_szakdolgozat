import React, {useState, useEffect} from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import swal from 'sweetalert';
import {simpleConfig, isLoggedIn} from '../Commands/Commands';

function Analysis() {
    if(isLoggedIn())
    {
        const [data, setData] = useState(null);
        const [ownAnalysis, setOwnAnalysis] = useState(null);
        const [userRank, setUserRank] = useState(null);
        const [userId, setUserId] = useState(0);
        const path = window.location.pathname;
        const forumID = path.substring(7);

        useEffect(() => {
            axios.get('http://localhost:8000/api/userID', simpleConfig()).then((response) => {
                var id = response.data.id;
                setUserId(id);
                axios.get('http://localhost:8000/api/users/'+id, simpleConfig()).then((response) => {
                    setUserRank(response.data.user_rank);
                    axios.get('http://localhost:8000/api/allAnalysis', simpleConfig()).then((res) => {
                        setData(res.data);
                        var temp = 0;
                        for(var i = 0; i < res.data.length; i++)
                        {
                            if(res.data[i].users_id == id)
                            {
                                if(temp == 0)
                                {
                                    setOwnAnalysis([res.data[i]]);
                                }
                                else
                                {
                                    setOwnAnalysis(prev => [...prev, res.data[i]]);
                                }
                                temp++;
                            }
                        }
                    }).catch((err) => {
                        swal({
                            title: "Lekérdezés",
                            text: "Sikertelen lekérdezés!",
                            icon: "error"
                        });
                    })
                }).catch((err) => {
                    swal({
                        title: "Lekérdezés",
                        text: "Sikertelen lekérdezés!",
                        icon: "error"
                    });
                })
            }).catch((error) => {
                swal({
                    title: "Lekérdezés",
                    text: "Sikertelen lekérdezés!",
                    icon: "error"
                });
            });
        }, []);

        const createAnalysis = () => {
            
            var formData = new FormData();
            formData.append('users_id', userId);
            formData.append('title', document.getElementById('newHeader').value);
            formData.append('content', document.getElementById('newText').value);
            if(document.getElementById('newFile').files[0])
            {
                formData.append('img', document.getElementById('newFile').files[0]);
            }
            axios.post('http://localhost:8000/api/createAnalysis',formData, simpleConfig()).then(() => {
                swal({
                    title: "Elemzés létrehozás",
                    text: "Sikeres létrehozás!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch((err) => {
                swal({
                    title: "Elemzés létrehozás",
                    text: err.response.data.message,
                    icon: "error"
                });
            });
        }

        const openAnalysis = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var analysis = data[0].innerHTML;
            window.location.href = "http://localhost:8000/analysis/"+analysis;
        }

        const changeAnalysis = () => {
            var postData = new FormData();
            if(document.getElementById('newAnalysisHeader').value){
                postData.append('title', document.getElementById('newAnalysisHeader').value);
            }
            else if(document.getElementById('newAnalysisText').value) postData.append('content', document.getElementById('newAnalysisText').value);
            else if(document.getElementById('newAnalysisImg').files[0]) postData.append('img', document.getElementById('newAnalysisImg').files[0]);
            
            axios.post('http://localhost:8000/api/changeAnalysis/'+document.getElementById('id').value, postData, simpleConfig()).then(() => {
                swal({
                    title: "Elemzés frissítés",
                    text: "Sikeres frissítés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Elemzés frissítés",
                    text: "Sikertelen frissítés! Kérem ellenőrizze, hogy mindent helyesen adott-e meg!",
                    icon: "error"
                });
            });
        }

        const setId = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var analysis = data[0].innerHTML;
            document.getElementById('id').value = analysis;
        }

        const deleteAnalysis = (event) => {
            var rowId = event.target.parentNode.parentNode.id;
            var data = document.getElementById(rowId).querySelectorAll(".row-data");
            var post = data[0].innerHTML;
            axios.delete('http://localhost:8000/api/deleteAnalysis/'+post, simpleConfig()).then(() => {
                swal({
                    title: "Elemzés törlés",
                    text: "Sikeres törlés!",
                    icon: "success"
                }).then(() => {location.reload()});
            }).catch(() => {
                swal({
                    title: "Elemzés törlés",
                    text: "Sikertelen törlés!",
                    icon: "error"
                });
            });
        }

        const banUser = () => {
            var body = {
                'users_id': document.getElementById('user_id').value,
                'ban_acc': userId,
                'date_end': document.getElementById('date_end').value, 
                'reason': document.getElementById('reason').value
            };
            axios.post('http://localhost:8000/api/createBanList', body, simpleConfig()).then(() => {
                swal({
                    title: "Felhasználó kitiltása",
                    text: "Sikeresen kitiltotta a felhasználót!",
                    icon: "success"
                }).then(function() {
                    location.reload();
                });
            }).catch((err) => {
                swal({
                    title: "Felhasználó kitiltása",
                    text: err.response.data.message,
                    icon: "error"
                });
            });
        }
        return(
            <div className='container pt-5'>
                <div className='pt-5' align='center'>
                    <p className='display-2 pt-3 pb-5'>Kripto<span className='text-warning'>Bázis</span><br />Felhasználói elemzések</p>
                    <p className='fs-3 pb-5'>Az alábbiakban láthatja az felhasználói elemzéseket!</p>
                    <div>
                        <button className="btn btn-outline-warning" type="button" data-toggle="collapse" data-target="#all" aria-expanded="false" aria-controls="collapseExample">
                            Elemzés létrehozása
                        </button> 
                        <div className="collapse p-5" id="all">
                            <div className="card card-body">
                                <div className="form-group pb-3">
                                    <label>Elemzés címe:</label>
                                    <input id="newHeader" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        5-25 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Elemzés szövege:</label>
                                    <input id="newText" className="form-control" type="text" />
                                    <small className="form-text text-muted">
                                        10-1000 karakter között szerepeljen!
                                    </small>
                                </div>
                                <div className="form-group pb-3">
                                    <label>Fájl csatolása:</label>
                                    <input id="newFile" type="file" className='form-control'></input>
                                    <small className="form-text text-muted">
                                        Elfogadott típusok: PNG, JPG, JPEG
                                    </small>
                                </div>
                                <input id="id" value="" type="hidden"></input>
                                <button onClick={createAnalysis} className='btn btn-outline-warning'>Létrehozás</button>
                            </div>
                        </div>

                        <div className="modal fade" id="changeModal"  role="dialog" aria-labelledby="changeModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="changeModalLabel">Elemzés módosítás</h5>
                                </div>
                                <div className="modal-body">
                                    <p>Azon mezőket töltse csak ki, amit megszeretne változtatni! A változatlan mezőket hagyja üresen!</p>
                                    <div className="form-group pb-3">
                                        <label>Új cím:</label>
                                        <input id="newAnalysisHeader" className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            5-25 karakter között szerepeljen!
                                        </small>
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Új leírás:</label>
                                        <input id="newAnalysisText" className="form-control" type="text" />
                                        <small className="form-text text-muted">
                                            10-1000 karakter között szerepeljen!
                                        </small>
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Új fájl:</label>
                                        <input id="newAnalysisImg" className="form-control" type="file" />
                                        <small className="form-text text-muted">
                                            Elfogadott típusok: PNG, JPG, JPEG
                                        </small>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={changeAnalysis} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!ownAnalysis ? <></> : 
                        <div className='table-responsive'>
                            <p className='py-5 fs-3'>Saját elemzések</p>
                            <table className="table table-fluid" id="myTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Elemzés létrehozója</th>
                                        <th>Elemzés címe</th>
                                        <th>Megtekintés száma</th>
                                        <th>Kedvelések száma</th>
                                        <th>Létrehozás ideje</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {!ownAnalysis ? <tr align="center"><td colSpan="8">Nincsen elérhető poszt!</td></tr> : ownAnalysis.map((n, idx) =>
                                        (<tr id={idx} key={idx}>
                                            <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                            <td className="row-data align-middle">{n.user.username}</td>
                                            <td id="title" className="row-data align-middle"><button onClick={(e) => openAnalysis(e)} className='btn btn-outline-warning'>{n.title}</button></td>
                                            <td id="desc" className="row-data align-middle">{n.viewing}</td>
                                            <td className="row-data align-middle">{n.likes}</td>
                                            <td className="row-data align-middle">{n.created_date}</td>
                                            {userId == n.users_id ? <td className="align-middle" ><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeModal">Módosítás</button></td> : <></>}
                                            {userId == n.users_id ? <td className="align-middle" ><button onClick={(e) => deleteAnalysis(e)} className='btn btn-outline-warning'>Törlés</button></td> : <></>}
                                        </tr>))}
                                </tbody>
                            </table>
                        </div>
                    }
                    {!data ? <></> : 
                    <div className='table-responsive'>
                        <p className='py-5 fs-3'>Felhasználói elemzések</p>
                        <table className="table table-fluid" id="myTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Elemzés létrehozója</th>
                                    <th>Elemzés címe</th>
                                    <th>Megtekintés száma</th>
                                    <th>Kedvelések száma</th>
                                    <th>Létrehozás ideje</th>
                                </tr>
                            </thead>
                            <tbody>
                                {!data ? <tr align="center"><td colSpan="8">Nincsen elérhető poszt!</td></tr> : data.map((n, idx) =>
                                    (<tr id={!ownAnalysis ? idx : (idx+ownAnalysis.length)+1} key={idx}>
                                        <td className="row-data align-middle" key={n.id}>{n.id}</td>
                                        <td className="row-data align-middle">{n.user.username} <input id="user_id" type="hidden" value={n.users_id} /></td>
                                        <td id="title" className="row-data align-middle"><button onClick={(e) => openAnalysis(e)} className='btn btn-outline-warning'>{n.title}</button></td>
                                        <td id="desc" className="row-data align-middle">{n.viewing}</td>
                                        <td className="row-data align-middle">{n.likes}</td>
                                        <td className="row-data align-middle">{n.created_date}</td>
                                        {userRank == "3" ? <td className="align-middle" ><button type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#banUser">Kitiltás</button></td> : <></>}
                                        {userRank == "2" || userId == n.users_id || userRank == "3" ? <td className="align-middle" ><button onClick={(e) => setId(e)} type="button" className="btn btn-outline-warning" data-toggle="modal" data-target="#changeModal">Módosítás</button></td> : <></>}
                                        {userRank == "2" || userId == n.users_id || userRank == "3" ? <td className="align-middle" ><button onClick={(e) => deleteAnalysis(e)} className='btn btn-outline-warning'>Törlés</button></td> : <></>}
                                    </tr>))}
                            </tbody>
                        </table>
                        {userRank == "3" ? <div className="modal fade" id="banUser" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title" id="exampleModalLabel">Felhasználó kitiltása</h5>
                                </div>
                                <div className="modal-body">
                                    
                                    <div className="form-group pb-3">
                                        <label>Kitiltás vége:</label>
                                        <input id="date_end" className="form-control" type="date" />
                                    </div>
                                    <div className="form-group pb-3">
                                        <label>Indok:</label>
                                        <input id="reason" className="form-control" type="text" />
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Bezárás</button>
                                    <button onClick={() => banUser()} type="button" className="btn btn-primary">Mentés</button>
                                </div>
                                </div>
                            </div>
                    </div> : <></>}
                    </div>
                    }
                    
                </div>
            </div>
        );
    }
    else
    {
        return (<p className='d-none'>{window.location.href = "http://localhost:8000/"}</p>)
    }
    
}

export default Analysis;

if (document.getElementById('analysis')) {
    ReactDOM.render(<Analysis />, document.getElementById('analysis'));
}
