/**
 * First we will load all of this project's JavaScript dependencies which
 * includes React and other helpers. It's a great starting point while
 * building robust, powerful web applications using React + Laravel.
 */

require('./bootstrap');

/**
 * Next, we will create a fresh React component instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

require('./components/Index');
require('./components/Navbar');
require('./components/AuthComponent/Login');
require('./components/AdminComponent/AdminPanel');
require('./components/Footer');
require('./components/AuthComponent/Registration');
require('./components/Support/Support');
require('./components/CryptoComponents/Coins');
require('./components/CryptoComponents/OneCoin');
require('./components/CryptoComponents/Watchlist');
require('./components/CryptoComponents/Portfolio');
require('./components/VerifyComponents/ForgoPassword');
require('./components/VerifyComponents/ResetPassword');
require('./components/NewsComponent/News');
require('./components/VerifyComponents/CompleteRegistration');
require('./components/VerifyComponents/VerifyTwoAuth');
require('./components/Quiz/Learn');
require('./components/CryptoComponents/CryptoSwap');
require('./components/Support/OneTicket');
require('./components/AuthComponent/Settings');
require('./components/Commands/Commands');
require('./components/Forums/Forum');
require('./components/Forums/Analysis');
require('./components/Forums/OneForum');
require('./components/Forums/OneAnalysis');
require('./components/Forums/Post');
require('./components/Forums/VipForum');
require('./components/VerifyComponents/VerifyEmail');
